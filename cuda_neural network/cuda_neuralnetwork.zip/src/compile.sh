extension='.cpp'
file_names=(*${extension})
for file in "${file_names[@]}";do
   name="${file%.*}"
   echo "$CC $CCFLAGS -c $file -o ${name}.o"
   $CC  $CCFLAGS -c $file -o ${name}.o
done

