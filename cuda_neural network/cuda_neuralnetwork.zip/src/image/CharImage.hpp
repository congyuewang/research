#pragma once

#include "../common/Common.hpp"
#include <cassert>
#include <vector>

struct CharImage {
    //unsigned width;
    unsigned features;
    
    // TODO: this can be an std::array since mnist data is 28x28 images.
    vector<float> pixels; // row wise
    
    CharImage(unsigned features,const vector<float> &pixels)
    : features(features),pixels(pixels) {
        // assert(pixels.size()==2048);
    }
};