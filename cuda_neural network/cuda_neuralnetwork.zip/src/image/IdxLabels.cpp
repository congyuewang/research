#include "IdxLabels.hpp"
#include "IdxUtil.hpp"
#include <fstream>
#include <iostream>

//static constexpr int IDX_MAGIC_NUM = 2049;

IdxLabels::IdxLabels(string filePath,string numPath) : filePath(filePath),numPath(numPath) {}
//IdxLabels::IdxLabels(string filePath,string numPath) : numPath(numPath) {}
vector<int> IdxLabels::Load(void) const {
    vector<int> result;
    int label;
    
    std::ifstream is;
    is.open(filePath);
    std::ifstream num;
    num.open(numPath);
    if (is) {
        // if (!loadAndCheckMagicNumber(is)) {
        //   cout << "Error, invalid file magic number" << endl;
        //   return result;
        // }
        
        //int numLabels = loadNumEntries(is);
        int numLabels;
        num>>numLabels;
        result.reserve(numLabels);
        string line;
        for (int i = 0; i < numLabels; i++) {
            //int label = static_cast<int>(Idx::readUchar(is));
            //label=is.get();
            //std::cout<<pixelValue<<std::endl;
            //pixels.push_back(p-48);
            //assert(label = 0 || label = 1);
            
            //result.push_back(label-48);
            //string number;
            getline(is,line);
            label=std::stoi(line);
            //result.push_back(label);
            //result[i]=label;
            result.insert(result.begin()+i,label);
        }
       // for(int i=0;i<50;i++){
            
            
        //    std::cout<<result[i]<<std::endl;
       // }
        
    } else {
        cout << "Error, no such file: " << filePath << endl;
    }
    
    return result;
}

//bool IdxLabels::loadAndCheckMagicNumber(istream &in) const {
//  return Idx::readInt(in) == IDX_MAGIC_NUM;
//}

//int IdxLabels::loadNumEntries(istream &in) const { return Idx::readInt(in); }
