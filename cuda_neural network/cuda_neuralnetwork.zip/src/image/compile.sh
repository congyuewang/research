extension='.cpp'
lib_name=image
file_names=(*${extension})
for file in "${file_names[@]}";do
   name="${file%.*}"
   echo "$CC $CLFLAGS $CCFLAGS -c $file -o ${name}.o"
   $CC $CLFLAGS $CCFLAGS -c $file -o ${name}.o
done

echo "ar crs ${lib_name}.a *.o"
ar crs ${lib_name}.a *.o

