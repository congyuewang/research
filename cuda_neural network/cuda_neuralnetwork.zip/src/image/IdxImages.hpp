#pragma once

#include "../common/Common.hpp"
#include "CharImage.hpp"
#include <iostream>
#include <string>
#include <vector>

class IdxImages {
  string filePath;
  string numPath;

public:
  IdxImages(string filePath,string numPath);

  vector<CharImage> Load(void) const;

private:
 // bool loadAndCheckMagicNumber(istream &in) const;
 // int loadNumEntries(istream &in) const;
  CharImage loadImage(istream &in, int features) const;
};
