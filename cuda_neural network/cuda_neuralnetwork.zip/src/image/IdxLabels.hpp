#pragma once

#include "../common/Common.hpp"
#include <iostream>
#include <string>
#include <vector>

class IdxLabels {
  string filePath;
    string numPath;

public:
  IdxLabels(string filePath,string numPath);

  vector<int> Load(void) const;

private:
  bool loadAndCheckMagicNumber(istream &in) const;
  int loadNumEntries(istream &in) const;
};
