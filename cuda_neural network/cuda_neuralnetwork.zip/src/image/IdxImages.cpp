
#include "IdxImages.hpp"
#include "IdxUtil.hpp"
#include <fstream>
#include <iostream>
#include <bitset>
//static constexpr int IDX_MAGIC_NUM = 2051;

IdxImages::IdxImages(string filePath,string numPath) : filePath(filePath),numPath(numPath) {}
//IdxImages::IdxImages(string filePath,string numPath){}
vector<CharImage> IdxImages::Load(void) const {
    vector<CharImage> result;
    
    std::ifstream is;
    is.open(filePath);
    std::ifstream num;
    num.open(numPath);
    //if (is) {
    //  if (!loadAndCheckMagicNumber(is)) {
    //     cout << "Error, invalid file magic number" << endl;
    //   return result;
    //  }
    
    int numImages;
    num>>numImages;
    int numFeatures=2048;
    
    // int imgWidth = Idx::readInt(is);
    // int imgHeight = Idx::readInt(is);
    //assert(imgWidth > 0 && imgHeight > 0);
    
    result.reserve(numImages);
    for (int i = 0; i < numImages; i++) {
        //result.push_back(loadImage(is, numFeatures));
        result.insert(result.begin()+i,loadImage(is, numFeatures));
    }
    // } else {
    //   cout << "Error, no such file: " << filePath << endl;
    // }
    
    return result;
}

//bool IdxImages::loadAndCheckMagicNumber(istream &in) const {
//  return Idx::readInt(in) == IDX_MAGIC_NUM;
//}

//int IdxImages::loadNumEntries(istream &in) const { return Idx::readInt(in); }

CharImage IdxImages::loadImage(istream &in, int features) const {
    assert(features > 0);
    
    vector<float> pixels;
    pixels.reserve(features);
    float pixelValue;
    string line;
    
    for (int y = 0; y < features; y++) {
        
        //float pixelValue = Idx::readUchar(in);
        
        //in>>pixels[y];
        //pixelValue=in.get();
        //std::cout<<pixelValue<<std::endl;
        //pixels.push_back(pixelValue-48);
        //in.get(pixels[y]);
        getline(in,line);
        pixelValue=strtof((line).c_str(),0);
        //pixels.push_back(pixelValue);
        //pixels[y]=pixelValue;
        pixels.insert(pixels.begin()+y,pixelValue);
        
    }
    //for(int i=0;i<50;i++){
    
    
    // std::cout<<pixels[i]<<std::endl;
    //}
    
    //std::cout<<pixe[i]<<std::endl;
    
    return CharImage(features, pixels);
}
