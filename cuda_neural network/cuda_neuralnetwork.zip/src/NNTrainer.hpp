
#pragma once

namespace NNTrainer {
void TrainAndEvaluate(void);
}
