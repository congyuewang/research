
#include "NNTrainer.hpp"
#include "common/Common.hpp"

int main(int argc, char **argv) {
  srand(1234);

  NNTrainer::TrainAndEvaluate();
  return 0;
}
