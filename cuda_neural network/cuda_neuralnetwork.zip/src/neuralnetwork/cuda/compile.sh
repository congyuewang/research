extension='.cu'
lib_name=cuda
file_names=(*${extension})
for file in "${file_names[@]}";do
   name="${file%.*}"
   echo "$CUDACC $CLFLAGS $CUDAFLAGS -c $file -o ${name}.o"
   $CUDACC $CLFLAGS $CUDAFLAGS -c $file -o ${name}.o
done

echo "ar crs ${lib_name}.a *.o"
ar crs ${lib_name}.a *.o

