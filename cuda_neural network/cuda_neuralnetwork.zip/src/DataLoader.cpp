
#include "DataLoader.hpp"

#include "image/CharImage.hpp"
#include "image/IdxImages.hpp"
#include "image/IdxLabels.hpp"
//#include "image/ImageGenerator.hpp"

#include <map>
#include <string>
#include <vector>

using namespace neuralnetwork;

// Number of images to generate using rotation and translation from each canonical training image.
static constexpr unsigned NUM_DERIVED_IMAGES = 5;

static constexpr float GENERATED_IMAGE_SHIFT_X = 0.1f;
static constexpr float GENERATED_IMAGE_SHIFT_Y = 0.1f;
static constexpr float GENERATED_IMAGE_ROT_THETA = 10.0f * M_PI / 180.0f;
static constexpr float PIXEL_DROPOUT_RATE = 0.0f;



static map<int, vector<CharImage>> loadLabeledImages(string imagePath, string labelPath ,string numPath);



static TrainingSample sampleFromCharImage(int label, const CharImage &img);

// Loads the training samples from the given digits files. Optionally generates additional derived
// images from the canonical loaded samples.
vector<TrainingSample> DataLoader::LoadSamples(string inImagePath, string inLabelPath,string innumPath){
  auto labeledImages = loadLabeledImages(inImagePath, inLabelPath,innumPath);

  

  vector<TrainingSample> result;
  int inputSize = 0;
  int outputSize = 0;

  for (const auto &entry : labeledImages) {
    for (const auto &image : entry.second) {
      result.push_back(sampleFromCharImage(entry.first, image));
      inputSize = result.back().input.rows();
      outputSize = result.back().expectedOutput.rows();
    }
  }

  for (const auto &sample : result) {
    assert(inputSize > 0 && outputSize > 0);
    assert(sample.input.rows() == inputSize);
    assert(sample.expectedOutput.rows() == outputSize);
  }

  return result;
}

map<int, vector<CharImage>> loadLabeledImages(string imagePath, string labelPath,string numPath) {
  IdxImages imageLoader(imagePath,numPath);
  IdxLabels labelLoader(labelPath,numPath);

  vector<int> labels = labelLoader.Load();
  vector<CharImage> images = imageLoader.Load();
  //for (int i=0;i<200;i++) {
  //  std::cout<<images[1].pixels[i]<<std::endl;
  //}
  std:cout<<labels.size()<<std::endl;
  std::cout<<images.size()<<std::endl;

  assert(labels.size() == images.size());

  map<int, vector<CharImage>> result;
  for (unsigned i = 0; i < labels.size(); i++) {
    if (result.find(labels[i]) == result.end()) {
      result[labels[i]] = vector<CharImage>();
    }

    result[labels[i]].push_back(images[i]);
  }

  return result;
}



TrainingSample sampleFromCharImage(int label, const CharImage &img) {
  EVector output(2);
  output.fill(0.0f);
  output[label] = 1.0f;

  EVector input(img.pixels.size());
  for (unsigned i = 0; i < img.pixels.size(); i++) {
    input(i) = img.pixels[i];
  }

  return neuralnetwork::TrainingSample(input, output);
}
