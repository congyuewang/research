clear;
clc;
MainPath = 'C:\Users\congyue wang\Documents\Visual Studio 2012\Projects\l=9_center_z\';
FigPath = 'C:\Users\congyue wang\Documents\Visual Studio 2012\Projects\l=9_center_z\data analysis\';
FolderNames = strcat(FigPath,'FolderNames.txt');
FNs = fopen(FolderNames,'r');
Runsnum=104;

MinTime = 1e-8;


AllTgmax(1:Runsnum,1:5)=0;
AllFNs(1:Runsnum,1:3)=0;

%while ~(feof(FNs))
    for FNsnum=1:10;
    %-------------------------------
    A = textscan(FNs,'%[^\n]',1);
    FolderName = cell2mat(A{1,1});
    clear A;
    %-------------------------------

    n =str2double(FolderName(1:2));  %n
    eNPStrength =str2double(FolderName(4:8));  %eNP
    npsize =str2double(FolderName(10:14));  %h
    
    AllFNs(FNsnum,1)=str2double(FolderName(1:2));  %n
    AllFNs(FNsnum,2)=str2double(FolderName(4:8));  %eNP
    AllFNs(FNsnum,3)=str2double(FolderName(10:14));  %h
    
    FolderNamesToRun = strcat(MainPath,FolderName,'\FolderNamesToRun.txt');
    FNsToRun = fopen(FolderNamesToRun,'r');
    
    UtotAvrg_T(1:30,1:3,1:2)=0;
    nAlphaAvrg_T(1:30,1:3,1:2)=0;
    nBetaAvrg_T(1:30,1:3,1:2)=0;
    nNonAlphaAvrg_T(1:30,1:3,1:2)=0;
    Ts(1:30)=0;
    
    while ~(feof(FNsToRun))
        A = textscan(FNsToRun,'%[^\n]',1);
        SubFolderName = cell2mat(A{1,1});
        clear A;
        if ~isempty(SubFolderName)
        SubFolderName = strcat(SubFolderName(1:5));
        
        Names = strcat(MainPath,FolderName,'\',SubFolderName,'\Outputs\Names.txt');
        Ns = fopen(Names,'r');
        Tnum=0;
 
        GTauscopy = xlsread(strcat(FigPath,'1-AutoCorrelation\ExcelFiles\',FolderName,'.xls'),SubFolderName,'A1:C30');
        CL(1:size(GTauscopy,1),1) = GTauscopy(1:size(GTauscopy,1),1);
        CL(1:size(GTauscopy,1),2) = GTauscopy(1:size(GTauscopy,1),2);
        clear GTauscopy;

        while ~(feof(Ns))
            A = textscan(Ns,'%[^\n]',1);
            FileName = cell2mat(A{1,1});
            textscan(Ns,'%[^\n]',1);
            clear A;
            if length(FileName)>1
                %Find T and EFileName
                %--------------------
                Tstr = FileName(18:23);
                T = str2double(Tstr);
                Tnum = Tnum+1;
                Ts(Tnum)=T;
                %SubTitle = strcat(FolderName,'-',SubFolderName,'-',Tstr);
                EFileName = strcat(MainPath,FolderName,'\',SubFolderName,'\Outputs\DataToAnalyze\E-HBns-R\E-HBns-R',FileName,'.txt');
                %--------------------

                EFile = fopen(EFileName,'r');
                textscan(EFile,'%*[^\n]',1);

                % Reading Data from E File
                All = textscan(EFile,...
                    '%f %f %f %f %f %f %f %f %f %d %d %d %f %f %f %f %f %f %f %f %f %f %f %f %f',-1);
                Utot = All{1,7};        
                nAlpha = All{1,9};
                nBeta = All{1,10};
                nHBtot = All{1,11};
                time = All{1,24};
                clear All;
                fclose(EFile);

                %Don't consider first data in MinTime range
                %------------------------------------------
                Datalen = length(time);
                if (time(1)<MinTime)
                    i=1;
                    while time(i)<MinTime
                        i=i+1;
                    end
                    time = time(i:Datalen);
                    Utot = Utot(i:Datalen);
                    nAlpha = nAlpha(i:Datalen);
                    nBeta = nBeta(i:Datalen);
                    nHBtot = nHBtot(i:Datalen);
                end
                Datalen = length(time);
                %------------------------------------------
               
                endtime = time(length(time))*1e6;       %seconds to microseconds
                Utot = Utot*T;       %KbT to eHB

                nNonAlpha(1:Datalen)=0;
                for i=1:Datalen
                    nNonAlpha(i) = nHBtot(i)-nAlpha(i);
                end
                clear nHBtot;

                
                %Do what you want with Data
                %==========================
                if endtime>0.1 
                    ibeg = round(Datalen/2);
                else
                    ibeg = min(round(0.05/endtime*Datalen),Datalen-2);
                end
                
                Utot_Avrg = mean(Utot(ibeg:Datalen));
                Utot_Var = var(Utot(ibeg:Datalen)); %*CL(Tnum,2)because of autocorrelation of data
                if SubFolderName(1)=='F'
                    UtotAvrg_T(Tnum,1,1) = UtotAvrg_T(Tnum,1,1)+1;  %count
                    UtotAvrg_T(Tnum,2,1) = UtotAvrg_T(Tnum,2,1)+Utot_Avrg;  %sum of Averages
                    UtotAvrg_T(Tnum,3,1) = UtotAvrg_T(Tnum,3,1)+Utot_Var;  %sum of Variances
                elseif SubFolderName(1)=='U'
                    UtotAvrg_T(Tnum,1,2) = UtotAvrg_T(Tnum,1,2)+1;  %count
                    UtotAvrg_T(Tnum,2,2) = UtotAvrg_T(Tnum,2,2)+Utot_Avrg;  %sum of Averages
                    UtotAvrg_T(Tnum,3,2) = UtotAvrg_T(Tnum,3,2)+Utot_Var;  %sum of Variances
                else
                    'error on F, UF'
                    SubFolderName
                end
                
                nAlpha_Avrg = mean(nAlpha(ibeg:Datalen));
                nAlpha_Var = var(double(nAlpha(ibeg:Datalen))); %*CL(Tnum,2)because of autocorrelation of data
                if SubFolderName(1)=='F'
                    nAlphaAvrg_T(Tnum,1,1) = nAlphaAvrg_T(Tnum,1,1)+1;  %count
                    nAlphaAvrg_T(Tnum,2,1) = nAlphaAvrg_T(Tnum,2,1)+nAlpha_Avrg;  %sum of Averages
                    nAlphaAvrg_T(Tnum,3,1) = nAlphaAvrg_T(Tnum,3,1)+nAlpha_Var;  %sum of Variances
                elseif SubFolderName(1)=='U'
                    nAlphaAvrg_T(Tnum,1,2) = nAlphaAvrg_T(Tnum,1,2)+1;  %count
                    nAlphaAvrg_T(Tnum,2,2) = nAlphaAvrg_T(Tnum,2,2)+nAlpha_Avrg;  %sum of Averages
                    nAlphaAvrg_T(Tnum,3,2) = nAlphaAvrg_T(Tnum,3,2)+nAlpha_Var;  %sum of Variances
                else
                    'error on F, UF'
                    SubFolderName
                end
                
                nBeta_Avrg = mean(nBeta(ibeg:Datalen));
                nBeta_Var = var(double(nBeta(ibeg:Datalen))); %*CL(Tnum,2)because of autocorrelation of data
                if SubFolderName(1)=='F'
                    nBetaAvrg_T(Tnum,1,1) = nBetaAvrg_T(Tnum,1,1)+1;  %count
                    nBetaAvrg_T(Tnum,2,1) = nBetaAvrg_T(Tnum,2,1)+nBeta_Avrg;  %sum of Averages
                    nBetaAvrg_T(Tnum,3,1) = nBetaAvrg_T(Tnum,3,1)+nBeta_Var;  %sum of Variances
                elseif SubFolderName(1)=='U'
                    nBetaAvrg_T(Tnum,1,2) = nBetaAvrg_T(Tnum,1,2)+1;  %count
                    nBetaAvrg_T(Tnum,2,2) = nBetaAvrg_T(Tnum,2,2)+nBeta_Avrg;  %sum of Averages
                    nBetaAvrg_T(Tnum,3,2) = nBetaAvrg_T(Tnum,3,2)+nBeta_Var;  %sum of Variances
                else
                    'error on F, UF'
                    SubFolderName
                end
                
                nNonAlpha_Avrg = mean(nNonAlpha(ibeg:Datalen));
                nNonAlpha_Var = var(double(nNonAlpha(ibeg:Datalen))); %*CL(Tnum,2)because of autocorrelation of data
                if SubFolderName(1)=='F'
                    nNonAlphaAvrg_T(Tnum,1,1) = nNonAlphaAvrg_T(Tnum,1,1)+1;  %count
                    nNonAlphaAvrg_T(Tnum,2,1) = nNonAlphaAvrg_T(Tnum,2,1)+nNonAlpha_Avrg;  %sum of Averages
                    nNonAlphaAvrg_T(Tnum,3,1) = nNonAlphaAvrg_T(Tnum,3,1)+nNonAlpha_Var;  %sum of Variances
                elseif SubFolderName(1)=='U'
                    nNonAlphaAvrg_T(Tnum,1,2) = nNonAlphaAvrg_T(Tnum,1,2)+1;  %count
                    nNonAlphaAvrg_T(Tnum,2,2) = nNonAlphaAvrg_T(Tnum,2,2)+nNonAlpha_Avrg;  %sum of Averages
                    nNonAlphaAvrg_T(Tnum,3,2) = nNonAlphaAvrg_T(Tnum,3,2)+nNonAlpha_Var;  %sum of Variances
                else
                    'error on F, UF'
                    SubFolderName
                end
                %==========================
            clear nAlpha Utot time nNonAlpha nBeta;
            end
        end   
        fclose(Ns);
        clear CL;
        end
        
    end
    fclose(FNsToRun);
    
    Tmean=(min(Ts(1:Tnum))+max(Ts))/2;
    
    Ts_Accept(1:30)=1; %the temperature is accepted for data collection or not
    
    Tgmax_Utot=min(Ts(1:Tnum));
    F_Utot(1:30)=0;
    F_Utot_err(1:30)=0;
    UF_Utot(1:30)=0;
    UF_Utot_err(1:30)=0;
    i=0;
    while Ts(i+1)>0
        i=i+1;
        
        num=UtotAvrg_T(i,1,1);
        if num>0
            F_Utot(i)=UtotAvrg_T(i,2,1)/num;
            F_Utot_err(i)=sqrt(UtotAvrg_T(i,3,1))/num;
        end
        
        num=UtotAvrg_T(i,1,2);
        if num>0 
            UF_Utot(i)=UtotAvrg_T(i,2,2)/num;
            UF_Utot_err(i)=sqrt(UtotAvrg_T(i,3,2))/num;
        end
        
        if (Ts(i)<=Tmean) && (Tgmax_Utot==min(Ts(1:Tnum))) && ((F_Utot(i)+F_Utot_err(i))<(UF_Utot(i)-UF_Utot_err(i)) || (F_Utot(i)-F_Utot_err(i))>(UF_Utot(i)+UF_Utot_err(i)))
            Tgmax_Utot = max(Ts(i+1),Ts(i));
        end
    end
    
    Tgmax_nAlpha=min(Ts(1:Tnum));
    F_nAlpha(1:30)=0;
    F_nAlpha_err(1:30)=0;
    UF_nAlpha(1:30)=0;
    UF_nAlpha_err(1:30)=0;
    i=0;
    while Ts(i+1)>0
        i=i+1;
        
        num=nAlphaAvrg_T(i,1,1);
        if num>0
            F_nAlpha(i)=nAlphaAvrg_T(i,2,1)/num;
            F_nAlpha_err(i)=sqrt(nAlphaAvrg_T(i,3,1))/num;
        end
        
        num=nAlphaAvrg_T(i,1,2);
        if num>0 
            UF_nAlpha(i)=nAlphaAvrg_T(i,2,2)/num;
            UF_nAlpha_err(i)=sqrt(nAlphaAvrg_T(i,3,2))/num;
        end
        
        if (Ts(i)<=Tmean) && (Tgmax_nAlpha==min(Ts(1:Tnum))) && ((F_nAlpha(i)+F_nAlpha_err(i))<(UF_nAlpha(i)-UF_nAlpha_err(i)) || (F_nAlpha(i)-F_nAlpha_err(i))>(UF_nAlpha(i)+UF_nAlpha_err(i)))
            Tgmax_nAlpha = max(Ts(i+1),Ts(i));
        end
        if abs(F_nAlpha(i)-UF_nAlpha(i))>(F_nAlpha_err(i)+UF_nAlpha_err(i)) %+min(F_nAlpha_err(i),UF_nAlpha_err(i))
            Ts_Accept(i)=0;
        end
    end
    
    Tgmax_nBeta=min(Ts(1:Tnum));
    F_nBeta(1:30)=0;
    F_nBeta_err(1:30)=0;
    UF_nBeta(1:30)=0;
    UF_nBeta_err(1:30)=0;
    i=0;
    while Ts(i+1)>0
        i=i+1;
        
        num=nBetaAvrg_T(i,1,1);
        if num>0
            F_nBeta(i)=nBetaAvrg_T(i,2,1)/num;
            F_nBeta_err(i)=sqrt(nBetaAvrg_T(i,3,1))/num;
        end
        
        num=nBetaAvrg_T(i,1,2);
        if num>0 
            UF_nBeta(i)=nBetaAvrg_T(i,2,2)/num;
            UF_nBeta_err(i)=sqrt(nBetaAvrg_T(i,3,2))/num;
        end
        
        if (Ts(i)<=Tmean) && (Tgmax_nBeta==min(Ts(1:Tnum))) && ((F_nBeta(i)+F_nBeta_err(i))<(UF_nBeta(i)-UF_nBeta_err(i)) || (F_nBeta(i)-F_nBeta_err(i))>(UF_nBeta(i)+UF_nBeta_err(i)))
            Tgmax_nBeta = max(Ts(i+1),Ts(i));
        end
    end
    
    Tgmax_nNonAlpha=min(Ts(1:Tnum));
    F_nNonAlpha(1:30)=0;
    F_nNonAlpha_err(1:30)=0;
    UF_nNonAlpha(1:30)=0;
    UF_nNonAlpha_err(1:30)=0;
    i=0;
    while Ts(i+1)>0
        i=i+1;
        
        num=nNonAlphaAvrg_T(i,1,1);
        if num>0
            F_nNonAlpha(i)=nNonAlphaAvrg_T(i,2,1)/num;
            F_nNonAlpha_err(i)=sqrt(nNonAlphaAvrg_T(i,3,1))/num;
        end
        
        num=nNonAlphaAvrg_T(i,1,2);
        if num>0 
            UF_nNonAlpha(i)=nNonAlphaAvrg_T(i,2,2)/num;
            UF_nNonAlpha_err(i)=sqrt(nNonAlphaAvrg_T(i,3,2))/num;
        end
        
        if (Ts(i)<=Tmean) && (Tgmax_nNonAlpha==min(Ts(1:Tnum))) && ((F_nNonAlpha(i)+F_nNonAlpha_err(i))<(UF_nNonAlpha(i)-UF_nNonAlpha_err(i)) || (F_nNonAlpha(i)-F_nNonAlpha_err(i))>(UF_nNonAlpha(i)+UF_nNonAlpha_err(i)))
            Tgmax_nNonAlpha = max(Ts(i+1),Ts(i));
        end
    end
    
    
    figure;
    errorbar(Ts(1:i),F_Utot(1:i),F_Utot_err(1:i),'-ok','LineWidth',2);
    hold on;
    errorbar(Ts(1:i),UF_Utot(1:i),UF_Utot_err(1:i),'-sk','LineWidth',2);
    hold on;
    errorbar(Ts(1:i),-F_nAlpha(1:i),F_nAlpha_err(1:i),'-ob','LineWidth',2);
    hold on;
    errorbar(Ts(1:i),-UF_nAlpha(1:i),UF_nAlpha_err(1:i),'-sb','LineWidth',2);
    hold on;
    errorbar(Ts(1:i),-F_nBeta(1:i),F_nBeta_err(1:i),'-or','LineWidth',2);
    hold on;
    errorbar(Ts(1:i),-UF_nBeta(1:i),UF_nBeta_err(1:i),'-sr','LineWidth',2);
    hold on;
    errorbar(Ts(1:i),-F_nNonAlpha(1:i),F_nNonAlpha_err(1:i),'-og','LineWidth',2);
    hold on;
    errorbar(Ts(1:i),-UF_nNonAlpha(1:i),UF_nNonAlpha_err(1:i),'-sg','LineWidth',2);
    title(FolderName)
    print('-dpng',strcat(FigPath,'2-Tg\Figs\',FolderName,'.png'));
    close;
    
    AllTgmax(FNsnum,1:5)=[Tgmax_Utot,Tgmax_nAlpha,Tgmax_nBeta,Tgmax_nNonAlpha,max([Tgmax_Utot,Tgmax_nAlpha,Tgmax_nBeta,Tgmax_nNonAlpha])];
    xlswrite(strcat(FigPath,'2-Tg\ExcelFiles\',FolderName,'.xls'),Ts(1:i)',1,'a1');
    xlswrite(strcat(FigPath,'2-Tg\ExcelFiles\',FolderName,'.xls'),Ts_Accept(1:i)',1,'b1');
    xlswrite(strcat(FigPath,'2-Tg\ExcelFiles\',FolderName,'.xls'),F_Utot(1:i)',1,'c1');
    xlswrite(strcat(FigPath,'2-Tg\ExcelFiles\',FolderName,'.xls'),F_Utot_err(1:i)',1,'d1');
    xlswrite(strcat(FigPath,'2-Tg\ExcelFiles\',FolderName,'.xls'),F_nAlpha(1:i)',1,'e1');
    xlswrite(strcat(FigPath,'2-Tg\ExcelFiles\',FolderName,'.xls'),F_nAlpha_err(1:i)',1,'f1');
    xlswrite(strcat(FigPath,'2-Tg\ExcelFiles\',FolderName,'.xls'),F_nBeta(1:i)',1,'g1');
    xlswrite(strcat(FigPath,'2-Tg\ExcelFiles\',FolderName,'.xls'),F_nBeta_err(1:i)',1,'h1');
    xlswrite(strcat(FigPath,'2-Tg\ExcelFiles\',FolderName,'.xls'),F_nNonAlpha(1:i)',1,'i1');
    xlswrite(strcat(FigPath,'2-Tg\ExcelFiles\',FolderName,'.xls'),F_nNonAlpha_err(1:i)',1,'j1');

    xlswrite(strcat(FigPath,'2-Tg\ExcelFiles\',FolderName,'.xls'),Ts(1:i)',2,'a1');
    xlswrite(strcat(FigPath,'2-Tg\ExcelFiles\',FolderName,'.xls'),Ts_Accept(1:i)',2,'b1');
    xlswrite(strcat(FigPath,'2-Tg\ExcelFiles\',FolderName,'.xls'),UF_Utot(1:i)',2,'c1');
    xlswrite(strcat(FigPath,'2-Tg\ExcelFiles\',FolderName,'.xls'),UF_Utot_err(1:i)',2,'d1');
    xlswrite(strcat(FigPath,'2-Tg\ExcelFiles\',FolderName,'.xls'),UF_nAlpha(1:i)',2,'e1');
    xlswrite(strcat(FigPath,'2-Tg\ExcelFiles\',FolderName,'.xls'),UF_nAlpha_err(1:i)',2,'f1');
    xlswrite(strcat(FigPath,'2-Tg\ExcelFiles\',FolderName,'.xls'),UF_nBeta(1:i)',2,'g1');
    xlswrite(strcat(FigPath,'2-Tg\ExcelFiles\',FolderName,'.xls'),UF_nBeta_err(1:i)',2,'h1');
    xlswrite(strcat(FigPath,'2-Tg\ExcelFiles\',FolderName,'.xls'),UF_nNonAlpha(1:i)',2,'i1');
    xlswrite(strcat(FigPath,'2-Tg\ExcelFiles\',FolderName,'.xls'),UF_nNonAlpha_err(1:i)',2,'j1');
    
    disp(FolderName);
    clear F_Utot F_Utot_err F_nAlpha F_nAlpha_err F_nBeta F_nBeta_err F_nNonAlpha F_nNonAlpha_err;
    clear UF_Utot UF_Utot_err UF_nAlpha UF_nAlpha_err UF_nBeta UF_nBeta_err UF_nNonAlpha UF_nNonAlpha_err;

end
fclose(FNs);



xlswrite(strcat(FigPath,'2-Tg\TgMax.xls'),AllFNs,1,'a1'); %Runsnum=104
xlswrite(strcat(FigPath,'2-Tg\TgMax.xls'),AllTgmax,1,'d1');
