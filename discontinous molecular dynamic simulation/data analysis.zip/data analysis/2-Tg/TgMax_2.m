clear;
clc;
MainPath = 'F:\Data\';
FigPath = 'F:\Data\AnalyzeData\';
FolderNames = strcat(FigPath,'FolderNames.txt');
FNs = fopen(FolderNames,'r');
Runsnum=104;

MinTime = 1e-8;

FNsnum=0;
AllTgmax(1:Runsnum,1:5)=0;
AllFNs(1:Runsnum,1:3)=0;
while ~(feof(FNs))
    FNsnum=FNsnum+1;
    %-------------------------------
    A = textscan(FNs,'%[^\n]',1);
    FolderName = cell2mat(A{1,1});
    clear A;
    %-------------------------------

    n =str2double(FolderName(1:2));  %n
    eNPStrength =str2double(FolderName(4:8));  %eNP
    npsize =str2double(FolderName(10:14));  %h
    
    AllFNs(FNsnum,1)=str2double(FolderName(1:2));  %n
    AllFNs(FNsnum,2)=str2double(FolderName(4:8));  %eNP
    AllFNs(FNsnum,3)=str2double(FolderName(10:14));  %h
    
    FolderNamesToRun = strcat(MainPath,FolderName,'\FolderNamesToRun.txt');
    FNsToRun = fopen(FolderNamesToRun,'r');
    
    UtotAvrg_T(1:30,1:3,1:2)=0;
    nAlphaAvrg_T(1:30,1:3,1:2)=0;
    nBetaAvrg_T(1:30,1:3,1:2)=0;
    nNonAlphaAvrg_T(1:30,1:3,1:2)=0;
    %Ts(1:30)=0;
    
    if FNsnum>=71
    
    Ts=xlsread(strcat(FigPath,'2-Tg\ExcelFiles\',FolderName,' - Copy.xls'),'a1');
    xlswrite(strcat(FigPath,'2-Tg\ExcelFiles\',FolderName,'.xls'),Ts,1,'a1');
    
    Ts_Accept=xlsread(strcat(FigPath,'2-Tg\ExcelFiles\',FolderName,' - Copy.xls'),'b1');
    xlswrite(strcat(FigPath,'2-Tg\ExcelFiles\',FolderName,'.xls'),Ts_Accept,1,'b1');

    F_Utot=xlsread(strcat(FigPath,'2-Tg\ExcelFiles\',FolderName,' - Copy.xls'),'c1');
    xlswrite(strcat(FigPath,'2-Tg\ExcelFiles\',FolderName,'.xls'),F_Utot,1,'c1');
    
    F_Utot_err=xlsread(strcat(FigPath,'2-Tg\ExcelFiles\',FolderName,' - Copy.xls'),'d1');
    xlswrite(strcat(FigPath,'2-Tg\ExcelFiles\',FolderName,'.xls'),F_Utot_err,1,'d1');

    F_nAlpha=xlsread(strcat(FigPath,'2-Tg\ExcelFiles\',FolderName,' - Copy.xls'),'e1');
    xlswrite(strcat(FigPath,'2-Tg\ExcelFiles\',FolderName,'.xls'),F_nAlpha,1,'e1');

    F_nAlpha_err=xlsread(strcat(FigPath,'2-Tg\ExcelFiles\',FolderName,' - Copy.xls'),'f1');
    xlswrite(strcat(FigPath,'2-Tg\ExcelFiles\',FolderName,'.xls'),F_nAlpha_err,1,'f1');

    F_nBeta=xlsread(strcat(FigPath,'2-Tg\ExcelFiles\',FolderName,' - Copy.xls'),'g1');
    xlswrite(strcat(FigPath,'2-Tg\ExcelFiles\',FolderName,'.xls'),F_nBeta,1,'g1');

    F_nBeta_err=xlsread(strcat(FigPath,'2-Tg\ExcelFiles\',FolderName,' - Copy.xls'),'h1');
    xlswrite(strcat(FigPath,'2-Tg\ExcelFiles\',FolderName,'.xls'),F_nBeta_err,1,'h1');

    F_nBeta=xlsread(strcat(FigPath,'2-Tg\ExcelFiles\',FolderName,' - Copy.xls'),'i1');
    xlswrite(strcat(FigPath,'2-Tg\ExcelFiles\',FolderName,'.xls'),F_nBeta,1,'i1');

    F_nBeta_err=xlsread(strcat(FigPath,'2-Tg\ExcelFiles\',FolderName,' - Copy.xls'),'j1');
    xlswrite(strcat(FigPath,'2-Tg\ExcelFiles\',FolderName,'.xls'),F_nBeta_err,1,'j1');
    end

end
fclose(FNs);

