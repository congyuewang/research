clear all;
clc;
MainPath = 'E:\Leili\FromPC\';
FigPath = 'E:\Leili\FromPC\AnalyzeData\';

FolderNames = strcat(FigPath,'FolderNames.txt');
FNs = fopen(FolderNames,'r');
Runsnum=104;

Foldernum=1;
AllFNs(1:Runsnum,1:3)=0;

while ~(feof(FNs))
    %-------------------------------
    A = textscan(FNs,'%[^\n]',1);
    FolderName = cell2mat(A{1,1});
    clear A;
    %-------------------------------

    n =str2double(FolderName(1:2));  %n
    eNPStrength =str2double(FolderName(4:8));  %eNP
    npsize =str2double(FolderName(10:14));  %h
    
    AllFNs(Foldernum,1)=n;  %n
    AllFNs(Foldernum,2)=eNPStrength;  %eNP
    AllFNs(Foldernum,3)=npsize;  %h

    
    GTauscopy = xlsread(strcat(FigPath,'1-AutoCorrelation\ExcelFiles\',FolderName,'.xls'),'F--01','A1:C30');%SubFolderName,
    GTaus(1:size(GTauscopy,1),1) = GTauscopy(1:size(GTauscopy,1),1);
    GTaus(1:size(GTauscopy,1),2) = GTauscopy(1:size(GTauscopy,1),3);
    clear GTauscopy;
  
    MinTAvrg = GTaus(length(GTaus),1);
    MaxTAvrg = GTaus(1,1);
    dTAvrg = 0.0001; 
    nTAvrg = round((MaxTAvrg-MinTAvrg)/dTAvrg) + 1;
    
    TAvrgs = MinTAvrg:dTAvrg:MaxTAvrg;
    
    for realization=1:3
    %Utot
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    
    if realization==1
        realizationstr='01';
    elseif realization==2
        realizationstr='02';
    elseif realization==3
        realizationstr='03';
    end
    A=xlsread(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\Utot\',FolderName,'-',realizationstr,'_gk_Utot.xls'),1);
    nUtotHist=A(1,1);
    UtotHist1=A(1:nUtotHist,2);
    gk=A(1:nUtotHist,3);
    gkerror=A(1:nUtotHist,4);
    clear A;

    %Average Utot calculation at different Temperatures
    %---------------------------------------------------------
    num=0;
    for T=MinTAvrg:dTAvrg:MaxTAvrg
        num=num+1;
        Den=0;
        Num=0;
        Num2=0;
        for k1=1:nUtotHist
            gexpE=gk(k1) * exp(-UtotHist1(k1)/T);
            Den = Den + gexpE;
            Num = Num + UtotHist1(k1) * gexpE;
            Num2 = Num2 + UtotHist1(k1)^2 * gexpE;
        end
        Avrg(num) = Num/Den;
        Avrg2(num) = Num2/Den;
        
        error2=0;
        error22=0;
        for k1=1:nUtotHist
            Coef = exp(-UtotHist1(k1)/T)*(UtotHist1(k1)*Den-Num)/Den^2;
            error2 = error2 + Coef^2*gkerror(k1)^2;
            Coef2 = exp(-UtotHist1(k1)/T)*(UtotHist1(k1)^2*Den-Num)/Den^2;
            error22 = error22 + Coef2^2*gkerror(k1)^2;
        end
        Avrgerror(num)=sqrt(error2);
        Avrg2error(num)=sqrt(error22);
    end
    
    num=0;
    for T=MinTAvrg:dTAvrg:MaxTAvrg
        num=num+1;
        %Finding Cv Using <E2>-<E>2
        Cv1(num)=(Avrg2(num)-Avrg(num)^2)/T^2;
        Cv1error(num)=sqrt(Avrg2error(num)^2+(2*Avrg(num)*Avrgerror(num))^2)/T^2;
        %Finding Cv Using d<E>/dT
        if num==1
            Cv2(num) = (Avrg(num+1)-Avrg(num))/(dTAvrg);
            Cv2error(num) = sqrt(Avrgerror(num+1)^2+Avrgerror(num)^2)/(dTAvrg);
        elseif(num==nTAvrg)
            Cv2(num) = (Avrg(num)-Avrg(num-1))/(dTAvrg);
            Cv2error(num) = sqrt(Avrgerror(num)^2+Avrgerror(num-1)^2)/(dTAvrg);
        else
            Cv2(num) = (Avrg(num+1)-Avrg(num-1))/(2*dTAvrg);
            Cv2error(num) = sqrt(Avrgerror(num+1)^2+Avrgerror(num-1)^2)/(2*dTAvrg);
        end
    end
    
    %{
    %Write in excel
    xlswrite(strcat(FigPath,'4-FreeEnergy-FindTf\ExcelFiles\Utot\',FolderName,'-Avrg.xls'),TAvrgs',1,'a1');
    xlswrite(strcat(FigPath,'4-FreeEnergy-FindTf\ExcelFiles\Utot\',FolderName,'-Avrg.xls'),Avrg',1,'b1');
    xlswrite(strcat(FigPath,'4-FreeEnergy-FindTf\ExcelFiles\Utot\',FolderName,'-Avrg.xls'),Avrgerror',1,'c1');
        
    %Write in excel
    xlswrite(strcat(FigPath,'4-FreeEnergy-FindTf\ExcelFiles\Utot\',FolderName,'-Cv.xls'),TAvrgs',1,'a1');
    xlswrite(strcat(FigPath,'4-FreeEnergy-FindTf\ExcelFiles\Utot\',FolderName,'-Cv.xls'),Cv1',1,'b1');
    xlswrite(strcat(FigPath,'4-FreeEnergy-FindTf\ExcelFiles\Utot\',FolderName,'-Cv.xls'),Cv1error',1,'c1');
    xlswrite(strcat(FigPath,'4-FreeEnergy-FindTf\ExcelFiles\Utot\',FolderName,'-Cv.xls'),Cv2',1,'d1');
    xlswrite(strcat(FigPath,'4-FreeEnergy-FindTf\ExcelFiles\Utot\',FolderName,'-Cv.xls'),Cv2error',1,'e1');
        
    %making a total figure
    figure;
    errorbar(TAvrgs,Avrg,Avrgerror,'.:');
    title(strcat(FolderName,'-Avrg'));
    print('-dpng',strcat(FigPath,'4-FreeEnergy-FindTf\Figs\Utot\',FolderName,'-Avrg.png'));
    %saveas(gcf,strcat(FigPath,'4-FreeEnergy-FindTf\Figs\Utot\',FolderName,'-Avrg.fig'));
    close;
    
    figure;
    errorbar(TAvrgs,Cv1,Cv1error,'.:');
    title(strcat(FolderName,'-Cv'));
    hold on;
    errorbar(TAvrgs,Cv2,Cv2error,'r.:');
    print('-dpng',strcat(FigPath,'4-FreeEnergy-FindTf\Figs\Utot\',FolderName,'-Cv-error.png'));
    %saveas(gcf,strcat(FigPath,'4-FreeEnergy-FindTf\Figs\Utot\',FolderName,'-Cv-error.fig'));
    close;
    
    figure;
    plot(TAvrgs,Cv1,'.:');
    title(strcat(FolderName,'-Cv'));
    hold on;
    plot(TAvrgs,Cv2,'r.:');
    print('-dpng',strcat(FigPath,'4-FreeEnergy-FindTf\Figs\Utot\',FolderName,'-Cv.png'));
    %saveas(gcf,strcat(FigPath,'4-FreeEnergy-FindTf\Figs\Utot\',FolderName,'-Cv.fig'));
    close;
    %}
    
    %Finding Tf Using Cv
    %-------------------
    %MaxLoc=0;
    num=0;
    [MaxCv,MaxLoc]=max(Cv1);
    %{
    MaxCv=max(Cv1);
    for T=MinTAvrg:dTAvrg:MaxTAvrg
        num=num+1;
        if (Cv1(num)==MaxCv)
            MaxLoc=num;
        end
    end
    if (MaxLoc==0)
        S='Error on Finding MaxLoc, Cv1'
    else
    end
    %}
    %Finding error using Cv1 will result in smaller errors for eNP=0
    TCv = TAvrgs(MaxLoc);
    MaxCv = Cv1(MaxLoc);
    %Finding TCv error
    Cvmin = Cv1(MaxLoc)-Cv1error(MaxLoc);
    TCvdown1 = TCv;
    TCvup1 = TCv;
    num=0;
    for T=MinTAvrg:dTAvrg:MaxTAvrg
        num=num+1;
        Cvmin=Cv1(MaxLoc)-sqrt(Cv1error(MaxLoc)^2+Cv1error(num)^2);
        if ((Cv1(num))>=Cvmin)
            if (TAvrgs(num)<TCvdown1)
                TCvdown1=TAvrgs(num);
            elseif (TAvrgs(num)>TCvup1)
                TCvup1=TAvrgs(num);
            end
        end
    end
    
    num=0;
    [MaxCv,MaxLoc]=max(Cv2);
    TCv = TAvrgs(MaxLoc);
    MaxCv = Cv2(MaxLoc);
    %Finding TCv error
    Cvmin = Cv2(MaxLoc)-Cv2error(MaxLoc);
    TCvdown2 = TCv;
    TCvup2 = TCv;
    num=0;
    for T=MinTAvrg:dTAvrg:MaxTAvrg
        num=num+1;
        Cvmin=Cv2(MaxLoc)-sqrt(Cv2error(MaxLoc)^2+Cv2error(num)^2);
        if ((Cv2(num))>=Cvmin)
            if (TAvrgs(num)<TCvdown2)
                TCvdown2=TAvrgs(num);
            elseif (TAvrgs(num)>TCvup2)
                TCvup2=TAvrgs(num);
            end
        end
    end
    
    [Cvhalf1,iCvhalf1]=min(abs(Cv2(1:MaxLoc)-0.5*MaxCv));
    Cvhalf1=Cv2(iCvhalf1);
    [Cvhalf2,iCvhalf2]=min(abs(Cv2(MaxLoc:length(Cv2))-0.5*MaxCv));
    iCvhalf2=iCvhalf2+MaxLoc-1;
    Cvhalf2=Cv2(iCvhalf2);
    T1_Cvhalf=TAvrgs(iCvhalf1);
    T2_Cvhalf=TAvrgs(iCvhalf2);

    
    clear Avrg Avrgerror Avrg2 Avrg2error Cv1 Cv1error Cv2 Cv2error;
    %---------------------------------------------------------
   
    clear UtotHist1 UtotHist gk gkerror;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    
    
    %writing T_f_nAlpha Values
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    Tf_nAlpha(realization,Foldernum,1:3)=[TCv,min(TCv-TCvdown1,TCv-TCvdown2),min(TCvup1-TCv,TCvup2-TCv)];%,T_f_P_Utot,T_f_P_nAlpha
    MaxValsCv_nAlpha(realization,Foldernum,1:6)=[MaxCv,T2_Cvhalf-T1_Cvhalf,T1_Cvhalf,T2_Cvhalf,Cvhalf1,Cvhalf2];
    %MaxValsChi_nAlpha(realization,Foldernum,1:6)=[MaxChi,T2_Chihalf-T1_Chihalf,T1_Chihalf,T2_Chihalf,Chihalf1,Chihalf2];
    %MaxValsdq_nAlpha(realization,Foldernum,1:6)=[Maxdq,T2_dqhalf-T1_dqhalf,T1_dqhalf,T2_dqhalf,dqhalf1,dqhalf2];
    %Vals_q_p_nAlpha(realization,Foldernum,1:5)=[valq,pfuf_Utot,pfuf_Utot_2,pfuf_nAlpha,pfuf_nAlpha_2];
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    end %realization
    
    clear TAvrgs TFEs;
    TfValues(Foldernum,1)=mean(Tf_nAlpha(1:3,Foldernum,1));
    TfValues(Foldernum,2)=std(Tf_nAlpha(1:3,Foldernum,1));

    Foldernum = Foldernum+1;
    disp(FolderName);
end

%Write in excel
xlswrite(strcat(FigPath,'4-FreeEnergy-FindTf\Tf-nAlpha.xls'),AllFNs,'Tf','A1:C104');%RunsNum
xlswrite(strcat(FigPath,'4-FreeEnergy-FindTf\Tf-nAlpha.xls'),TfValues,'Tf','d1');
Tf_nAlphacopy(1:size(Tf_nAlpha,2),1:size(Tf_nAlpha,3))=Tf_nAlpha(1,:,:);
xlswrite(strcat(FigPath,'4-FreeEnergy-FindTf\Tf-nAlpha.xls'),AllFNs,'Tf1','A1:C104');%RunsNum
xlswrite(strcat(FigPath,'4-FreeEnergy-FindTf\Tf-nAlpha.xls'),Tf_nAlphacopy,'Tf1','d1');
Tf_nAlphacopy(1:size(Tf_nAlpha,2),1:size(Tf_nAlpha,3))=Tf_nAlpha(2,:,:);
xlswrite(strcat(FigPath,'4-FreeEnergy-FindTf\Tf-nAlpha.xls'),AllFNs,'Tf2','A1:C104');%RunsNum
xlswrite(strcat(FigPath,'4-FreeEnergy-FindTf\Tf-nAlpha.xls'),Tf_nAlphacopy,'Tf2','d1');
Tf_nAlphacopy(1:size(Tf_nAlpha,2),1:size(Tf_nAlpha,3))=Tf_nAlpha(3,:,:);
xlswrite(strcat(FigPath,'4-FreeEnergy-FindTf\Tf-nAlpha.xls'),AllFNs,'Tf3','A1:C104');%RunsNum
xlswrite(strcat(FigPath,'4-FreeEnergy-FindTf\Tf-nAlpha.xls'),Tf_nAlphacopy,'Tf3','d1');
MaxValsCv_nAlphacopy(1:size(MaxValsCv_nAlpha,2),1:size(MaxValsCv_nAlpha,3))=MaxValsCv_nAlpha(1,:,:);
%MaxValsChi_nAlphacopy(1:size(MaxValsChi_nAlpha,2),1:size(MaxValsChi_nAlpha,3))=MaxValsChi_nAlpha(1,:,:);
%MaxValsdq_nAlphacopy(1:size(MaxValsdq_nAlpha,2),1:size(MaxValsdq_nAlpha,3))=MaxValsdq_nAlpha(1,:,:);
%Vals_q_p_nAlphacopy=Vals_q_p_nAlpha(1,:,:);
xlswrite(strcat(FigPath,'4-FreeEnergy-FindTf\Tf-nAlpha.xls'),MaxValsCv_nAlphacopy,'MaxCv1','d1');
%xlswrite(strcat(FigPath,'4-FreeEnergy-FindTf\Tf-nAlpha.xls'),MaxValsChi_nAlphacopy,'MaxChi1','d1');
%xlswrite(strcat(FigPath,'4-FreeEnergy-FindTf\Tf-nAlpha.xls'),MaxValsdq_nAlphacopy,'Maxdq1','d1');
%xlswrite(strcat(FigPath,'4-FreeEnergy-FindTf\Tf-nAlpha.xls'),Vals_q_p_nAlphacopy,'Vals_q_p1','d1');
MaxValsCv_nAlphacopy(1:size(MaxValsCv_nAlpha,2),1:size(MaxValsCv_nAlpha,3))=MaxValsCv_nAlpha(2,:,:);
%MaxValsChi_nAlphacopy(1:size(MaxValsChi_nAlpha,2),1:size(MaxValsChi_nAlpha,3))=MaxValsChi_nAlpha(2,:,:);
%MaxValsdq_nAlphacopy(1:size(MaxValsdq_nAlpha,2),1:size(MaxValsdq_nAlpha,3))=MaxValsdq_nAlpha(2,:,:);
%Vals_q_p_nAlphacopy=Vals_q_p_nAlpha(2,:,:);
xlswrite(strcat(FigPath,'4-FreeEnergy-FindTf\Tf-nAlpha.xls'),MaxValsCv_nAlphacopy,'MaxCv2','d1');
%xlswrite(strcat(FigPath,'4-FreeEnergy-FindTf\Tf-nAlpha.xls'),MaxValsChi_nAlphacopy,'MaxChi2','d1');
%xlswrite(strcat(FigPath,'4-FreeEnergy-FindTf\Tf-nAlpha.xls'),MaxValsdq_nAlphacopy,'Maxdq2','d1');
%xlswrite(strcat(FigPath,'4-FreeEnergy-FindTf\Tf-nAlpha.xls'),Vals_q_p_nAlphacopy,'Vals_q_p2','d1');
MaxValsCv_nAlphacopy(1:size(MaxValsCv_nAlpha,2),1:size(MaxValsCv_nAlpha,3))=MaxValsCv_nAlpha(3,:,:);
%MaxValsChi_nAlphacopy(1:size(MaxValsChi_nAlpha,2),1:size(MaxValsChi_nAlpha,3))=MaxValsChi_nAlpha(3,:,:);
%MaxValsdq_nAlphacopy(1:size(MaxValsdq_nAlpha,2),1:size(MaxValsdq_nAlpha,3))=MaxValsdq_nAlpha(3,:,:);
%Vals_q_p_nAlphacopy=Vals_q_p_nAlpha(3,:,:);
xlswrite(strcat(FigPath,'4-FreeEnergy-FindTf\Tf-nAlpha.xls'),MaxValsCv_nAlphacopy,'MaxCv3','d1');
%xlswrite(strcat(FigPath,'4-FreeEnergy-FindTf\Tf-nAlpha.xls'),MaxValsChi_nAlphacopy,'MaxChi3','d1');
%xlswrite(strcat(FigPath,'4-FreeEnergy-FindTf\Tf-nAlpha.xls'),MaxValsdq_nAlphacopy,'Maxdq3','d1');
%xlswrite(strcat(FigPath,'4-FreeEnergy-FindTf\Tf-nAlpha.xls'),Vals_q_p_nAlphacopy,'Vals_q_p3','d1');

clear Tf_nAlpha MaxValsCv_nAlpha MaxValsChi_nAlpha MaxValsdq_nAlpha Vals_q_p_nAlpha;


fclose(FNs);


