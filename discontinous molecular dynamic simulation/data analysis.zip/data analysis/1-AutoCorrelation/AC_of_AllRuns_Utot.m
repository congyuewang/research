clear;
clc;
MainPath = 'C:\Users\congyue wang\Documents\Visual Studio 2012\Projects\l=9_center_z\';
FigPath = 'C:\Users\congyue wang\Documents\Visual Studio 2012\Projects\l=9_center_z\data analysis\';
FolderNames = strcat(FigPath,'FolderNames.txt');
FNs = fopen(FolderNames,'r');

while ~(feof(FNs))
    %Find n and np or Bulk
    %-------------------------------
    A = textscan(FNs,'%[^\n]',1);
    FolderName = cell2mat(A{1,1});
    clear A;
    %-------------------------------
    
    FolderNamesToRun = strcat(MainPath,FolderName,'\FolderNamesToRun.txt');
    FNsToRun = fopen(FolderNamesToRun,'r');
    
    while ~(feof(FNsToRun))
        A = textscan(FNsToRun,'%[^\n]',1);
        SubFolderName = cell2mat(A{1,1});
        clear A;
        if ~isempty(SubFolderName)
        SubFolderName = strcat(SubFolderName(1:5));
        
        Names = strcat(MainPath,FolderName,'\',SubFolderName,'\Outputs\Names.txt');
        Ns = fopen(Names,'r');
        Tnum=0;
        while ~(feof(Ns))
            A = textscan(Ns,'%[^\n]',1);
            FileName = cell2mat(A{1,1});
            textscan(Ns,'%[^\n]',1);
            clear A;
            if length(FileName)>1
                %Find T and EFileName
                %--------------------
                Tstr = FileName(18:23);
                T = str2num(Tstr);
                SubTitle = strcat(FolderName,'-',SubFolderName,'-',Tstr);
                EFileName = strcat(MainPath,FolderName,'\',SubFolderName,'\Outputs\DataToAnalyze\E-HBns-R\E-HBns-R',FileName,'.txt');
                %--------------------

                EFile = fopen(EFileName,'r');
                textscan(EFile,'%*[^\n]',1);

                % Reading Data from E File
                All = textscan(EFile,...
                    '%f %f %f %f %f %f %f %f %f %d %d %d %f %f %f %f %f %f %f %f %f %f %f %f %f',-1);
                Utot = All{1,7};        
                time = All{1,24};
                clear All;
                fclose(EFile);

                endtime = time(length(time))*1e6;       %seconds to microseconds
                Utot = Utot*T;       %KbT to eHB

                %Do what you want with Data
                %==========================
                Tnum = Tnum+1;
                CL(Tnum,1) = T;
                CL(Tnum,2) = 0; %corr length
                CL(Tnum,3) = 0; %gtau
                CL(Tnum,4) = length(time); %number of independant data
 
                for i= 0:100
                    Utotc = Utot(i+1:length(Utot));
                    cor=corrcoef(Utot(1:length(Utot)-i),Utotc(1:length(Utot)-i));
                    Y(i+1)=cor(1,2);
                end
                
               % CL(Tnum,2) = -1/log(Y(2));
                CL(Tnum,2) = mean([-1/log(Y(2)),-5/log(Y(6))]);
                if CL(Tnum,2)<1
                    CL(Tnum,2)=1;
                end
                CL(Tnum,3) = 1+2*CL(Tnum,2);
                CL(Tnum,4) = round(length(time)/CL(Tnum,2));
                
                figure;
                plot([1:101],Y,'-');
                ylim([-0.3 1]);
                title(SubTitle)
                print('-dpng',strcat(FigPath,'1-AutoCorrelation\Figs\',SubTitle,'.png'));
                close;
                clear Utot time Y;
                %==========================
            end
        end   
        fclose(Ns);
        xlswrite(strcat(FigPath,'1-AutoCorrelation\ExcelFiles\',FolderName,'.xls'),CL,SubFolderName);
        clear CL;
        end
    end
    fclose(FNsToRun);
end
fclose(FNs);