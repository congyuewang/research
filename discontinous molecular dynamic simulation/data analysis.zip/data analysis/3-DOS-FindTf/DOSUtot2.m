clear all;
clc;
MainPath = 'C:\Users\congyue wang\Documents\Visual Studio 2012\Projects\l=9_center_z\';
FigPath = 'C:\Users\congyue wang\Documents\Visual Studio 2012\Projects\l=9_center_z\data analysis\';

%Minimum time which should be cut from the begining of data, so that we can start data collection
MinTime = 5e-10;  %1e-8

%max num of simulated T for each FolderName
maxTnum=11;

FolderNames = strcat(FigPath,'FolderNames.txt');
FNs = fopen(FolderNames,'r');

while ~(feof(FNs))
    %-------------------------------
    A = textscan(FNs,'%[^\n]',1);
    FolderName = cell2mat(A{1,1});
    clear A;
    %-------------------------------

    n =str2double(FolderName(1:2));  %n
    eNPStrength =str2double(FolderName(4:8));  %eNP
    npsize =str2double(FolderName(10:14));  %h
    
    Ts(1:maxTnum)=0;
   

    A=xlsread(strcat(FigPath,'2-Tg\ExcelFiles\',FolderName,'.xls'),1);
    Ts=A(:,1);
    Ts_Accept=A(:,2);
    clear A;
 
    
    FolderNamesToRun = strcat(MainPath,FolderName,'\FolderNamesToRun.txt');
    FNsToRun = fopen(FolderNamesToRun,'r');
    
    FNsnum=0;
    while ~(feof(FNsToRun))
        A = textscan(FNsToRun,'%[^\n]',1);
        SubFolderName = cell2mat(A{1,1});
        clear A;
        if isempty(SubFolderName)
            break;
        else
            SubFolderName = strcat(SubFolderName(1:5));
        end
        
        FNsnum=FNsnum+1;
        if mod(FNsnum,2)==1
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            MinUtot = -(n-4+4*n*eNPStrength+round(n/6)+1);  %eHB,eNP,eHP
            MaxUtot = 0;
            dUtot = 1/4;
            nUtotHist = round((MaxUtot-MinUtot)/dUtot) + 1;
            dUtot = (MaxUtot-MinUtot)/(nUtotHist-1);
            UtotHist1(1:nUtotHist) = MinUtot:dUtot:MaxUtot;
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %{
            MineHB = -(n-4);
            MaxeHB = 0;
            deHB = 1;
            neHBHist = round((MaxeHB-MineHB)/deHB) + 1;
            deHB = (MaxeHB-MineHB)/(neHBHist-1);
            eHBHist1(1:neHBHist) = MineHB:deHB:MaxeHB;
            %}
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

            UtotHist(1:maxTnum,1:nUtotHist,1:2) = 0;
        end
        
        
        GTauscopy = xlsread(strcat(FigPath,'1-AutoCorrelation\ExcelFiles\',FolderName,'.xls'),SubFolderName,'A1:C30');
        GTaus(1:size(GTauscopy,1),1) = GTauscopy(1:size(GTauscopy,1),1);
        GTaus(1:size(GTauscopy,1),2) = GTauscopy(1:size(GTauscopy,1),3);
        clear GTauscopy;

        Names = strcat(MainPath,FolderName,'\',SubFolderName,'\Outputs\Names.txt');
        Ns = fopen(Names,'r');
        Tnum=0;
        
        while ~(feof(Ns))
            A = textscan(Ns,'%[^\n]',1);
            FileName = cell2mat(A{1,1});
            textscan(Ns,'%[^\n]',1);
            clear A;
            if length(FileName)>1

                %Find T and EFileName
                %--------------------
                Tstr = FileName(18:23);
                T = str2double(Tstr);
                Tnum = Tnum+1;
                if T~=Ts(Tnum)
                    'error on T'
                end
                %Ts(Tnum)=T;
                
                if Ts_Accept(Tnum)==1
                    %SubTitle = strcat(FolderName,'-',SubFolderName,'-',Tstr);
                    EFileName = strcat(MainPath,FolderName,'\',SubFolderName,'\Outputs\DataToAnalyze\E-HBns-R\E-HBns-R',FileName,'.txt');
                    %--------------------

                    EFile = fopen(EFileName,'r');
                    textscan(EFile,'%*[^\n]',1);

                    % Reading Data from E File
                    All = textscan(EFile,...
                        '%f %f %f %f %f %f %f %f %f %d %d %d %f %f %f %f %f %f %f %f %f %f %f %f %f',-1);
                    eHB = All{1,1};
                    eHP = All{1,4};
                    eNP = All{1,6};
                    Utot = All{1,7};
                    time = All{1,24};
                    clear All;
                    fclose(EFile);

                    %Don't consider first data in MinTime range
                    %------------------------------------------
                    if (time(1)<MinTime)
                        i=1;
                        while time(i)<MinTime
                            i=i+1;
                        end
                        Datalen = length(time);
                        time = time(i:Datalen);
                        Utot = Utot(i:Datalen);
                        eHB = eHB(i:Datalen);
                        eHP = eHP(i:Datalen);
                        eNP = eNP(i:Datalen);
                    end
                    %------------------------------------------

                    Datalen = length(time);

                    endtime = time(Datalen)*1e6;       %seconds to microseconds
                    Utot = Utot*T;       %KbT to eHB
                    eHB = eHB*T;       
                    eHP = eHP*T;       
                    eNP = eNP*T;       

                    %------------------------------------------
                    if (GTaus(Tnum,1)==T) 
                        gtau = GTaus(Tnum,2);
                    else
                        'Error on GTaus'
                        FolderName
                        SubFolderName
                        T
                        GTaus(Tnum,:)
                    end
                    %------------------------------------------

                    %Don't consider energies except than neHB, eHP and eNp
                    %------------------------------------------
                    for i=1:Datalen
                        Utot(i)=(eHB(i)+eHP(i)+eNP(i));
                    end
                    %------------------------------------------


                    %----------nAlpha----------%
                    for i=1:Datalen
                        Utoti=Utot(i);
                    end

                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    %Do what you want with Data
                    %==========================
                    i=1;
                    while i<=Datalen
                        %Utot
                        Ui = Utot(i);
                        UiHistNum = 1 + round((Ui-MinUtot)/dUtot);

                        if (UiHistNum<=nUtotHist)&(UiHistNum>=1)
                            UtotHist(Tnum,UiHistNum,1) = UtotHist(Tnum,UiHistNum,1)+1;                
                        elseif (UiHistNum<1)
                            beep;
                            S='Error on UiHistNum<min'
                            T
                            Ui
                        else
                            S='Error on UiHistNum>max'
                            beep;
                            T
                            Ui
                        end

                        %*%*%*%*%*%*%*%*%*%*%*%*%*%*%*%*%*%
                    end
                    %==========================

                    %Utot
                    UtotHist(Tnum,:,2) = sqrt(UtotHist(Tnum,:,1)*gtau);

                    clear eHB eHP eNP Utot UtotrestNP UtotrestBt UtotrestNA nAlpha nBeta nNonAlpha time;
                end
            end   %filname not empty
        end
        fclose(Ns);

    
if mod(FNsnum,2)==0
    
    realizationstr=SubFolderName(4:5);
    realization=str2double(SubFolderName(4:5));

    %find Tnum for unfinished runs
    Tnum=0;
    for i=1:length(Ts)
        if (Ts(i)>0) && (Ts_Accept(i)==1)
            Tnum=Tnum+1;
            Tscopy(Tnum)=Ts(i);
            Tindex(Tnum)=i;
        end
    end
    
%Utot
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    for counter=1:Tnum
        SumUtotHist(Tindex(counter)) = sum(UtotHist(Tindex(counter),:,1));
    end
    
    %This coefficient determines the method of WHAM (usual or that by Hall)
    %Coef(1:Tnum) = 1/SumUtotHist(1:Tnum);
    Coef(1:Tnum) = 1; 
    
    %----------------------------------------------------------------------
    %Initial Conditions
    f(1:Tnum)=0;
    expf(1:Tnum)=1;

    %Finding g_k from fs
    for k1=1:nUtotHist
        gkNum = 0;
        gkDen = 0;
        for nn=1:Tnum
            gkNum = gkNum + Coef(nn)/GTaus(Tindex(nn),2)*UtotHist(Tindex(nn),k1,1);
            gkDen = gkDen + Coef(nn)/GTaus(Tindex(nn),2)*SumUtotHist(Tindex(nn))*exp(-UtotHist1(k1)/Ts(Tindex(nn)))/expf(nn);
        end
        gk(k1) = gkNum/gkDen;
    end
    
    MaxfDiff = 1;
    %DOSAllxls
    ferror = 5e-5;
    while MaxfDiff > ferror
        lastf = f;
        lastexpf = expf;
        
        %finding f from g_k
        for nn=1:Tnum
            expf(nn)=0;
            for k1=1:nUtotHist
                expf(nn) = expf(nn) + exp(-UtotHist1(k1)/Ts(Tindex(nn))) * gk(k1);
            end
        end
        f=log(expf);

        %Finding g_k from fs
        for k1=1:nUtotHist
            gkNum = 0;
            gkDen = 0;
            for nn=1:Tnum
                gkNum = gkNum + Coef(nn)/GTaus(Tindex(nn),2)*UtotHist(Tindex(nn),k1,1);
                gkDen = gkDen + Coef(nn)/GTaus(Tindex(nn),2)*SumUtotHist(Tindex(nn))*exp(-UtotHist1(k1)/Ts(Tindex(nn)))/expf(nn);
            end
            gk(k1) = gkNum/gkDen;
        end
        
        %finding MaxfDiff
        for nn=1:Tnum
            X(nn) = abs(f(nn)-lastf(nn))/(f(nn)+lastf(nn));
        end
        MaxfDiff = max(X);

    end

    %Finding error of g_k 
    for k1=1:nUtotHist
        gkerror(k1)=0;
        %gkerrorNum=0;   gkerrorDen=0;
        for nn=1:Tnum
            gkerror(k1) = gkerror(k1) + Coef(nn)/GTaus(Tindex(nn),2)*UtotHist(Tindex(nn),k1,1);
            %if SumUtotHist(Tindex(nn))~=0
                %gkerrorNum = gkerrorNum + Coef(nn)/GTaus(Tindex(nn),2)*UtotHist(Tindex(nn),k1,1)/SumUtotHist(Tindex(nn));
                %gkerrorDen = gkerrorDen + Coef(nn)/GTaus(Tindex(nn),2)*UtotHist(Tindex(nn),k1,1);
            %end
        end
        if gkerror(k1)~=0
            gkerror(k1) = 1/sqrt(gkerror(k1))*gk(k1);
            %gkerror(k1) = sqrt(gkerrorNum)/gkerrorDen;
        else
            gkerror(k1)=0;
        end
    end
        
    %making the lowest amount of gk equal to one
    mingk = max(max(gk));
    for k1=1:nUtotHist
        if (gk(k1)>0)&(gk(k1)<mingk)
            mingk = gk(k1);
        end
    end

    %DOSAllxls
    gk = gk/mingk;
    gkerror = gkerror/mingk;
    expf = expf/mingk;
    f = f - log(mingk);
    
    xlswrite(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\Utot\',FolderName,'-',realizationstr,'_gk_Utot.xls'),nUtotHist,1,'a1');
    xlswrite(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\Utot\',FolderName,'-',realizationstr,'_gk_Utot.xls'),UtotHist1',1,'b1');
    xlswrite(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\Utot\',FolderName,'-',realizationstr,'_gk_Utot.xls'),gk',1,'c1');
    xlswrite(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\Utot\',FolderName,'-',realizationstr,'_gk_Utot.xls'),gkerror',1,'d1');

    xlswrite(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\Utot\',FolderName,'-',realizationstr,'_f_Utot.xls'),Tnum,1,'a1');
    xlswrite(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\Utot\',FolderName,'-',realizationstr,'_f_Utot.xls'),Ts',1,'b1');
    xlswrite(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\Utot\',FolderName,'-',realizationstr,'_f_Utot.xls'),f',1,'c1');

    %DOSAllxls
    
    
    
    %making figure
    %---------------------------------
    figure;
    plot(Tscopy(1:Tnum),f(1:Tnum),'o-');
    title(strcat(FolderName,'-',realizationstr,'-f-Utot'));
    %DOSAllxls
    print('-dpng',strcat(FigPath,'3-DOS-FindTf\Figs\Utot\',FolderName,'-',realizationstr,'_f_Utot.png'));
    close;

    figure;
    semilogy(UtotHist1,gk,'o');
    %plotting error
    hold on;
    semilogy(UtotHist1,(gk+gkerror),'rx');
    title(strcat(FolderName,'-',realizationstr,'-gk-Utot'));
    %DOSAllxls
    print('-dpng',strcat(FigPath,'3-DOS-FindTf\Figs\Utot\',FolderName,'-',realizationstr,'_gk_Utot.png'));
    close;
    %---------------------------------
    
 
  
    %close all;
    clear UtotHist Coef SumUtotHist lastf lastexpf gk gkerror X;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    


    clear UtotHist1 eNPHist1 UtotrestNPHist1 UtotrestBtHist1 UtotrestNAHist1 nAlphaHist1 nBetaHist1 nNonAlphaHist1 UtotHist nAlphaHist nAlphaeNPHist nAlphanBetaHist nAlphanNonAlphaHist;
end    

    end
    fclose(FNsToRun);
    disp(FolderName);

end
fclose(FNs);


