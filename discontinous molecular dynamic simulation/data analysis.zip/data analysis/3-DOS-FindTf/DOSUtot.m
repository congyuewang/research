clear all;
clc;
MainPath = 'C:\Users\congyue wang\Documents\Visual Studio 2012\Projects\l=9_center_z\';
FigPath = 'C:\Users\congyue wang\Documents\Visual Studio 2012\Projects\l=9_center_z\data analysis\';

%Minimum time which should be cut from the begining of data, so that we can start data collection
MinTime = 5e-10;  %5e-10

%max num of simulated T for each FolderName
maxTnum=12;

FolderNames = strcat(FigPath,'FolderNames.txt');
FNs = fopen(FolderNames,'r');

while ~(feof(FNs))
    %-------------------------------
    A = textscan(FNs,'%[^\n]',1);
    FolderName = cell2mat(A{1,1});
    clear A;
    %-------------------------------

    n =str2double(FolderName(1:2));  %n
    eNPStrength =str2double(FolderName(4:8));  %eNP
    npsize =str2double(FolderName(10:14));  %h
    
    Ts(1:maxTnum)=0;
   

    A=xlsread(strcat(FigPath,'2-Tg\ExcelFiles\',FolderName,'.xls'),1);
    Ts=A(:,1);
    Ts_Accept=A(:,2);
    clear A;
 
    
    FolderNamesToRun = strcat(MainPath,FolderName,'\FolderNamesToRun.txt');
    FNsToRun = fopen(FolderNamesToRun,'r');
    
    FNsnum=0;
    while ~(feof(FNsToRun))
        A = textscan(FNsToRun,'%[^\n]',1);
        SubFolderName = cell2mat(A{1,1});
        clear A;
        if isempty(SubFolderName)
            break;
        else
            SubFolderName = strcat(SubFolderName(1:5));
        end
        
        FNsnum=FNsnum+1;
        if mod(FNsnum,2)==1
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            MinUtot = -(n-4+4*n*eNPStrength+round(n/6)+1);  %eHB,eNP,eHP
            MaxUtot = 0;
            dUtot = 1/4;
            nUtotHist = round((MaxUtot-MinUtot)/dUtot) + 1;
            dUtot = (MaxUtot-MinUtot)/(nUtotHist-1);
            UtotHist1(1:nUtotHist) = MinUtot:dUtot:MaxUtot;
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            MineNP = -4*n*eNPStrength;
            MaxeNP = 0;
            deNP = 1/4;
            neNPHist = round((MaxeNP-MineNP)/deNP) + 1;
            deNP = (MaxeNP-MineNP)/(neNPHist-1);
            eNPHist1(1:neNPHist) = MineNP:deNP:MaxeNP;
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %{
            MineHB = -(n-4);
            MaxeHB = 0;
            deHB = 1;
            neHBHist = round((MaxeHB-MineHB)/deHB) + 1;
            deHB = (MaxeHB-MineHB)/(neHBHist-1);
            eHBHist1(1:neHBHist) = MineHB:deHB:MaxeHB;
            %}
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            MinUtotrestNP = -(round(n/2)+1+round(n/6)+1);
            MaxUtotrestNP = 0;
            dUtotrestNP = 0.5;
            nUtotrestNPHist = round((MaxUtotrestNP-MinUtotrestNP)/dUtotrestNP) + 1;
            dUtotrestNP = (MaxUtotrestNP-MinUtotrestNP)/(nUtotrestNPHist-1);
            UtotrestNPHist1(1:nUtotrestNPHist) = MinUtotrestNP:dUtotrestNP:MaxUtotrestNP;
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            MinUtotrestBt = -(round(n/2)+1+4*n*eNPStrength+round(n/6)+1);  %considers eHP=eHB/6
            MaxUtotrestBt = 0;
            dUtotrestBt = 0.5;
            nUtotrestBtHist = round((MaxUtotrestBt-MinUtotrestBt)/dUtotrestBt) + 1;
            dUtotrestBt = (MaxUtotrestBt-MinUtotrestBt)/(nUtotrestBtHist-1);
            UtotrestBtHist1(1:nUtotrestBtHist) = MinUtotrestBt:dUtotrestBt:MaxUtotrestBt;
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            MinUtotrestNA = -(4*n*eNPStrength+round(n/6)+1);
            MaxUtotrestNA = 0;
            dUtotrestNA = 0.5;
            nUtotrestNAHist = round((MaxUtotrestNA-MinUtotrestNA)/dUtotrestNA) + 1;
            dUtotrestNA = (MaxUtotrestNA-MinUtotrestNA)/(nUtotrestNAHist-1);
            UtotrestNAHist1(1:nUtotrestNAHist) = MinUtotrestNA:dUtotrestNA:MaxUtotrestNA;
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            MinnAlpha = 0;
            MaxnAlpha = n-4;
            dnAlpha = 1;
            nnAlphaHist = round((MaxnAlpha-MinnAlpha)/dnAlpha) + 1;
            dnAlpha = (MaxnAlpha-MinnAlpha)/(nnAlphaHist-1);
            nAlphaHist1(1:nnAlphaHist) = MinnAlpha:dnAlpha:MaxnAlpha;
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            MinnBeta = 0;
            MaxnBeta = round(n/2)-1;
            dnBeta = 1;
            nnBetaHist = round((MaxnBeta-MinnBeta)/dnBeta) + 1;
            dnBeta = (MaxnBeta-MinnBeta)/(nnBetaHist-1);
            nBetaHist1(1:nnBetaHist) = MinnBeta:dnBeta:MaxnBeta;
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            MinnNonAlpha = 0;      %nonAlpha
            MaxnNonAlpha = round(n/2)-1;
            dnNonAlpha = 1;
            nnNonAlphaHist = round((MaxnNonAlpha-MinnNonAlpha)/dnNonAlpha) + 1;
            dnNonAlpha = (MaxnNonAlpha-MinnNonAlpha)/(nnNonAlphaHist-1);
            nNonAlphaHist1(1:nnNonAlphaHist) = MinnNonAlpha:dnNonAlpha:MaxnNonAlpha;
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

            UtotHist(1:maxTnum,1:nUtotHist,1:2) = 0;
            nAlphaHist(1:maxTnum,1:nnAlphaHist,1:nUtotHist,1:2) = 0;
            nBetaHist(1:maxTnum,1:nnBetaHist,1:nUtotHist,1:2) = 0;
            nNonAlphaHist(1:maxTnum,1:nnNonAlphaHist,1:nUtotHist,1:2) = 0;
            %*%*%*%*%*%*%*%*%*%*%*%*%*%*%*%*%*%
            nAlphaeNPHist(1:maxTnum,1:nnAlphaHist,1:neNPHist,1:nUtotrestNPHist,1:2) = 0;
            nAlphanBetaHist(1:maxTnum,1:nnAlphaHist,1:nnBetaHist,1:nUtotrestBtHist,1:2) = 0;
            nAlphanNonAlphaHist(1:maxTnum,1:nnAlphaHist,1:nnNonAlphaHist,1:nUtotrestNAHist,1:2) = 0;
            %*%*%*%*%*%*%*%*%*%*%*%*%*%*%*%*%*%
        end
        
        
        GTauscopy = xlsread(strcat(FigPath,'1-AutoCorrelation\ExcelFiles\',FolderName,'.xls'),SubFolderName,'A1:C30');
        GTaus(1:size(GTauscopy,1),1) = GTauscopy(1:size(GTauscopy,1),1);
        GTaus(1:size(GTauscopy,1),2) = GTauscopy(1:size(GTauscopy,1),3);
        clear GTauscopy;

        Names = strcat(MainPath,FolderName,'\',SubFolderName,'\Outputs\Names.txt');
        Ns = fopen(Names,'r');
        Tnum=0;
        
        while ~(feof(Ns))
            A = textscan(Ns,'%[^\n]',1);
            FileName = cell2mat(A{1,1});
            textscan(Ns,'%[^\n]',1);
            clear A;
            if length(FileName)>1

                %Find T and EFileName
                %--------------------
                Tstr = FileName(18:23);
                T = str2double(Tstr);
                Tnum = Tnum+1;
                if T~=Ts(Tnum)
                    'error on T'
                end
                %Ts(Tnum)=T;
                
                if Ts_Accept(Tnum)==1
                    %SubTitle = strcat(FolderName,'-',SubFolderName,'-',Tstr);
                    EFileName = strcat(MainPath,FolderName,'\',SubFolderName,'\Outputs\DataToAnalyze\E-HBns-R\E-HBns-R',FileName,'.txt');
                    %--------------------

                    EFile = fopen(EFileName,'r');
                    textscan(EFile,'%*[^\n]',1);

                    % Reading Data from E File
                    All = textscan(EFile,...
                        '%f %f %f %f %f %f %f %f %f %d %d %d %f %f %f %f %f %f %f %f %f %f %f %f %f',-1);
                    eHB = All{1,1};
                    eHP = All{1,4};
                    eNP = All{1,6};
                    Utot = All{1,7};
                    nAlpha = All{1,9};
                    nBeta = All{1,10};
                    nHBtot = All{1,11};
                    time = All{1,24};
                    clear All;
                    fclose(EFile);

                    %Don't consider first data in MinTime range
                    %------------------------------------------
                    if (time(1)<MinTime)
                        i=1;
                        while time(i)<MinTime
                            i=i+1;
                        end
                        Datalen = length(time);
                        time = time(i:Datalen);
                        Utot = Utot(i:Datalen);
                        eHB = eHB(i:Datalen);
                        eHP = eHP(i:Datalen);
                        eNP = eNP(i:Datalen);
                        nAlpha = nAlpha(i:Datalen);
                        nBeta = nBeta(i:Datalen);
                        nHBtot = nHBtot(i:Datalen);
                    end
                    %------------------------------------------

                    Datalen = length(time);

                    endtime = time(Datalen)*1e6;       %seconds to microseconds
                    Utot = Utot*T;       %KbT to eHB
                    eHB = eHB*T;       
                    eHP = eHP*T;       
                    eNP = eNP*T;       

                    %------------------------------------------
                    if (GTaus(Tnum,1)==T) 
                        gtau = GTaus(Tnum,2);
                    else
                        'Error on GTaus'
                        FolderName
                        SubFolderName
                        T
                        GTaus(Tnum,:)
                    end
                    %------------------------------------------

                    %Don't consider energies except than neHB, eHP and eNp
                    %------------------------------------------
                    for i=1:Datalen
                        Utot(i)=(eHB(i)+eHP(i)+eNP(i));
                    end
                    %------------------------------------------


                    %----------nAlpha----------%
                    for i=1:Datalen
                        nOther(i) = nHBtot(i)-nBeta(i)-nAlpha(i);
                    end
                    %nOther = nHBtot-nBeta-nAlpha;
                    %Correct number of Hydrogen Bonds
                    %------------------------------------------
                    for i=1:Datalen
                        eHBi = eHB(i);
                        nHBtoti = nHBtot(i);
                        nAlphai = nAlpha(i);
                        nBetai = nBeta(i);
                        nOtheri = nOther(i);
                        TrueN = int32(-eHBi);
                        if TrueN~=nHBtoti
                            diff = TrueN-nHBtoti;
                            if diff<0
                                if (nOtheri>0)
                                     nOther(i) = max(nOtheri+diff,0);
                                     diff = diff + nOtheri - nOther(i);
                                end
                                if (nBetai>0)
                                    nBeta(i) = max(nBetai+diff,0);
                                    diff = diff + nBetai - nBeta(i);
                                end
                                if (nAlphai>0)
                                    nAlpha(i) = max(nAlphai+diff,0);
                                    diff = diff + nAlphai - nAlpha(i);
                                end
                                if (diff~=0)
                                    S='Error on TrueN'
                                    FolderName
                                    SubFolderName
                                    T
                                    i
                                    Tnum
                                    eHBi
                                    nHBtoti
                                    nAlphai
                                    nBetai
                                    nOtheri
                                    TrueN
                                end
                            else
                                nAlpha(i) = min(nAlphai+diff,MaxnAlpha);
                                diff = diff + nAlphai - nAlpha(i);

                                nBeta(i) = min(nBetai+diff,MaxnBeta);
                                diff = diff + nBetai - nBeta(i);

                                nOther(i) = min(nOtheri+diff,MaxnBeta);
                                diff = diff + nOtheri - nOther(i);


                                if (diff~=0)
                                    S='Error on TrueN'
                                    FolderName
                                    SubFolderName
                                    T
                                    i
                                    Tnum
                                    eHBi
                                    nHBtoti
                                    nAlphai
                                    nBetai
                                    nOtheri
                                    TrueN
                                end
                            end

                            nHBtot(i) = nAlpha(i)+nBeta(i)+nOther(i);

                            if (nAlpha(i)<0)|(nBeta(i)<0)|(nOther(i)<0)|(nAlpha(i)>MaxnAlpha)
                                S='Error on correcting'
                                FolderName
                                SubFolderName
                                T
                                i
                                Tnum
                                eHBi
                                nHBtot(i)
                                nAlpha(i)
                                nBeta(i)
                                nOther(i)
                                TrueN
                            end
                        end
                        if TrueN~=nHBtot(i)
                            S='Error on correcting nHBtot.'
                            FolderName
                            SubFolderName
                            T
                            i
                            Tnum
                            eHBi
                            nHBtot(i)
                            nAlpha(i)
                            nBeta(i)
                            nOther(i)
                            TrueN
                        end
                    end

                    for i=1:Datalen
                        nNonAlpha(i) = nHBtot(i)-nAlpha(i);
                    end

                    clear nHBtot nOther;
                    %----------nAlpha----------%

                    for i=1:Datalen
                        nAlphai=nAlpha(i);
                        Utoti=Utot(i);
                        UtotrestNP(i) = Utoti-eNP(i)+double(nAlphai);
                        UtotrestBt(i) = Utoti+double(nAlphai)+double(nBeta(i));
                        UtotrestNA(i) = Utoti+double(nAlphai)+double(nNonAlpha(i));
                    end

                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    %Do what you want with Data
                    %==========================
                    i=1;
                    while i<=Datalen
                        %Utot
                        Ui = Utot(i);
                        UiHistNum = 1 + round((Ui-MinUtot)/dUtot);
                        %nAlpha
                        nAlphai = nAlpha(i);
                        nAlphaiHistNum = 1 + round((nAlphai-MinnAlpha)/dnAlpha);
                        %nBeta
                        nBetai = nBeta(i);
                        nBetaiHistNum = 1 + round((nBetai-MinnBeta)/dnBeta);
                        %nNonAlpha
                        nNonAlphai = nNonAlpha(i);
                        nNonAlphaiHistNum = 1 + round((nNonAlphai-MinnNonAlpha)/dnNonAlpha);
                        %eNP
                        eNPi = eNP(i);
                        eNPiHistNum = 1 + round((eNPi-MineNP)/deNP);
                        %UtotrestNP
                        UrestNPi = UtotrestNP(i);
                        UrestNPiHistNum = 1 + round((UrestNPi-MinUtotrestNP)/dUtotrestNP);
                        %UtotrestBt
                        UrestBti = UtotrestBt(i);
                        UrestBtiHistNum = 1 + round((UrestBti-MinUtotrestBt)/dUtotrestBt);
                        %UtotrestNA
                        UrestNAi = UtotrestNA(i);
                        UrestNAiHistNum = 1 + round((UrestNAi-MinUtotrestNA)/dUtotrestNA);

                        if (UiHistNum<=nUtotHist)&(UiHistNum>=1)
                            UtotHist(Tnum,UiHistNum,1) = UtotHist(Tnum,UiHistNum,1)+1;                
                            %nAlpha
                            if (nAlphaiHistNum<=nnAlphaHist)&(nAlphaiHistNum>=1)
                                nAlphaHist(Tnum,nAlphaiHistNum,UiHistNum,1) = nAlphaHist(Tnum,nAlphaiHistNum,UiHistNum,1)+1;                
                            elseif (nAlphaiHistNum<1)
                                beep;
                                S='Error on nAlphaiHistNum<min'
                                Tnum
                                nAlphai
                            else
                                beep;
                                S='Error on nAlphaiHistNum>max'
                                Tnum
                                nAlphai
                            end
                            %nBeta
                            if (nBetaiHistNum<=nnBetaHist)&(nBetaiHistNum>=1)
                                nBetaHist(Tnum,nBetaiHistNum,UiHistNum,1) = nBetaHist(Tnum,nBetaiHistNum,UiHistNum,1)+1;                
                            elseif (nBetaiHistNum<1)
                                beep;
                                S='Error on nBetaiHistNum<min'
                                Tnum
                                nBetai
                            elseif (nBetaiHistNum>nnBetaHist)
                                beep;
                                S='Error on nBetaiHistNum>max'
                                Tnum
                                nBetai
                            end
                            %nNonAlpha
                            if (nNonAlphaiHistNum<=nnNonAlphaHist)&(nNonAlphaiHistNum>=1)
                                nNonAlphaHist(Tnum,nNonAlphaiHistNum,UiHistNum,1) = nNonAlphaHist(Tnum,nNonAlphaiHistNum,UiHistNum,1)+1;                
                            elseif (nNonAlphaiHistNum<1)
                                beep;
                                S='Error on nNonAlphaiHistNum<min'
                                Tnum
                                nNonAlphai
                            elseif (nNonAlphaiHistNum>nnNonAlphaHist)
                                beep;
                                S='Error on nNonAlphaiHistNum>max'
                                Tnum
                                nNonAlphai
                            end
                            %eNP
                            if (eNPiHistNum<1)
                                beep;
                                S='Error on eNPiHistNum<min'
                                Tnum
                                eNPi
                            elseif(eNPiHistNum>neNPHist)
                                beep;
                                S='Error on eNPiHistNum>max'
                                Tnum
                                eNPi
                            end
                            %UtotrestNP 
                            if (UrestNPiHistNum<1)
                                beep;
                                S='Error on UrestNPiHistNum<min'
                                Tnum
                                UrestNPi
                                nAlphai
                                eNPi
                            elseif(UrestNPiHistNum>nUtotrestNPHist)
                                beep;
                                S='Error on UrestNPiHistNum>max'
                                Tnum
                                UrestNPi
                                nAlphai
                                eNPi
                           end
                            %UtotrestBt 
                            if (UrestBtiHistNum<1)
                                beep;
                                S='Error on UrestBtiHistNum<min'
                                Tnum
                                UrestBti
                                nAlphai
                                nBetai
                            elseif(UrestBtiHistNum>nUtotrestBtHist)
                                beep;
                                S='Error on UrestBtiHistNum>max'
                                Tnum
                                UrestBti
                                nAlphai
                                nBetai
                           end
                            %UtotrestNA 
                            if (UrestNAiHistNum<1)
                                beep;
                                S='Error on UrestNAiHistNum<min'
                                Tnum
                                UrestNAi
                                nAlphai
                                nNonAlphai
                            elseif(UrestNAiHistNum>nUtotrestNAHist)
                                beep;
                                S='Error on UrestNAiHistNum>max'
                                Tnum
                                UrestNAi
                                nAlphai
                                nNonAlphai
                           end
                           %*%*%*%*%*%*%*%*%*%*%*%*%*%*%*%*%*%
                            %nAlphaeNP  :  Below
                            %*%*%*%*%*%*%*%*%*%*%*%*%*%*%*%*%*%
                        elseif (UiHistNum<1)
                            beep;
                            S='Error on UiHistNum<min'
                            T
                            Ui
                        else
                            S='Error on UiHistNum>max'
                            beep;
                            T
                            Ui
                        end

                        %*%*%*%*%*%*%*%*%*%*%*%*%*%*%*%*%*%
                        %nAlphaeNP
                        if eNPStrength~=0
                            nAlphaeNPHist(Tnum,nAlphaiHistNum,eNPiHistNum,UrestNPiHistNum,1) = nAlphaeNPHist(Tnum,nAlphaiHistNum,eNPiHistNum,UrestNPiHistNum,1)+1;                
                        end
                        nAlphanBetaHist(Tnum,nAlphaiHistNum,nBetaiHistNum,UrestBtiHistNum,1) = nAlphanBetaHist(Tnum,nAlphaiHistNum,nBetaiHistNum,UrestBtiHistNum,1)+1;
                        nAlphanNonAlphaHist(Tnum,nAlphaiHistNum,nNonAlphaiHistNum,UrestNAiHistNum,1) = nAlphanNonAlphaHist(Tnum,nAlphaiHistNum,nNonAlphaiHistNum,UrestNAiHistNum,1)+1;
                        %*%*%*%*%*%*%*%*%*%*%*%*%*%*%*%*%*%
                        i=i+1;
                    end
                    %==========================

                    %Utot
                    UtotHist(Tnum,:,2) = sqrt(UtotHist(Tnum,:,1)*gtau);
                    %nAlpha
                    nAlphaHist(Tnum,:,:,2) = sqrt(nAlphaHist(Tnum,:,:,1)*gtau);
                    %nBeta
                    nBetaHist(Tnum,:,:,2) = sqrt(nBetaHist(Tnum,:,:,1)*gtau);
                    %nNonAlpha
                    nNonAlphaHist(Tnum,:,:,2) = sqrt(nNonAlphaHist(Tnum,:,:,1)*gtau);
                    %*%*%*%*%*%*%*%*%*%*%*%*%*%*%*%*%*%
                    %nAlphaeNP
                    if eNPStrength~=0
                        nAlphaeNPHist(Tnum,:,:,:,2) = sqrt(nAlphaeNPHist(Tnum,:,:,:,1)*gtau);
                    end
                    nAlphanBetaHist(Tnum,:,:,:,2) = sqrt(nAlphanBetaHist(Tnum,:,:,:,1)*gtau);
                    nAlphanNonAlphaHist(Tnum,:,:,:,2) = sqrt(nAlphanNonAlphaHist(Tnum,:,:,:,1)*gtau);
                    %*%*%*%*%*%*%*%*%*%*%*%*%*%*%*%*%*%

                    clear eHB eHP eNP Utot UtotrestNP UtotrestBt UtotrestNA nAlpha nBeta nNonAlpha time;
                end
            end   %filname not empty
        end
        fclose(Ns);

    
if mod(FNsnum,2)==0
    
    realizationstr=SubFolderName(4:5);
    realization=str2double(SubFolderName(4:5));

    %find Tnum for unfinished runs
    Tnum=0;
    for i=1:length(Ts)
        if (Ts(i)>0) && (Ts_Accept(i)==1)
            Tnum=Tnum+1;
            Tscopy(Tnum)=Ts(i);
            Tindex(Tnum)=i;
        end
    end
    
%Utot
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    for counter=1:Tnum
        SumUtotHist(Tindex(counter)) = sum(UtotHist(Tindex(counter),:,1));
    end
    
    %This coefficient determines the method of WHAM (usual or that by Hall)
    %Coef(1:Tnum) = 1/SumUtotHist(1:Tnum);
    Coef(1:Tnum) = 1; 
    
    %----------------------------------------------------------------------
    %Initial Conditions
    f(1:Tnum)=0;
    expf(1:Tnum)=1;

    %Finding g_k from fs
    for k1=1:nUtotHist
        gkNum = 0;
        gkDen = 0;
        for nn=1:Tnum
            gkNum = gkNum + Coef(nn)/GTaus(Tindex(nn),2)*UtotHist(Tindex(nn),k1,1);
            gkDen = gkDen + Coef(nn)/GTaus(Tindex(nn),2)*SumUtotHist(Tindex(nn))*exp(-UtotHist1(k1)/Ts(Tindex(nn)))/expf(nn);
        end
        gk(k1) = gkNum/gkDen;
    end
    
    MaxfDiff = 1;
    %DOSAllxls
    ferror = 5e-5;
    while MaxfDiff > ferror
        lastf = f;
        lastexpf = expf;
        
        %finding f from g_k
        for nn=1:Tnum
            expf(nn)=0;
            for k1=1:nUtotHist
                expf(nn) = expf(nn) + exp(-UtotHist1(k1)/Ts(Tindex(nn))) * gk(k1);
            end
        end
        f=log(expf);

        %Finding g_k from fs
        for k1=1:nUtotHist
            gkNum = 0;
            gkDen = 0;
            for nn=1:Tnum
                gkNum = gkNum + Coef(nn)/GTaus(Tindex(nn),2)*UtotHist(Tindex(nn),k1,1);
                gkDen = gkDen + Coef(nn)/GTaus(Tindex(nn),2)*SumUtotHist(Tindex(nn))*exp(-UtotHist1(k1)/Ts(Tindex(nn)))/expf(nn);
            end
            gk(k1) = gkNum/gkDen;
        end
        
        %finding MaxfDiff
        for nn=1:Tnum
            X(nn) = abs(f(nn)-lastf(nn))/(f(nn)+lastf(nn));
        end
        MaxfDiff = max(X);

    end

    %Finding error of g_k 
    for k1=1:nUtotHist
        gkerror(k1)=0;
        %gkerrorNum=0;   gkerrorDen=0;
        for nn=1:Tnum
            gkerror(k1) = gkerror(k1) + Coef(nn)/GTaus(Tindex(nn),2)*UtotHist(Tindex(nn),k1,1);
            %if SumUtotHist(Tindex(nn))~=0
                %gkerrorNum = gkerrorNum + Coef(nn)/GTaus(Tindex(nn),2)*UtotHist(Tindex(nn),k1,1)/SumUtotHist(Tindex(nn));
                %gkerrorDen = gkerrorDen + Coef(nn)/GTaus(Tindex(nn),2)*UtotHist(Tindex(nn),k1,1);
            %end
        end
        if gkerror(k1)~=0
            gkerror(k1) = 1/sqrt(gkerror(k1))*gk(k1);
            %gkerror(k1) = sqrt(gkerrorNum)/gkerrorDen;
        else
            gkerror(k1)=0;
        end
    end
        
    %making the lowest amount of gk equal to one
    mingk = max(max(gk));
    for k1=1:nUtotHist
        if (gk(k1)>0)&(gk(k1)<mingk)
            mingk = gk(k1);
        end
    end

    %DOSAllxls
    gk = gk/mingk;
    gkerror = gkerror/mingk;
    expf = expf/mingk;
    f = f - log(mingk);
    
    xlswrite(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\Utot\',FolderName,'-',realizationstr,'_gk_Utot.xls'),nUtotHist,1,'a1');
    xlswrite(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\Utot\',FolderName,'-',realizationstr,'_gk_Utot.xls'),UtotHist1',1,'b1');
    xlswrite(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\Utot\',FolderName,'-',realizationstr,'_gk_Utot.xls'),gk',1,'c1');
    xlswrite(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\Utot\',FolderName,'-',realizationstr,'_gk_Utot.xls'),gkerror',1,'d1');

    xlswrite(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\Utot\',FolderName,'-',realizationstr,'_f_Utot.xls'),Tnum,1,'a1');
    xlswrite(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\Utot\',FolderName,'-',realizationstr,'_f_Utot.xls'),Ts',1,'b1');
    xlswrite(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\Utot\',FolderName,'-',realizationstr,'_f_Utot.xls'),f',1,'c1');

    %DOSAllxls
    
    
    %{
    %making figure
    %---------------------------------
    figure;
    plot(Tscopy(1:Tnum),f(1:Tnum),'o-');
    title(strcat(FolderName,'-',realizationstr,'-f-Utot'));
    %DOSAllxls
    print('-dpng',strcat(FigPath,'3-DOS-FindTf\Figs\Utot\',FolderName,'-',realizationstr,'_f_Utot.png'));
    close;

    figure;
    semilogy(UtotHist1,gk,'o');
    %plotting error
    hold on;
    semilogy(UtotHist1,(gk+gkerror),'rx');
    title(strcat(FolderName,'-',realizationstr,'-gk-Utot'));
    %DOSAllxls
    print('-dpng',strcat(FigPath,'3-DOS-FindTf\Figs\Utot\',FolderName,'-',realizationstr,'_gk_Utot.png'));
    close;
    %---------------------------------
    %}
 
  
    %close all;
    clear UtotHist Coef SumUtotHist lastf lastexpf gk gkerror X;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    

%nAlpha
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    for counter=1:Tnum
        SumnAlphaHist(Tindex(counter)) = sum(sum(nAlphaHist(Tindex(counter),:,:,1)));
    end
    
    %This coefficient determines the method of WHAM (usual or that by Hall)
    %Coef(1:Tnum) = 1/SumnAlphaHist(1:Tnum);
    Coef(1:Tnum) = 1; 
    
    %----------------------------------------------------------------------
    %Finding g_k from fs
    for k1=1:nnAlphaHist
        for k2=1:nUtotHist
            gkNum = 0;
            gkDen = 0;
            for nn=1:Tnum
                gkNum = gkNum + Coef(nn)/GTaus(Tindex(nn),2)*nAlphaHist(Tindex(nn),k1,k2,1);
                gkDen = gkDen + Coef(nn)/GTaus(Tindex(nn),2)*SumnAlphaHist(Tindex(nn))*exp(-UtotHist1(k2)/Ts(Tindex(nn)))/expf(nn);
            end
            gk(k1,k2) = gkNum/gkDen;
        end
    end
    
    %Finding error of g_k 
    for k1=1:nnAlphaHist
        for k2=1:nUtotHist
            gkerror(k1,k2)=0;
            %gkerrorNum=0;   gkerrorDen=0;
            for nn=1:Tnum
                gkerror(k1,k2) = gkerror(k1,k2) + Coef(nn)/GTaus(Tindex(nn),2)*nAlphaHist(Tindex(nn),k1,k2,1);
                %if SumnAlphaHist(Tindex(nn))~=0
                    %gkerrorNum = gkerrorNum + Coef(nn)/GTaus(Tindex(nn),2)*nAlphaHist(Tindex(nn),k1,k2,1)/SumnAlphaHist(Tindex(nn));
                    %gkerrorDen = gkerrorDen + Coef(nn)/GTaus(Tindex(nn),2)*nAlphaHist(Tindex(nn),k1,k2,1);
                %end
            end
            if gkerror(k1,k2)~=0
                gkerror(k1,k2) = 1/sqrt(gkerror(k1,k2))*gk(k1,k2);
                %gkerror(k1,k2) = sqrt(gkerrorNum)/gkerrorDen;
            else
                gkerror(k1,k2)=0;
            end
        end
    end
        
    %making the lowest amount of gk equal to one
    mingk = max(max(gk));
    for k1=1:nnAlphaHist
        for k2=1:nUtotHist
            if (gk(k1,k2)>0)&(gk(k1,k2)<mingk)
                mingk = gk(k1,k2);
            end
        end
    end

    gk = gk/mingk;
    gkerror = gkerror/mingk;
    
    xlswrite(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\nAlpha\',FolderName,'-',realizationstr,'_gk_nAlpha.xls'),nnAlphaHist,1,'a1');
    xlswrite(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\nAlpha\',FolderName,'-',realizationstr,'_gk_nAlpha.xls'),nUtotHist,1,'a2');
    xlswrite(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\nAlpha\',FolderName,'-',realizationstr,'_gk_nAlpha.xls'),nAlphaHist1',1,'b1');
    xlswrite(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\nAlpha\',FolderName,'-',realizationstr,'_gk_nAlpha.xls'),UtotHist1',1,'c1');
    xlswrite(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\nAlpha\',FolderName,'-',realizationstr,'_gk_nAlpha.xls'),gk',1,'d1');
    xlswrite(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\nAlpha\',FolderName,'-',realizationstr,'_gk_nAlpha.xls'),gkerror',2,'d1');

    %{
    %making figure
    %---------------------------------
    figure;
    Z(1:nnAlphaHist,1:nUtotHist) = log(gk(1:nnAlphaHist,1:nUtotHist));
    surfc(UtotHist1,nAlphaHist1,Z);
    alpha(0.3);
    %plotting error
    Zerror(1:nnAlphaHist,1:nUtotHist) = log(gk(1:nnAlphaHist,1:nUtotHist)+gkerror(1:nnAlphaHist,1:nUtotHist));
    hold on;
    surfc(UtotHist1,nAlphaHist1,Zerror);
    alpha(0.3);
    clear Z Zerror;
    title(strcat(FolderName,'-',realizationstr,'-nAlpha'));
    print('-dpng',strcat(FigPath,'3-DOS-FindTf\Figs\nAlpha\',FolderName,'-',realizationstr,'_gkerr_nAlpha.png'));
    close;
    %---------------------------------
    %}
 
    
    clear nAlphaHist Coef SumnAlphaHist gk gkerror;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    

%nBeta
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    for counter=1:Tnum
        SumnBetaHist(Tindex(counter)) = sum(sum(nBetaHist(Tindex(counter),:,:,1)));
    end
    
    %This coefficient determines the method of WHAM (usual or that by Hall)
    %Coef(1:Tnum) = 1/SumnBetaHist(1:Tnum);
    Coef(1:Tnum) = 1; 
    
    %----------------------------------------------------------------------
    %Finding g_k from fs
    for k1=1:nnBetaHist
        for k2=1:nUtotHist
            gkNum = 0;
            gkDen = 0;
            for nn=1:Tnum
                gkNum = gkNum + Coef(nn)/GTaus(Tindex(nn),2)*nBetaHist(Tindex(nn),k1,k2,1);
                gkDen = gkDen + Coef(nn)/GTaus(Tindex(nn),2)*SumnBetaHist(Tindex(nn))*exp(-UtotHist1(k2)/Ts(Tindex(nn)))/expf(nn);
            end
            gk(k1,k2) = gkNum/gkDen;
        end
    end
    
    %Finding error of g_k 
    for k1=1:nnBetaHist
        for k2=1:nUtotHist
            gkerror(k1,k2)=0;
            %gkerrorNum=0;   gkerrorDen=0;
            for nn=1:Tnum
                gkerror(k1,k2) = gkerror(k1,k2) + Coef(nn)/GTaus(Tindex(nn),2)*nBetaHist(Tindex(nn),k1,k2,1);
                %if SumnBetaHist(Tindex(nn))~=0
                    %gkerrorNum = gkerrorNum + Coef(nn)/GTaus(Tindex(nn),2)*nBetaHist(Tindex(nn),k1,k2,1)/SumnBetaHist(Tindex(nn));
                    %gkerrorDen = gkerrorDen + Coef(nn)/GTaus(Tindex(nn),2)*nBetaHist(Tindex(nn),k1,k2,1);
                %end
            end
            if gkerror(k1,k2)~=0
                gkerror(k1,k2) = 1/sqrt(gkerror(k1,k2))*gk(k1,k2);
                %gkerror(k1,k2) = sqrt(gkerrorNum)/gkerrorDen;
            else
                gkerror(k1,k2)=0;
            end
        end
    end
        
    %making the lowest amount of gk equal to one
    mingk = max(max(gk));
    for k1=1:nnBetaHist
        for k2=1:nUtotHist
            if (gk(k1,k2)>0)&(gk(k1,k2)<mingk)
                mingk = gk(k1,k2);
            end
        end
    end

    gk = gk/mingk;
    gkerror = gkerror/mingk;
    
    xlswrite(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\nBeta\',FolderName,'-',realizationstr,'_gk_nBeta.xls'),nnBetaHist,1,'a1');
    xlswrite(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\nBeta\',FolderName,'-',realizationstr,'_gk_nBeta.xls'),nUtotHist,1,'a2');
    xlswrite(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\nBeta\',FolderName,'-',realizationstr,'_gk_nBeta.xls'),nBetaHist1',1,'b1');
    xlswrite(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\nBeta\',FolderName,'-',realizationstr,'_gk_nBeta.xls'),UtotHist1',1,'c1');
    xlswrite(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\nBeta\',FolderName,'-',realizationstr,'_gk_nBeta.xls'),gk',1,'d1');
    xlswrite(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\nBeta\',FolderName,'-',realizationstr,'_gk_nBeta.xls'),gkerror',2,'d1');

    %{
    %making figure
    %---------------------------------
    figure;
    Z(1:nnBetaHist,1:nUtotHist) = log(gk(1:nnBetaHist,1:nUtotHist));
    surfc(UtotHist1,nBetaHist1,Z);
    alpha(0.3);
    %plotting error
    Zerror(1:nnBetaHist,1:nUtotHist) = log(gk(1:nnBetaHist,1:nUtotHist)+gkerror(1:nnBetaHist,1:nUtotHist));
    hold on;
    surfc(UtotHist1,nBetaHist1,Zerror);
    alpha(0.3);
    clear Z Zerror;
    title(strcat(FolderName,'-',realizationstr,'-nBeta'));
    print('-dpng',strcat(FigPath,'3-DOS-FindTf\Figs\nBeta\',FolderName,'-',realizationstr,'_gkerr_nBeta.png'));
    close;
    %---------------------------------
    %}
 
    
    clear nBetaHist Coef SumnBetaHist gk gkerror;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%nNonAlpha
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    for counter=1:Tnum
        SumnNonAlphaHist(Tindex(counter)) = sum(sum(nNonAlphaHist(Tindex(counter),:,:,1)));
    end
    
    %This coefficient determines the method of WHAM (usual or that by Hall)
    %Coef(1:Tnum) = 1/SumnNonAlphaHist(1:Tnum);
    Coef(1:Tnum) = 1; 
    
    %----------------------------------------------------------------------
    %Finding g_k from fs
    for k1=1:nnNonAlphaHist
        for k2=1:nUtotHist
            gkNum = 0;
            gkDen = 0;
            for nn=1:Tnum
                gkNum = gkNum + Coef(nn)/GTaus(Tindex(nn),2)*nNonAlphaHist(Tindex(nn),k1,k2,1);
                gkDen = gkDen + Coef(nn)/GTaus(Tindex(nn),2)*SumnNonAlphaHist(Tindex(nn))*exp(-UtotHist1(k2)/Ts(Tindex(nn)))/expf(nn);
            end
            gk(k1,k2) = gkNum/gkDen;
        end
    end
    
    %Finding error of g_k 
    for k1=1:nnNonAlphaHist
        for k2=1:nUtotHist
            gkerror(k1,k2)=0;
            %gkerrorNum=0;   gkerrorDen=0;
            for nn=1:Tnum
                gkerror(k1,k2) = gkerror(k1,k2) + Coef(nn)/GTaus(Tindex(nn),2)*nNonAlphaHist(Tindex(nn),k1,k2,1);
                %if SumnNonAlphaHist(Tindex(nn))~=0
                    %gkerrorNum = gkerrorNum + Coef(nn)/GTaus(Tindex(nn),2)*nNonAlphaHist(Tindex(nn),k1,k2,1)/SumnNonAlphaHist(Tindex(nn));
                    %gkerrorDen = gkerrorDen + Coef(nn)/GTaus(Tindex(nn),2)*nNonAlphaHist(Tindex(nn),k1,k2,1);
                %end
            end
            if gkerror(k1,k2)~=0
                gkerror(k1,k2) = 1/sqrt(gkerror(k1,k2))*gk(k1,k2);
                %gkerror(k1,k2) = sqrt(gkerrorNum)/gkerrorDen;
            else
                gkerror(k1,k2)=0;
            end
        end
    end
        
    %making the lowest amount of gk equal to one
    mingk = max(max(gk));
    for k1=1:nnNonAlphaHist
        for k2=1:nUtotHist
            if (gk(k1,k2)>0)&(gk(k1,k2)<mingk)
                mingk = gk(k1,k2);
            end
        end
    end

    gk = gk/mingk;
    gkerror = gkerror/mingk;
    
    xlswrite(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\nNonAlpha\',FolderName,'-',realizationstr,'_gk_nNonAlpha.xls'),nnNonAlphaHist,1,'a1');
    xlswrite(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\nNonAlpha\',FolderName,'-',realizationstr,'_gk_nNonAlpha.xls'),nUtotHist,1,'a2');
    xlswrite(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\nNonAlpha\',FolderName,'-',realizationstr,'_gk_nNonAlpha.xls'),nNonAlphaHist1',1,'b1');
    xlswrite(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\nNonAlpha\',FolderName,'-',realizationstr,'_gk_nNonAlpha.xls'),UtotHist1',1,'c1');
    xlswrite(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\nNonAlpha\',FolderName,'-',realizationstr,'_gk_nNonAlpha.xls'),gk',1,'d1');
    xlswrite(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\nNonAlpha\',FolderName,'-',realizationstr,'_gk_nNonAlpha.xls'),gkerror',2,'d1');

    %{
    %making figure
    %---------------------------------
    figure;
    Z(1:nnNonAlphaHist,1:nUtotHist) = log(gk(1:nnNonAlphaHist,1:nUtotHist));
    surfc(UtotHist1,nNonAlphaHist1,Z);
    alpha(0.3);
    %plotting error
    Zerror(1:nnNonAlphaHist,1:nUtotHist) = log(gk(1:nnNonAlphaHist,1:nUtotHist)+gkerror(1:nnNonAlphaHist,1:nUtotHist));
    hold on;
    surfc(UtotHist1,nNonAlphaHist1,Zerror);
    alpha(0.3);
    clear Z Zerror;
    title(strcat(FolderName,'-',realizationstr,'-nNonAlpha'));
    print('-dpng',strcat(FigPath,'3-DOS-FindTf\Figs\nNonAlpha\',FolderName,'-',realizationstr,'_gkerr_nNonAlpha.png'));
    close;
    %---------------------------------
    %}
 
    
    clear nNonAlphaHist Coef SumnNonAlphaHist gk gkerror;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    
    %*%*%*%*%*%*%*%*%*%*%*%*%*%*%*%*%*%
    if eNPStrength~=0
        %nAlphaeNP
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
        for counter=1:Tnum
            SumnAlphaeNPHist(Tindex(counter)) = sum(sum(sum(nAlphaeNPHist(Tindex(counter),:,:,:,1))));
        end

        %This coefficient determines the method of WHAM (usual or that by Hall)
        %Coef(1:Tnum) = 1/SumnAlphaeNPHist(1:Tnum);
        Coef(1:Tnum) = 1; 

        %----------------------------------------------------------------------
        %Finding g_k from fs
        for k1=1:nnAlphaHist
            for k2=1:neNPHist
                for k3=1:nUtotrestNPHist
                    gkNum = 0;
                    gkDen = 0;
                    for nn=1:Tnum
                        gkNum = gkNum + Coef(nn)/GTaus(Tindex(nn),2)*nAlphaeNPHist(Tindex(nn),k1,k2,k3,1);
                        gkDen = gkDen + Coef(nn)/GTaus(Tindex(nn),2)*SumnAlphaeNPHist(Tindex(nn))*exp(-(eNPHist1(k2)-nAlphaHist1(k1)+UtotrestNPHist1(k3))/Ts(Tindex(nn)))/expf(nn);
                    end
                    gkcopy(k1,k2,k3) = gkNum/gkDen;
                end
            end
        end

        for k1=1:nnAlphaHist
            for k2=1:neNPHist
                gk(k1,k2) = sum(gkcopy(k1,k2,1:nUtotrestNPHist));
                UAvrg(k1,k2) = 0;
                if (gk(k1,k2)~=0)
                    for k3=1:nUtotrestNPHist
                        UAvrg(k1,k2) = UAvrg(k1,k2)+ gkcopy(k1,k2,k3)*UtotrestNPHist1(k3)/gk(k1,k2);
                    end
                end
            end
        end

        %Finding error of g_k
        for k1=1:nnAlphaHist
            for k2=1:neNPHist
                gkerror(k1,k2)=0;
                %gkerrorNum=0;   gkerrorDen=0;
                for nn=1:Tnum
                    gkerror(k1,k2) = gkerror(k1,k2) + Coef(nn)/GTaus(Tindex(nn),2)*sum(nAlphaeNPHist(Tindex(nn),k1,k2,1:nUtotrestNPHist,1));
                    %if SumnAlphaHist(Tindex(nn))~=0
                        %gkerrorNum = gkerrorNum + Coef(nn)/GTaus(Tindex(nn),2)*nAlphaeNPHist(Tindex(nn),k1,k2,1)/SumnAlphaeNPHist(Tindex(nn));
                        %gkerrorDen = gkerrorDen + Coef(nn)/GTaus(Tindex(nn),2)*nAlphaeNPHist(Tindex(nn),k1,k2,1);
                    %end
                end
                if gkerror(k1,k2)~=0
                    gkerror(k1,k2) = 1/sqrt(gkerror(k1,k2))*gk(k1,k2);
                    %gkerror(k1,k2) = sqrt(gkerrorNum)/gkerrorDen;
                else
                    gkerror(k1,k2)=0;
                end
            end
        end

        %making the lowest amount of gk equal to one
        mingk = max(max(gk));
        for k1=1:nnAlphaHist
            for k2=1:neNPHist
                if (gk(k1,k2)>0)&(gk(k1,k2)<mingk)
                    mingk = gk(k1,k2);
                end
            end
        end

        gk = gk/mingk;
        gkerror = gkerror/mingk;

        xlswrite(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\nAlphaeNP\',FolderName,'-',realizationstr,'_gk_nAlphaeNP.xls'),nnAlphaHist,1,'a1');
        xlswrite(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\nAlphaeNP\',FolderName,'-',realizationstr,'_gk_nAlphaeNP.xls'),neNPHist,1,'a2');
        xlswrite(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\nAlphaeNP\',FolderName,'-',realizationstr,'_gk_nAlphaeNP.xls'),nAlphaHist1',1,'b1');
        xlswrite(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\nAlphaeNP\',FolderName,'-',realizationstr,'_gk_nAlphaeNP.xls'),eNPHist1',1,'c1');
        xlswrite(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\nAlphaeNP\',FolderName,'-',realizationstr,'_gk_nAlphaeNP.xls'),gk',1,'d1');
        xlswrite(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\nAlphaeNP\',FolderName,'-',realizationstr,'_gk_nAlphaeNP.xls'),gkerror',2,'d1');
        xlswrite(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\nAlphaeNP\',FolderName,'-',realizationstr,'_gk_nAlphaeNP.xls'),UAvrg',3,'d1');

        %{
        %making figure
        %---------------------------------
        figure;
        Z(1:nnAlphaHist,1:neNPHist) = log(gk(1:nnAlphaHist,1:neNPHist));
        surfc(eNPHist1,nAlphaHist1,Z);
        alpha(0.3);
        %plotting error
        Zerror(1:nnAlphaHist,1:neNPHist) = log(gk(1:nnAlphaHist,1:neNPHist)+gkerror(1:nnAlphaHist,1:neNPHist));
        hold on;
        surfc(eNPHist1,nAlphaHist1,Zerror);
        alpha(0.3);
        clear Z Zerror;
        title(strcat(FolderName,'-',realizationstr,'-nAlphaeNP'));
        print('-dpng',strcat(FigPath,'3-DOS-FindTf\Figs\nAlphaeNP\',FolderName,'-',realizationstr,'_gkerr_nAlphaeNP.png'));
        close;
        %---------------------------------
        %}

        clear nAlphaeNPHist eNPHist1 UtotrestNPHist1 Coef SumnAlphaeNPHist gkcopy gk gkerror UAvrg;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    end
    %nAlphanBeta
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    for counter=1:Tnum
        SumnAlphanBetaHist(Tindex(counter)) = sum(sum(sum(nAlphanBetaHist(Tindex(counter),:,:,:,1))));
    end
    
    %This coefficient determines the method of WHAM (usual or that by Hall)
    %Coef(1:Tnum) = 1/SumnAlphanBetaHist(1:Tnum);
    Coef(1:Tnum) = 1; 
    
    %----------------------------------------------------------------------
    %Finding g_k from fs
    for k1=1:nnAlphaHist
        for k2=1:nnBetaHist
            for k3=1:nUtotrestBtHist
                gkNum = 0;
                gkDen = 0;
                for nn=1:Tnum
                    gkNum = gkNum + Coef(nn)/GTaus(Tindex(nn),2)*nAlphanBetaHist(Tindex(nn),k1,k2,k3,1);
                    gkDen = gkDen + Coef(nn)/GTaus(Tindex(nn),2)*SumnAlphanBetaHist(Tindex(nn))*exp(-(-nBetaHist1(k2)-nAlphaHist1(k1)+UtotrestBtHist1(k3))/Ts(Tindex(nn)))/expf(nn);
                end
                gkcopy(k1,k2,k3) = gkNum/gkDen;
            end
        end
    end
    
    for k1=1:nnAlphaHist
        for k2=1:nnBetaHist
            gk(k1,k2) = sum(gkcopy(k1,k2,1:nUtotrestBtHist));
            UAvrg(k1,k2) = 0;
            if (gk(k1,k2)~=0)
                for k3=1:nUtotrestBtHist
                    UAvrg(k1,k2) = UAvrg(k1,k2)+ gkcopy(k1,k2,k3)*UtotrestBtHist1(k3)/gk(k1,k2);
                end
            end
        end
    end
   
    %Finding error of g_k
    for k1=1:nnAlphaHist
        for k2=1:nnBetaHist
            gkerror(k1,k2)=0;
            %gkerrorNum=0;   gkerrorDen=0;
            for nn=1:Tnum
                gkerror(k1,k2) = gkerror(k1,k2) + Coef(nn)/GTaus(Tindex(nn),2)*sum(nAlphanBetaHist(Tindex(nn),k1,k2,1:nUtotrestBtHist,1));
                %if SumnAlphaHist(Tindex(nn))~=0
                    %gkerrorNum = gkerrorNum + Coef(nn)/GTaus(Tindex(nn),2)*nAlphanBetaHist(Tindex(nn),k1,k2,1)/SumnAlphanBetaHist(Tindex(nn));
                    %gkerrorDen = gkerrorDen + Coef(nn)/GTaus(Tindex(nn),2)*nAlphanBetaHist(Tindex(nn),k1,k2,1);
                %end
            end
            if gkerror(k1,k2)~=0
                gkerror(k1,k2) = 1/sqrt(gkerror(k1,k2))*gk(k1,k2);
                %gkerror(k1,k2) = sqrt(gkerrorNum)/gkerrorDen;
            else
                gkerror(k1,k2)=0;
            end
        end
    end
        
    %making the lowest amount of gk equal to one
    mingk = max(max(gk));
    for k1=1:nnAlphaHist
        for k2=1:nnBetaHist
            if (gk(k1,k2)>0)&(gk(k1,k2)<mingk)
                mingk = gk(k1,k2);
            end
        end
    end
    
    gk = gk/mingk;
    gkerror = gkerror/mingk;
    
    xlswrite(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\nAlphanBeta\',FolderName,'-',realizationstr,'_gk_nAlphanBeta.xls'),nnAlphaHist,1,'a1');
    xlswrite(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\nAlphanBeta\',FolderName,'-',realizationstr,'_gk_nAlphanBeta.xls'),nnBetaHist,1,'a2');
    xlswrite(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\nAlphanBeta\',FolderName,'-',realizationstr,'_gk_nAlphanBeta.xls'),nAlphaHist1',1,'b1');
    xlswrite(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\nAlphanBeta\',FolderName,'-',realizationstr,'_gk_nAlphanBeta.xls'),nBetaHist1',1,'c1');
    xlswrite(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\nAlphanBeta\',FolderName,'-',realizationstr,'_gk_nAlphanBeta.xls'),gk',1,'d1');
    xlswrite(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\nAlphanBeta\',FolderName,'-',realizationstr,'_gk_nAlphanBeta.xls'),gkerror',2,'d1');
    xlswrite(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\nAlphanBeta\',FolderName,'-',realizationstr,'_gk_nAlphanBeta.xls'),UAvrg',3,'d1');

    %{
    %making figure
    %---------------------------------
    figure;
    Z(1:nnAlphaHist,1:nnBetaHist) = log(gk(1:nnAlphaHist,1:nnBetaHist));
    surfc(nBetaHist1,nAlphaHist1,Z);
    alpha(0.3);
    %plotting error
    Zerror(1:nnAlphaHist,1:nnBetaHist) = log(gk(1:nnAlphaHist,1:nnBetaHist)+gkerror(1:nnAlphaHist,1:nnBetaHist));
    hold on;
    surfc(nBetaHist1,nAlphaHist1,Zerror);
    alpha(0.3);
    clear Z Zerror;
    title(strcat(FolderName,'-',realizationstr,'-nAlphanBeta'));
    print('-dpng',strcat(FigPath,'3-DOS-FindTf\Figs\nAlphanBeta\',FolderName,'-',realizationstr,'_gkerr_nAlphanBeta.png'));
    close;
    %---------------------------------
    %}
    
    clear nAlphanBetaHist nBetaHist1 UtotrestBtHist1 Coef SumnAlphanBetaHist gkcopy gk gkerror UAvrg;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    %nAlphanNonAlpha
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    for counter=1:Tnum
        SumnAlphanNonAlphaHist(Tindex(counter)) = sum(sum(sum(nAlphanNonAlphaHist(Tindex(counter),:,:,:,1))));
    end
    
    %This coefficient determines the method of WHAM (usual or that by Hall)
    %Coef(1:Tnum) = 1/SumnAlphanNonAlphaHist(1:Tnum);
    Coef(1:Tnum) = 1; 
    
    %----------------------------------------------------------------------
    %Finding g_k from fs
    for k1=1:nnAlphaHist
        for k2=1:nnNonAlphaHist
            for k3=1:nUtotrestNAHist
                gkNum = 0;
                gkDen = 0;
                for nn=1:Tnum
                    gkNum = gkNum + Coef(nn)/GTaus(Tindex(nn),2)*nAlphanNonAlphaHist(Tindex(nn),k1,k2,k3,1);
                    gkDen = gkDen + Coef(nn)/GTaus(Tindex(nn),2)*SumnAlphanNonAlphaHist(Tindex(nn))*exp(-(-nNonAlphaHist1(k2)-nAlphaHist1(k1)+UtotrestNAHist1(k3))/Ts(Tindex(nn)))/expf(nn);
                end
                gkcopy(k1,k2,k3) = gkNum/gkDen;
            end
        end
    end
    
    for k1=1:nnAlphaHist
        for k2=1:nnNonAlphaHist
            gk(k1,k2) = sum(gkcopy(k1,k2,1:nUtotrestNAHist));
            UAvrg(k1,k2) = 0;
            if (gk(k1,k2)~=0)
                for k3=1:nUtotrestNAHist
                    UAvrg(k1,k2) = UAvrg(k1,k2)+ gkcopy(k1,k2,k3)*UtotrestNAHist1(k3)/gk(k1,k2);
                end
            end
        end
    end
   
    %Finding error of g_k
    for k1=1:nnAlphaHist
        for k2=1:nnNonAlphaHist
            gkerror(k1,k2)=0;
            %gkerrorNum=0;   gkerrorDen=0;
            for nn=1:Tnum
                gkerror(k1,k2) = gkerror(k1,k2) + Coef(nn)/GTaus(Tindex(nn),2)*sum(nAlphanNonAlphaHist(Tindex(nn),k1,k2,1:nUtotrestNAHist,1));
                %if SumnAlphaHist(Tindex(nn))~=0
                    %gkerrorNum = gkerrorNum + Coef(nn)/GTaus(Tindex(nn),2)*nAlphanNonAlphaHist(Tindex(nn),k1,k2,1)/SumnAlphanNonAlphaHist(Tindex(nn));
                    %gkerrorDen = gkerrorDen + Coef(nn)/GTaus(Tindex(nn),2)*nAlphanNonAlphaHist(Tindex(nn),k1,k2,1);
                %end
            end
            if gkerror(k1,k2)~=0
                gkerror(k1,k2) = 1/sqrt(gkerror(k1,k2))*gk(k1,k2);
                %gkerror(k1,k2) = sqrt(gkerrorNum)/gkerrorDen;
            else
                gkerror(k1,k2)=0;
            end
        end
    end
        
    %making the lowest amount of gk equal to one
    mingk = max(max(gk));
    for k1=1:nnAlphaHist
        for k2=1:nnNonAlphaHist
            if (gk(k1,k2)>0)&(gk(k1,k2)<mingk)
                mingk = gk(k1,k2);
            end
        end
    end
    
    gk = gk/mingk;
    gkerror = gkerror/mingk;
    
    xlswrite(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\nAlphanNonAlpha\',FolderName,'-',realizationstr,'_gk_nAlphanNonAlpha.xls'),nnAlphaHist,1,'a1');
    xlswrite(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\nAlphanNonAlpha\',FolderName,'-',realizationstr,'_gk_nAlphanNonAlpha.xls'),nnNonAlphaHist,1,'a2');
    xlswrite(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\nAlphanNonAlpha\',FolderName,'-',realizationstr,'_gk_nAlphanNonAlpha.xls'),nAlphaHist1',1,'b1');
    xlswrite(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\nAlphanNonAlpha\',FolderName,'-',realizationstr,'_gk_nAlphanNonAlpha.xls'),nNonAlphaHist1',1,'c1');
    xlswrite(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\nAlphanNonAlpha\',FolderName,'-',realizationstr,'_gk_nAlphanNonAlpha.xls'),gk',1,'d1');
    xlswrite(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\nAlphanNonAlpha\',FolderName,'-',realizationstr,'_gk_nAlphanNonAlpha.xls'),gkerror',2,'d1');
    xlswrite(strcat(FigPath,'3-DOS-FindTf\ExcelFiles\nAlphanNonAlpha\',FolderName,'-',realizationstr,'_gk_nAlphanNonAlpha.xls'),UAvrg',3,'d1');

    %{
    %making figure
    %---------------------------------
    figure;
    Z(1:nnAlphaHist,1:nnNonAlphaHist) = log(gk(1:nnAlphaHist,1:nnNonAlphaHist));
    surfc(nNonAlphaHist1,nAlphaHist1,Z);
    alpha(0.3);
    %plotting error
    Zerror(1:nnAlphaHist,1:nnNonAlphaHist) = log(gk(1:nnAlphaHist,1:nnNonAlphaHist)+gkerror(1:nnAlphaHist,1:nnNonAlphaHist));
    hold on;
    surfc(nNonAlphaHist1,nAlphaHist1,Zerror);
    alpha(0.3);
    clear Z Zerror;
    title(strcat(FolderName,'-',realizationstr,'-nAlphanNonAlpha'));
    print('-dpng',strcat(FigPath,'3-DOS-FindTf\Figs\nAlphanNonAlpha\',FolderName,'-',realizationstr,'_gkerr_nAlphanNonAlpha.png'));
    close;
    %---------------------------------
    %}
    
    clear nAlphanNonAlphaHist nNonAlphaHist1 UtotrestNAHist1 Coef SumnAlphanNonAlphaHist gkcopy gk gkerror UAvrg;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    %*%*%*%*%*%*%*%*%*%*%*%*%*%*%*%*%*%
    clear UtotHist1 eNPHist1 UtotrestNPHist1 UtotrestBtHist1 UtotrestNAHist1 nAlphaHist1 nBetaHist1 nNonAlphaHist1 UtotHist nAlphaHist nAlphaeNPHist nAlphanBetaHist nAlphanNonAlphaHist;
end    

    end
    fclose(FNsToRun);
    disp(FolderName);

end
fclose(FNs);


