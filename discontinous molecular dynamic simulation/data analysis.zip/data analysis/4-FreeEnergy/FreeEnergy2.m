%clear all;
clear Avrg Avrgerror Avrg2 Avrg2error Chi1 Chi1error Chi2 Chi2error;
clear UtotHist1 nAlphaHist1 nAlphaHist gk gkerror;
clear eNPHist1 nAlphaeNPHist1 nAlphaeNPHist gk gkerror UAvrg;
clear FE FEerror;
clear newHist1 newgk newgkeror2 FEtot FEtoterror;
clear UtotHist1 UtotHist gk gkerror;
clear TAvrgs TFEs;
clear TAvrgs TFEs;
%clc;
MainPath = 'F:\Data\';%F:\Data\
FigPath = 'F:\Data\AnalyzeData\';

FolderNames = strcat(FigPath,'FolderNames.txt');
FNs = fopen(FolderNames,'r');
Runsnum=104;

Foldernum=99;
AllFNs(1:Runsnum,1:3)=0;

while ~(feof(FNs))
    %-------------------------------
    A = textscan(FNs,'%[^\n]',1);
    FolderName = cell2mat(A{1,1});
    clear A;
    %-------------------------------

    n =str2double(FolderName(1:2));  %n
    eNPStrength =str2double(FolderName(4:8));  %eNP
    npsize =str2double(FolderName(10:14));  %h
    
    AllFNs(Foldernum,1)=n;  %n
    AllFNs(Foldernum,2)=eNPStrength;  %eNP
    AllFNs(Foldernum,3)=npsize;  %h

    
    GTauscopy = xlsread(strcat(FigPath,'1-AutoCorrelation\ExcelFiles\',FolderName,'.xls'),'F--01','A1:C30');%SubFolderName,
    GTaus(1:size(GTauscopy,1),1) = GTauscopy(1:size(GTauscopy,1),1);
    GTaus(1:size(GTauscopy,1),2) = GTauscopy(1:size(GTauscopy,1),3);
    clear GTauscopy;
  
    MinTFE = GTaus(length(GTaus),1);
    MaxTFE = GTaus(1,1);
    dTFE = 0.01;
    nTFE = round((MaxTFE-MinTFE)/dTFE) + 1;
    
    MinTAvrg = GTaus(length(GTaus),1);
    MaxTAvrg = GTaus(1,1);
    dTAvrg = 0.0005; 
    nTAvrg = round((MaxTAvrg-MinTAvrg)/dTAvrg) + 1;
    
    TFEs = MinTFE:dTFE:MaxTFE;
    TAvrgs = MinTAvrg:dTAvrg:MaxTAvrg;
    
    dTFEnAlphaeNP = 0.02;
    dTFEnAlphanBeta = 0.02;
    dTFEnAlphanNonAlpha = 0.02;
    %dTAvrgnAlphaeNP = 0.015;

    %Utot
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    A=xlsread(strcat(FigPath,'3-DOS\ExcelFiles\Utot\',FolderName,'_gk_Utot.xls'),1);
    nUtotHist=A(1,1);
    UtotHist1=A(1:nUtotHist,2);
    gk=A(1:nUtotHist,3);
    gkerror=A(1:nUtotHist,4);
    clear A;

    %Free Energy calculation vs Utot at different Temperatures
    %---------------------------------------------------------
    onceUtot=4;
    k1end = floor(nUtotHist/onceUtot);  %instead of int32
    for k1=1:k1end
        newHist1(k1) = (UtotHist1((k1-1)*onceUtot+1)+UtotHist1(k1*onceUtot))/2;
        newgk(k1) = sum(gk(((k1-1)*onceUtot+1):onceUtot*k1));
        newgkerror2(k1) = sum(gkerror(((k1-1)*onceUtot+1):onceUtot*k1).*gkerror(((k1-1)*onceUtot+1):onceUtot*k1));
    end
    
    num=0;
    
    for T=MinTFE:dTFE:MaxTFE
        for k1=1:k1end
            if (newgk(k1)==0)
                FE(k1)=NaN;
                FEerror(k1)=NaN;    %corrected after an error
            else
                FE(k1)=newHist1(k1)-T*log(newgk(k1));
                FEerror(k1)=sqrt( (T/newgk(k1))^2 * newgkerror2(k1));
            end
        end
        
        %making figure
        figure;
        errorbar(newHist1,FE,FEerror,'.:');
        title(strcat(FolderName,'-FE-Utot-T=',num2str(T)));
        print('-dpng',strcat(FigPath,'4-FreeEnergy\Figs\Utot\',FolderName,'-T=',num2str(T),'.png'));
        %saveas(gcf,strcat(FigPath,'Free Energy\',FolderName,'\Utot\T=',num2str(T),'_Free Energy_Utot.fig'));
        close;
        
        num=num+1;
        FEtot(num,1:k1end)=FE;
        FEtoterror(num,1:k1end)=FEerror;
        
        clear FE FEerror;
    end
    
    %Write in excel
    xlswrite(strcat(FigPath,'4-FreeEnergy\ExcelFiles\Utot\',FolderName,'-All-T.xls'),nTFE,1,'a1');
    xlswrite(strcat(FigPath,'4-FreeEnergy\ExcelFiles\Utot\',FolderName,'-All-T.xls'),k1end,1,'a2');
    xlswrite(strcat(FigPath,'4-FreeEnergy\ExcelFiles\Utot\',FolderName,'-All-T.xls'),TFEs',1,'b1');
    xlswrite(strcat(FigPath,'4-FreeEnergy\ExcelFiles\Utot\',FolderName,'-All-T.xls'),newHist1',1,'c1');
    xlswrite(strcat(FigPath,'4-FreeEnergy\ExcelFiles\Utot\',FolderName,'-All-T.xls'),FEtot',1,'d1');
    xlswrite(strcat(FigPath,'4-FreeEnergy\ExcelFiles\Utot\',FolderName,'-All-T.xls'),FEtoterror',2,'d1');
        
    %making a total figure
    figure;
    surfc(newHist1,TFEs,FEtot);
    alpha(0.3);
    title(strcat(FolderName,'-FE-Utot-All-T'));
    print('-dpng',strcat(FigPath,'4-FreeEnergy\Figs\Utot\',FolderName,'-All-T.png'));
    saveas(gcf,strcat(FigPath,'4-FreeEnergy\Figs\Utot\',FolderName,'-All-T.fig'));

    hold on;
    title(strcat(FolderName,'-FEerror-Utot-All-T'));
    surfc(newHist1,TFEs,FEtot+FEtoterror);
    alpha(0.3);
    print('-dpng',strcat(FigPath,'4-FreeEnergy\Figs\Utot\',FolderName,'-FEerror-All-T.png'));
    saveas(gcf,strcat(FigPath,'4-FreeEnergy\Figs\Utot\',FolderName,'-FEerror-All-T.fig'));

    close;
    clear newHist1 newgk newgkeror2 FEtot FEtoterror;
    %---------------------------------------------------------
        
    %Average Utot calculation at different Temperatures
    %---------------------------------------------------------
    num=0;
    for T=MinTAvrg:dTAvrg:MaxTAvrg
        num=num+1;
        Den=0;
        Num=0;
        Num2=0;
        for k1=1:nUtotHist
            gexpE=gk(k1) * exp(-UtotHist1(k1)/T);
            Den = Den + gexpE;
            Num = Num + UtotHist1(k1) * gexpE;
            Num2 = Num2 + UtotHist1(k1)^2 * gexpE;
        end
        Avrg(num) = Num/Den;
        Avrg2(num) = Num2/Den;
        
        error2=0;
        error22=0;
        for k1=1:nUtotHist
            Coef = exp(-UtotHist1(k1)/T)*(UtotHist1(k1)*Den-Num)/Den^2;
            error2 = error2 + Coef^2*gkerror(k1)^2;
            Coef2 = exp(-UtotHist1(k1)/T)*(UtotHist1(k1)^2*Den-Num)/Den^2;
            error22 = error22 + Coef2^2*gkerror(k1)^2;
        end
        Avrgerror(num)=sqrt(error2);
        Avrg2error(num)=sqrt(error22);
    end
    
    num=0;
    for T=MinTAvrg:dTAvrg:MaxTAvrg
        num=num+1;
        %Finding Cv Using <E2>-<E>2
        Cv1(num)=(Avrg2(num)-Avrg(num)^2)/T^2;
        Cv1error(num)=sqrt(Avrg2error(num)^2+(2*Avrg(num)*Avrgerror(num))^2)/T^2;
        %Finding Cv Using d<E>/dT
        if num==1
            Cv2(num) = (Avrg(num+1)-Avrg(num))/(dTAvrg);
            Cv2error(num) = sqrt(Avrgerror(num+1)^2+Avrgerror(num)^2)/(dTAvrg);
        elseif(num==nTAvrg)
            Cv2(num) = (Avrg(num)-Avrg(num-1))/(dTAvrg);
            Cv2error(num) = sqrt(Avrgerror(num)^2+Avrgerror(num-1)^2)/(dTAvrg);
        else
            Cv2(num) = (Avrg(num+1)-Avrg(num-1))/(2*dTAvrg);
            Cv2error(num) = sqrt(Avrgerror(num+1)^2+Avrgerror(num-1)^2)/(2*dTAvrg);
        end
    end
    
    %Write in excel
    xlswrite(strcat(FigPath,'4-FreeEnergy\ExcelFiles\Utot\',FolderName,'-Avrg.xls'),TAvrgs',1,'a1');
    xlswrite(strcat(FigPath,'4-FreeEnergy\ExcelFiles\Utot\',FolderName,'-Avrg.xls'),Avrg',1,'b1');
    xlswrite(strcat(FigPath,'4-FreeEnergy\ExcelFiles\Utot\',FolderName,'-Avrg.xls'),Avrgerror',1,'c1');
        
    %Write in excel
    xlswrite(strcat(FigPath,'4-FreeEnergy\ExcelFiles\Utot\',FolderName,'-Cv.xls'),TAvrgs',1,'a1');
    xlswrite(strcat(FigPath,'4-FreeEnergy\ExcelFiles\Utot\',FolderName,'-Cv.xls'),Cv1',1,'b1');
    xlswrite(strcat(FigPath,'4-FreeEnergy\ExcelFiles\Utot\',FolderName,'-Cv.xls'),Cv1error',1,'c1');
    xlswrite(strcat(FigPath,'4-FreeEnergy\ExcelFiles\Utot\',FolderName,'-Cv.xls'),Cv2',1,'d1');
    xlswrite(strcat(FigPath,'4-FreeEnergy\ExcelFiles\Utot\',FolderName,'-Cv.xls'),Cv2error',1,'e1');
        
    %making a total figure
    figure;
    errorbar(TAvrgs,Avrg,Avrgerror,'.:');
    title(strcat(FolderName,'-Avrg'));
    print('-dpng',strcat(FigPath,'4-FreeEnergy\Figs\Utot\',FolderName,'-Avrg.png'));
    %saveas(gcf,strcat(FigPath,'4-FreeEnergy\Figs\Utot\',FolderName,'-Avrg.fig'));
    close;
    
    figure;
    errorbar(TAvrgs,Cv1,Cv1error,'.:');
    title(strcat(FolderName,'-Cv'));
    hold on;
    errorbar(TAvrgs,Cv2,Cv2error,'r.:');
    print('-dpng',strcat(FigPath,'4-FreeEnergy\Figs\Utot\',FolderName,'-Cv-error.png'));
    %saveas(gcf,strcat(FigPath,'4-FreeEnergy\Figs\Utot\',FolderName,'-Cv-error.fig'));
    close;
    
    figure;
    plot(TAvrgs,Cv1,'.:');
    title(strcat(FolderName,'-Cv'));
    hold on;
    plot(TAvrgs,Cv2,'r.:');
    print('-dpng',strcat(FigPath,'4-FreeEnergy\Figs\Utot\',FolderName,'-Cv.png'));
    %saveas(gcf,strcat(FigPath,'4-FreeEnergy\Figs\Utot\',FolderName,'-Cv.fig'));
    close;
    
    %Finding Tf Using Cv
    %-------------------
    %MaxLoc=0;
    num=0;
    [MaxCv,MaxLoc]=max(Cv2);
    %{
    MaxCv=max(Cv1);
    for T=MinTAvrg:dTAvrg:MaxTAvrg
        num=num+1;
        if (Cv1(num)==MaxCv)
            MaxLoc=num;
        end
    end
    if (MaxLoc==0)
        S='Error on Finding MaxLoc, Cv1'
    else
    end
    %}
    TCv = TAvrgs(MaxLoc);
    MaxCv = Cv2(MaxLoc);
    %Finding TCv error
    Cvmin = Cv2(MaxLoc)-Cv2error(MaxLoc);
    TCvdown = TCv;
    TCvup = TCv;
    num=0;
    for T=MinTAvrg:dTAvrg:MaxTAvrg
        num=num+1;
        if ((Cv2(num)+Cv2error(num))>=Cvmin)
            if (TAvrgs(num)<TCvdown)
                TCvdown=TAvrgs(num);
            elseif (TAvrgs(num)>TCvup)
                TCvup=TAvrgs(num);
            end
        end
    end
    
    [Cvhalf1,iCvhalf1]=min(abs(Cv2(1:MaxLoc)-0.5*MaxCv));
    Cvhalf1=Cv2(iCvhalf1);
    [Cvhalf2,iCvhalf2]=min(abs(Cv2(MaxLoc:length(Cv2))-0.5*MaxCv));
    iCvhalf2=iCvhalf2+MaxLoc-1;
    Cvhalf2=Cv2(iCvhalf2);
    T1_Cvhalf=TAvrgs(iCvhalf1);
    T2_Cvhalf=TAvrgs(iCvhalf2);

    
    clear Avrg Avrgerror Avrg2 Avrg2error Cv1 Cv1error Cv2 Cv2error;
    %---------------------------------------------------------
   
    clear UtotHist1 UtotHist gk gkerror;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    
    %nAlpha
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    A=xlsread(strcat(FigPath,'3-DOS\ExcelFiles\nAlpha\',FolderName,'_gk_nAlpha.xls'),1);
    nnAlphaHist=A(1,1);
    nUtotHist=A(2,1);
    nAlphaHist1=A(1:nnAlphaHist,2);
    UtotHist1=A(1:nUtotHist,3);
    gk=A(1:nUtotHist,4:(3+nnAlphaHist));
    clear A;

    A=xlsread(strcat(FigPath,'3-DOS\ExcelFiles\nAlpha\',FolderName,'_gk_nAlpha.xls'),2);
    gkerror=A(1:nUtotHist,1:nnAlphaHist);%4:(3+nnAlphaHist)
    clear A;
    
    %Free Energy calculation vs nAlpha at different Temperatures
    %---------------------------------------------------------
    num=0;
    for T=MinTFE:dTFE:MaxTFE
        for k2=1:nnAlphaHist
            Sum=0;
            error2=0;
            for k1=1:nUtotHist
                Sum=Sum+gk(k1,k2)*exp(-UtotHist1(k1)/T);
                error2 = error2 + T^2*exp(-2*UtotHist1(k1)/T)*gkerror(k1,k2)^2;
            end
            FE(k2)=-T*log(Sum);
            FEerror(k2)=sqrt(error2/Sum^2);
        end
        
        %making figure
        figure;
        errorbar(nAlphaHist1,FE,FEerror,'.:');
        title(strcat(FolderName,'-FE-nAlpha-T=',num2str(T)));
        print('-dpng',strcat(FigPath,'4-FreeEnergy\Figs\nAlpha\',FolderName,'-T=',num2str(T),'.png'));
        %saveas(gcf,strcat(FigPath,'4-FreeEnergy\Figs\nAlpha\',FolderName,'-T=',num2str(T),'.fig'));
        close;
        
        num=num+1;
        FEtot(num,1:nnAlphaHist)=FE;
        FEtoterror(num,1:nnAlphaHist)=FEerror;
        
        clear FE FEerror;
    end
    
    %Write in excel
    xlswrite(strcat(FigPath,'4-FreeEnergy\ExcelFiles\nAlpha\',FolderName,'-All-T.xls'),nTFE,1,'a1');
    xlswrite(strcat(FigPath,'4-FreeEnergy\ExcelFiles\nAlpha\',FolderName,'-All-T.xls'),nnAlphaHist,1,'a2');
    xlswrite(strcat(FigPath,'4-FreeEnergy\ExcelFiles\nAlpha\',FolderName,'-All-T.xls'),TFEs',1,'b1');
    xlswrite(strcat(FigPath,'4-FreeEnergy\ExcelFiles\nAlpha\',FolderName,'-All-T.xls'),nAlphaHist1,1,'c1');
    xlswrite(strcat(FigPath,'4-FreeEnergy\ExcelFiles\nAlpha\',FolderName,'-All-T.xls'),FEtot',1,'d1');
    xlswrite(strcat(FigPath,'4-FreeEnergy\ExcelFiles\nAlpha\',FolderName,'-All-T.xls'),FEtoterror',2,'d1');
        
    %making a total figure
    figure;
    %surfc(nAlphaHist1,TFEs,FEtot);
    %alpha(0.3);
    contourf(nAlphaHist1,TFEs,FEtot,50);
    colormap gray;
    colorbar;
    title(strcat(FolderName,'-FE-nAlpha-All'));
    print('-dpng',strcat(FigPath,'4-FreeEnergy\Figs\nAlpha\',FolderName,'-All-T.png'));
    %print('-deps',strcat(FigPath,'4-FreeEnergy\Figs\nAlpha\',FolderName,'-All-T.eps'));
    saveas(gcf,strcat(FigPath,'4-FreeEnergy\Figs\nAlpha\',FolderName,'-All-T.fig'));

    
    hold off;
    surfc(nAlphaHist1,TFEs,FEtot);
    hold on;
    title(strcat(FolderName,'-FEerror-nAlpha-All'));
    if sum(sum(isnan(FEtot+FEtoterror)))==0 %size(FEtot,1)*size(FEtot,2)
        surfc(nAlphaHist1,TFEs,FEtot+FEtoterror);
        alpha(0.3);
    end
    print('-dpng',strcat(FigPath,'4-FreeEnergy\Figs\nAlpha\',FolderName,'-FEerror-All-T.png'));
    %saveas(gcf,strcat(FigPath,'Free Energy\',FolderName,'\nAlpha\All T_Free Energy error_nAlpha.fig'));

    close;
    clear FEtot FEtoterror;
    %---------------------------------------------------------
        
    %Average nAlpha calculation at different Temperatures
    %---------------------------------------------------------
    num=0;
    for T=MinTAvrg:dTAvrg:MaxTAvrg
        num=num+1;
        Den=0;
        Num=0;
        Num2=0;
        for k1=1:nUtotHist
            for k2=1:nnAlphaHist
                gexpE=gk(k1,k2)*exp(-UtotHist1(k1)/T);
                Den=Den+gexpE;
                Num=Num+nAlphaHist1(k2)*gexpE;
                Num2 = Num2 + nAlphaHist1(k2)^2 * gexpE;
            end
        end
        Avrg(num) = Num/Den;
        Avrg2(num) = Num2/Den;
        
        error2=0;
        error22=0;
        for k1=1:nUtotHist
            for k2=1:nnAlphaHist
                Coef = exp(-UtotHist1(k1)/T)*(nAlphaHist1(k2)*Den-Num)/Den^2;
                error2 = error2 + Coef^2*gkerror(k1,k2)^2;
                Coef2 = exp(-UtotHist1(k1)/T)*(nAlphaHist1(k2)^2*Den-Num)/Den^2;
                error22 = error22 + Coef2^2*gkerror(k1,k2)^2;
            end
        end
        Avrgerror(num)=sqrt(error2);
        Avrg2error(num)=sqrt(error22);
    end
    
    num=0;
    for T=MinTAvrg:dTAvrg:MaxTAvrg
        num=num+1;
        %Finding Chi Using <q2>-<q>2
        Chi1(num)=(Avrg2(num)-Avrg(num)^2);
        Chi1error(num)=sqrt(Avrg2error(num)^2+(2*Avrg(num)*Avrgerror(num))^2);
        %Finding Chi Using d<E>/dT
        if num==1
            Chi2(num) = abs(Avrg(num+1)-Avrg(num))/(dTAvrg);
            Chi2error(num) = sqrt(Avrgerror(num+1)^2+Avrgerror(num)^2)/(dTAvrg);
        elseif(num==nTAvrg)
            Chi2(num) = abs(Avrg(num)-Avrg(num-1))/(dTAvrg);
            Chi2error(num) = sqrt(Avrgerror(num)^2+Avrgerror(num-1)^2)/(dTAvrg);
        else
            Chi2(num) = abs(Avrg(num+1)-Avrg(num-1))/(2*dTAvrg);
            Chi2error(num) = sqrt(Avrgerror(num+1)^2+Avrgerror(num-1)^2)/(2*dTAvrg);
        end
    end
 
    %Write in excel
    xlswrite(strcat(FigPath,'4-FreeEnergy\ExcelFiles\nAlpha\',FolderName,'-Avrg.xls'),TAvrgs',1,'a1');
    xlswrite(strcat(FigPath,'4-FreeEnergy\ExcelFiles\nAlpha\',FolderName,'-Avrg.xls'),Avrg',1,'b1');
    xlswrite(strcat(FigPath,'4-FreeEnergy\ExcelFiles\nAlpha\',FolderName,'-Avrg.xls'),Avrgerror',1,'c1');
        
    %Write in excel
    xlswrite(strcat(FigPath,'4-FreeEnergy\ExcelFiles\nAlpha\',FolderName,'-Chi.xls'),TAvrgs',1,'a1');
    xlswrite(strcat(FigPath,'4-FreeEnergy\ExcelFiles\nAlpha\',FolderName,'Chi.xls'),Chi1',1,'b1');
    xlswrite(strcat(FigPath,'4-FreeEnergy\ExcelFiles\nAlpha\',FolderName,'Chi.xls'),Chi1error',1,'c1');
    xlswrite(strcat(FigPath,'4-FreeEnergy\ExcelFiles\nAlpha\',FolderName,'Chi.xls'),Chi2',1,'d1');
    xlswrite(strcat(FigPath,'4-FreeEnergy\ExcelFiles\nAlpha\',FolderName,'Chi.xls'),Chi2error',1,'e1');
        
    %making a total figure
    figure;
    errorbar(TAvrgs,Avrg,Avrgerror,'.:');
    title(strcat(FolderName,'-Avrg-nAlpha-T'));
    print('-dpng',strcat(FigPath,'4-FreeEnergy\Figs\nAlpha\',FolderName,'-Avrg-nAlpha-T.png'));
    %saveas(gcf,strcat(FigPath,'4-FreeEnergy\Figs\nAlpha\',FolderName,'-Avrg-nAlpha-T.fig'));
    close;
    
    figure;
    errorbar(TAvrgs,Chi1,Chi1error,'.:');
    title(strcat(FolderName,'-Chi1-error'));
    print('-dpng',strcat(FigPath,'4-FreeEnergy\Figs\nAlpha\',FolderName,'-Chi1-error.png'));
    hold off;
    close;
    
    figure;
    errorbar(TAvrgs,Chi2,Chi2error,'r.:');
    title(strcat(FolderName,'-Chi2-error'));
    print('-dpng',strcat(FigPath,'4-FreeEnergy\Figs\nAlpha\',FolderName,'-Chi2-error.png'));
    %saveas(gcf,strcat(FigPath,'4-FreeEnergy\Figs\nAlpha\',FolderName,'-Chi-error.fig'));
    close;
    
    
    %{
    figure;
    plot(TAvrgs,Chi1,'.:');
    title(strcat(FolderName,'Chi'));
    hold on;
    plot(TAvrgs,Chi2,'r.:');
    print('-dpng',strcat(FigPath,'4-FreeEnergy\Figs\nAlpha\',FolderName,'-Chi.png'));
    %saveas(gcf,strcat(FigPath,'4-FreeEnergy\Figs\nAlpha\',FolderName,'-Chi.fig'));
    close;
    %}
    
    %Finding Tf Using q=1/2
    %-------------------
    %midLoc=0;
    num=0;
    minval=min(Avrg);
    maxval=max(Avrg);
    [mindiff,midLoc]=min(abs(Avrg-(maxval+minval)/2.0));  %min(Avrg-(n-4)/2.0);
    %{
    mindiff=min(abs(Avrg-(maxval+minval)/2.0));  %min(Avrg-(n-4)/2.0);
    for T=MinTAvrg:dTAvrg:MaxTAvrg
        num=num+1;
        if (abs(Avrg(num)-(maxval+minval)/2.0)==mindiff)
            midLoc=num;
        end
    end
    if (midLoc==0)
        S='Error on Finding MaxLoc, alpha average'
    else
    %}
    Tq = TAvrgs(midLoc);
    valq = Avrg(midLoc);
    %Finding TChi error
    qmin = Avrg(midLoc)-Avrgerror(midLoc);
    qmax = Avrg(midLoc)+Avrgerror(midLoc);
    Tqdown = Tq;
    Tqup = Tq;
    num=0;
    for T=MinTAvrg:dTAvrg:MaxTAvrg
        num=num+1;
        val1=(Avrg(num)-Avrgerror(num));
        val2=(Avrg(num)+Avrgerror(num));
        if ((val1-qmin)*(val1-qmax)<=0) | ((val2-qmin)*(val2-qmax)<=0)
            if (TAvrgs(num)<Tqdown)
                Tqdown=TAvrgs(num);
            elseif (TAvrgs(num)>Tqup)
                Tqup=TAvrgs(num);
            end
        end
    end
    %end
    %-------------------
    
    %Finding Tf Using Chi
    %-------------------
    %MaxLoc=0;
    num=0;
    [MaxChi,MaxLoc]=max(Chi1);
    %{
    MaxChi=max(Chi1);
    for T=MinTAvrg:dTAvrg:MaxTAvrg
        num=num+1;
        if (Chi1(num)==MaxChi)
            MaxLoc=num;
        end
    end
    if (MaxLoc==0)
        S='Error on Finding MaxLoc, Chi1'
        TChi = 0;
        MaxChi = 0;
    else
    %}
    TChi = TAvrgs(MaxLoc);
    MaxChi = Chi1(MaxLoc);
    %Finding TChi error
    Chimin = Chi1(MaxLoc)-Chi1error(MaxLoc);
    TChidown = TChi;
    TChiup = TChi;
    num=0;
    for T=MinTAvrg:dTAvrg:MaxTAvrg
        num=num+1;
        if ((Chi1(num)+Chi1error(num))>=Chimin)
            if (TAvrgs(num)<TChidown)
                TChidown=TAvrgs(num);
            elseif (TAvrgs(num)>TChiup)
                TChiup=TAvrgs(num);
            end
        end
    end
    %end

    [Chihalf1,iChihalf1]=min(abs(Chi1(1:MaxLoc)-0.5*MaxChi));
    Chihalf1=Chi1(iChihalf1);
    [Chihalf2,iChihalf2]=min(abs(Chi1((MaxLoc:length(Chi1)))-0.5*MaxChi));
    iChihalf2=iChihalf2+MaxLoc-1;
    Chihalf2=Chi1(iChihalf2);
    T1_Chihalf=TAvrgs(iChihalf1);
    T2_Chihalf=TAvrgs(iChihalf2);
    
    %-------------------
    
    %Finding Tf Using dq/dt
    %-------------------
    %MaxLoc=0;
    num=0;
    [Maxdq,MaxLoc]=max(Chi2);
    %{
    Maxdq=max(Chi2);
    for T=MinTAvrg:dTAvrg:MaxTAvrg
        num=num+1;
        if (Chi2(num)==Maxdq)
            MaxLoc=num;
        end
    end
    if (MaxLoc==0)
        S='Error on Finding MaxLoc, dq/dt'
        Tdq = 0;
        Maxdq = 0;
    else
    %}
    Tdq = TAvrgs(MaxLoc);
    Maxdq = Chi2(MaxLoc);
    %Finding Tdq error
    Chimin = Chi2(MaxLoc)-Chi2error(MaxLoc);
    Tdqdown = Tdq;
    Tdqup = Tdq;
    num=0;
    for T=MinTAvrg:dTAvrg:MaxTAvrg
        num=num+1;
        if ((Chi2(num)+Chi2error(num))>=Chimin)
            if (TAvrgs(num)<Tdqdown)
                Tdqdown=TAvrgs(num);
            elseif (TAvrgs(num)>Tdqup)
                Tdqup=TAvrgs(num);
            end
        end
    end
    %end

    [dqhalf1,idqhalf1]=min(abs(Chi2(1:MaxLoc)-0.5*Maxdq));
    dqhalf1=Chi2(idqhalf1);
    [dqhalf2,idqhalf2]=min(abs(Chi2((MaxLoc:length(Chi2)))-0.5*Maxdq));
    idqhalf2=idqhalf2+MaxLoc-1;
    dqhalf2=Chi2(idqhalf2);
    T1_dqhalf=TAvrgs(idqhalf1);
    T2_dqhalf=TAvrgs(idqhalf2);
    %-------------------

    clear Avrg Avrgerror Avrg2 Avrg2error Chi1 Chi1error Chi2 Chi2error;
    %---------------------------------------------------------
   
    clear UtotHist1 nAlphaHist1 nAlphaHist gk gkerror;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    
    %writing T_f Values
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    Tf(Foldernum,1:10)=[TCv,TCv-TCvdown,TCvup-TCv,TChi,TChi-TChidown,TChiup-TChi,Tdq,Tdq-Tdqdown,Tdqup-Tdq,Tq];%,Tq-Tqdown,Tqup-Tq,T_f_P_Utot,T_f_P_nAlpha
    MaxValsCv(Foldernum,1:6)=[MaxCv,T2_Cvhalf-T1_Cvhalf,T1_Cvhalf,T2_Cvhalf,Cvhalf1,Cvhalf2];
    MaxValsChi(Foldernum,1:6)=[MaxChi,T2_Chihalf-T1_Chihalf,T1_Chihalf,T2_Chihalf,Chihalf1,Chihalf2];
    MaxValsdq(Foldernum,1:6)=[Maxdq,T2_dqhalf-T1_dqhalf,T1_dqhalf,T2_dqhalf,dqhalf1,dqhalf2];
    %Vals_q_p(Foldernum,1:5)=[valq,pfuf_Utot,pfuf_Utot_2,pfuf_nAlpha,pfuf_nAlpha_2];
    
    Foldernum = Foldernum+1;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    

    %*%*%*%*%*%*%*%*%*%*%*%*%*%*%*%*%*%
    if eNPStrength~=0
        %nAlphaeNP
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
        A=xlsread(strcat(FigPath,'3-DOS\ExcelFiles\nAlphaeNP\',FolderName,'_gk_nAlphaeNP.xls'),1);
        nnAlphaHist=A(1,1);
        neNPHist=A(2,1);
        nAlphaHist1=A(1:nnAlphaHist,2);
        eNPHist1=A(1:neNPHist,3);
        gk=A(1:neNPHist,4:(3+nnAlphaHist));
        clear A;

        A=xlsread(strcat(FigPath,'3-DOS\ExcelFiles\nAlphaeNP\',FolderName,'_gk_nAlphaeNP.xls'),2);
        gkerror=A(1:neNPHist,1:nnAlphaHist);%4:(3+nnAlphaHist)
        clear A;

        A=xlsread(strcat(FigPath,'3-DOS\ExcelFiles\nAlphaeNP\',FolderName,'_gk_nAlphaeNP.xls'),3);
        UAvrg=A(1:neNPHist,1:nnAlphaHist);%4:(3+nnAlphaHist)
        clear A;
    
        %Free Energy calculation vs nAlphaeNP at different Temperatures
        %---------------------------------------------------------
        num=0;
        for T=MinTFE:dTFEnAlphaeNP:MaxTFE
            for k2=1:nnAlphaHist
                for k1=1:neNPHist
                    if (gk(k1,k2)==0)
                        FE(k1,k2)=NaN;
                    else
                        FE(k1,k2)= (eNPHist1(k1)-nAlphaHist1(k2)+UAvrg(k1,k2)) - T*log(gk(k1,k2));
                        FEerror(k1,k2)=sqrt( (T/gk(k1,k2))^2 * gkerror(k1,k2)^2);
                    end
                end
            end

            %Write in excel
            xlswrite(strcat(FigPath,'4-FreeEnergy\ExcelFiles\nAlphaeNP\',FolderName,'T=',num2str(T),'.xls'),neNPHist,1,'a1');
            xlswrite(strcat(FigPath,'4-FreeEnergy\ExcelFiles\nAlphaeNP\',FolderName,'T=',num2str(T),'.xls'),nnAlphaHist,1,'a2');
            xlswrite(strcat(FigPath,'4-FreeEnergy\ExcelFiles\nAlphaeNP\',FolderName,'T=',num2str(T),'.xls'),eNPHist1',1,'b1');
            xlswrite(strcat(FigPath,'4-FreeEnergy\ExcelFiles\nAlphaeNP\',FolderName,'T=',num2str(T),'.xls'),nAlphaHist1,1,'c1');
            xlswrite(strcat(FigPath,'4-FreeEnergy\ExcelFiles\nAlphaeNP\',FolderName,'T=',num2str(T),'.xls'),FE',1,'d1');
            xlswrite(strcat(FigPath,'4-FreeEnergy\ExcelFiles\nAlphaeNP\',FolderName,'T=',num2str(T),'.xls'),FEerror',2,'d1');


            %making figure
            figure;
            %surfc(nAlphaHist1,eNPHist1,FE);
            %alpha(0.3);
            contourf(nAlphaHist1,eNPHist1,FE,50);
            colormap gray;
            colorbar;
            title(strcat(FolderName,'-nAlphaeNP-T=',num2str(T)));
            print('-dpng',strcat(FigPath,'4-FreeEnergy\Figs\nAlphaeNP\',FolderName,'-flat-T=',num2str(T),'.png'));
            saveas(gcf,strcat(FigPath,'4-FreeEnergy\Figs\nAlphaeNP\',FolderName,'-flat-T=',num2str(T),'.fig'));
            close;
            
            figure;
            surfc(nAlphaHist1,eNPHist1,FE);
            alpha(0.3);
            title(strcat(FolderName,'-nAlphaeNP-T=',num2str(T)));
            print('-dpng',strcat(FigPath,'4-FreeEnergy\Figs\nAlphaeNP\',FolderName,'-T=',num2str(T),'.png'));
            saveas(gcf,strcat(FigPath,'4-FreeEnergy\Figs\nAlphaeNP\',FolderName,'-T=',num2str(T),'.fig'));
            close;

            %{
            hold on;
            title(strcat(FolderName,'-errror-nAlphaeNP-T=',num2str(T)));
            surfc(nAlphaHist1,eNPHist1,FE+FEerror);
            alpha(0.3);
            print('-dpng',strcat(FigPath,'4-FreeEnergy\Figs\nAlphaeNP\',FolderName,'-Error-T=',num2str(T),'.png'));
            saveas(gcf,strcat(FigPath,'4-FreeEnergy\Figs\nAlphaeNP\',FolderName,'-Error-T=',num2str(T),'.fig'));
            close;
            %}

            num=num+1;
            clear FE FEerror;
        end
        %---------------------------------------------------------

%{
        %Average nAlphaeNP Correlation calculation at different Temperatures
        %---------------------------------------------------------
        num=0;
        for T=MinTAvrg:dTAvrgnAlphaeNP:MaxTAvrg
            num=num+1;
            Den=0;
            NumnAlpha=0;
            NumnAlpha2=0;
            NumeNP=0;
            NumeNP2=0;
            NumnAlphaeNP=0;
            for k1=1:neNPHist
                for k2=1:nnAlphaHist
                    gexpE=gk(k1,k2)*exp(-(eNPHist1(k1)-nAlphaHist1(k2)+UAvrg(k1,k2))/T);
                    Den=Den+gexpE;
                    NumnAlpha=NumnAlpha+nAlphaHist1(k2)*gexpE;
                    NumnAlpha2=NumnAlpha2+nAlphaHist1(k2)^2*gexpE;
                    NumeNP=NumeNP+eNPHist1(k1)*gexpE;
                    NumeNP2=NumeNP2+eNPHist1(k1)^2*gexpE;
                    NumnAlphaeNP=NumnAlphaeNP+nAlphaHist1(k2)*eNPHist1(k1)*gexpE;
                end
            end
            AvrgnAlpha(num) = NumnAlpha/Den;
            AvrgnAlpha2(num) = NumnAlpha2/Den;
            AvrgeNP(num) = NumeNP/Den;
            AvrgeNP2(num) = NumeNP2/Den;
            AvrgnAlphaeNP(num) = NumnAlphaeNP/Den;

            error2nAlpha=0;
            error2nAlpha2=0;
            error2eNP=0;
            error2eNP2=0;
            error2nAlphaeNP=0;
            for k1=1:neNPHist
                for k2=1:nnAlphaHist
                    CoefnAlpha = exp(-(eNPHist1(k1)-nAlphaHist1(k2)+UAvrg(k1,k2))/T)*(nAlphaHist1(k2)*Den-NumnAlpha)/Den^2;
                    error2nAlpha = error2nAlpha + CoefnAlpha^2*gkerror(k1,k2)^2;
                    
                    CoefnAlpha2 = exp(-(eNPHist1(k1)-nAlphaHist1(k2)+UAvrg(k1,k2))/T)*(nAlphaHist1(k2)^2*Den-NumnAlpha2)/Den^2;
                    error2nAlpha2 = error2nAlpha2 + CoefnAlpha2^2*gkerror(k1,k2)^2;
                    
                    CoefeNP = exp(-(eNPHist1(k1)-nAlphaHist1(k2)+UAvrg(k1,k2))/T)*(eNPHist1(k1)*Den-NumeNP)/Den^2;
                    error2eNP = error2eNP + CoefeNP^2*gkerror(k1,k2)^2;
                    
                    CoefeNP2 = exp(-(eNPHist1(k1)-nAlphaHist1(k2)+UAvrg(k1,k2))/T)*(eNPHist1(k1)^2*Den-NumeNP2)/Den^2;
                    error2eNP2 = error2eNP2 + CoefeNP2^2*gkerror(k1,k2)^2;
                    
                    CoefnAlphaeNP = exp(-(eNPHist1(k1)-nAlphaHist1(k2)+UAvrg(k1,k2))/T)*(nAlphaHist1(k2)*eNPHist1(k1)*Den-NumnAlphaeNP)/Den^2;
                    error2nAlphaeNP = error2nAlphaeNP + CoefnAlphaeNP^2*gkerror(k1,k2)^2;
                end
            end
            AvrgnAlphaerror(num)=sqrt(error2nAlpha);
            AvrgnAlpha2error(num)=sqrt(error2nAlpha2);
            AvrgeNPerror(num)=sqrt(error2eNP);
            AvrgeNP2error(num)=sqrt(error2eNP2);
            AvrgnAlphaeNPerror(num)=sqrt(error2nAlphaeNP);
            
            a=AvrgnAlphaeNP(num);
            b=AvrgnAlpha(num);
            c=AvrgeNP(num);
            d=AvrgnAlpha2(num);
            e=AvrgeNP2(num);
            Radical = sqrt((d-b^2)*(e-c^2));
            
            CorrnAlphaeNP(num) = -((a-b*c)/Radical);
            
            S1 = (AvrgnAlphaeNPerror(num)/Radical)^2;
            S2 = (AvrgnAlphaerror(num)*(-c/Radical+b*(a-b*c)*(e-c^2)/Radical^3))^2;
            S3 = (AvrgeNPerror(num)*(-b/Radical+c*(a-b*c)*(d-b^2)/Radical^3))^2;
            S4 = (AvrgnAlpha2error(num)*(-1/2*(a-b*c)*(e-c^2)/Radical^3))^2;
            S5 = (AvrgeNP2error(num)*(-1/2*(a-b*c)*(d-b^2)/Radical^3))^2;
            CorrnAlphaeNPerror(num) = sqrt(S1+S2+S3+S4+S5);
            
        end

        %Write in excel
        xlswrite(strcat(FigPath,'Averages\nAlphaeNP\',FolderName,'_Averages_nAlphaeNPCorr vs T.xls'),(MinTAvrg:dTAvrgnAlphaeNP:MaxTAvrg)',1,'a1');
        xlswrite(strcat(FigPath,'Averages\nAlphaeNP\',FolderName,'_Averages_nAlphaeNPCorr vs T.xls'),CorrnAlphaeNP',1,'b1');
        xlswrite(strcat(FigPath,'Averages\nAlphaeNP\',FolderName,'_Averages_nAlphaeNPCorr vs T.xls'),CorrnAlphaeNPerror',1,'c1');

        %making a total figure
        figure;
        errorbar((MinTAvrg:dTAvrgnAlphaeNP:MaxTAvrg),CorrnAlphaeNP,CorrnAlphaeNPerror,'.:');
        title(strcat(TrueFolderName,'-Averages-nAlphaeNP Correlation vs T'));
        print('-djpeg',strcat(FigPath,'Averages\nAlphaeNP\',FolderName,'_Averages_nAlphaeNPCorr vs T.jpeg'));
        saveas(gcf,strcat(FigPath,'Averages\nAlphaeNP\',FolderName,'_Averages_nAlphaeNPCorr vs T.fig'));
        close;
        
        clear CorrnAlphaeNP CorrnAlphaeNPerror AvrgnAlpha AvrgnAlphaerror AvrgnAlpha2 AvrgnAlpha2error;
        clear AvrgeNP AvrgeNPerror AvrgeNP2 AvrgeNP2error AvrgnAlphaeNP AvrgnAlphaeNPerror;
        %---------------------------------------------------------
        %}

        clear eNPHist1 nAlphaeNPHist1 nAlphaeNPHist gk gkerror UAvrg;
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    end
 
    %nAlphanBeta
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    A=xlsread(strcat(FigPath,'3-DOS\ExcelFiles\nAlphanBeta\',FolderName,'_gk_nAlphanBeta.xls'),1);
    nnAlphaHist=A(1,1);
    nnBetaHist=A(2,1);
    nAlphaHist1=A(1:nnAlphaHist,2);
    nBetaHist1=A(1:nnBetaHist,3);
    gk=A(1:nnBetaHist,4:(3+nnAlphaHist));
    clear A;

    A=xlsread(strcat(FigPath,'3-DOS\ExcelFiles\nAlphanBeta\',FolderName,'_gk_nAlphanBeta.xls'),2);
    gkerror=A(1:nnBetaHist,1:nnAlphaHist);%4:(3+nnAlphaHist)
    clear A;

    A=xlsread(strcat(FigPath,'3-DOS\ExcelFiles\nAlphanBeta\',FolderName,'_gk_nAlphanBeta.xls'),3);
    UAvrg=A(1:nnBetaHist,1:nnAlphaHist);%4:(3+nnAlphaHist)
    clear A;

    %Free Energy calculation vs nAlphanBeta at different Temperatures
    %---------------------------------------------------------
    num=0;
    for T=MinTFE:dTFEnAlphanBeta:MaxTFE
        for k2=1:nnAlphaHist
            for k1=1:nnBetaHist
                if (gk(k1,k2)==0)
                    FE(k1,k2)=NaN;
                else
                    FE(k1,k2)= (-nBetaHist1(k1)-nAlphaHist1(k2)+UAvrg(k1,k2)) - T*log(gk(k1,k2));
                    FEerror(k1,k2)=sqrt( (T/gk(k1,k2))^2 * gkerror(k1,k2)^2);
                end
            end
        end

        %Write in excel
        xlswrite(strcat(FigPath,'4-FreeEnergy\ExcelFiles\nAlphanBeta\',FolderName,'T=',num2str(T),'.xls'),nnBetaHist,1,'a1');
        xlswrite(strcat(FigPath,'4-FreeEnergy\ExcelFiles\nAlphanBeta\',FolderName,'T=',num2str(T),'.xls'),nnAlphaHist,1,'a2');
        xlswrite(strcat(FigPath,'4-FreeEnergy\ExcelFiles\nAlphanBeta\',FolderName,'T=',num2str(T),'.xls'),nBetaHist1',1,'b1');
        xlswrite(strcat(FigPath,'4-FreeEnergy\ExcelFiles\nAlphanBeta\',FolderName,'T=',num2str(T),'.xls'),nAlphaHist1,1,'c1');
        xlswrite(strcat(FigPath,'4-FreeEnergy\ExcelFiles\nAlphanBeta\',FolderName,'T=',num2str(T),'.xls'),FE',1,'d1');
        xlswrite(strcat(FigPath,'4-FreeEnergy\ExcelFiles\nAlphanBeta\',FolderName,'T=',num2str(T),'.xls'),FEerror',2,'d1');


        %making figure
        figure;
        %surfc(nAlphaHist1,nBetaHist1,FE);
        %alpha(0.3);
        contourf(nAlphaHist1,nBetaHist1,FE,50);
        colormap gray;
        colorbar;
        title(strcat(FolderName,'-nAlphanBeta-T=',num2str(T)));
        print('-dpng',strcat(FigPath,'4-FreeEnergy\Figs\nAlphanBeta\',FolderName,'-flat-T=',num2str(T),'.png'));
        saveas(gcf,strcat(FigPath,'4-FreeEnergy\Figs\nAlphanBeta\',FolderName,'-flat-T=',num2str(T),'.fig'));
        close;

        figure;
        surfc(nAlphaHist1,nBetaHist1,FE);
        alpha(0.3);
        title(strcat(FolderName,'-nAlphanBeta-T=',num2str(T)));
        print('-dpng',strcat(FigPath,'4-FreeEnergy\Figs\nAlphanBeta\',FolderName,'-T=',num2str(T),'.png'));
        saveas(gcf,strcat(FigPath,'4-FreeEnergy\Figs\nAlphanBeta\',FolderName,'-T=',num2str(T),'.fig'));
        close;

        %{
        hold on;
        title(strcat(FolderName,'-errror-nAlphanBeta-T=',num2str(T)));
        surfc(nAlphaHist1,nBetaHist1,FE+FEerror);
        alpha(0.3);
        print('-dpng',strcat(FigPath,'4-FreeEnergy\Figs\nAlphanBeta\',FolderName,'-Error-T=',num2str(T),'.png'));
        saveas(gcf,strcat(FigPath,'4-FreeEnergy\Figs\nAlphanBeta\',FolderName,'-Error-T=',num2str(T),'.fig'));
        close;
        %}

        num=num+1;
        clear FE FEerror;
    end
    %---------------------------------------------------------

    clear nBetaHist1 nAlphanBetaHist1 nAlphanBetaHist gk gkerror UAvrg;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    
    %nAlphanNonAlpha
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    A=xlsread(strcat(FigPath,'3-DOS\ExcelFiles\nAlphanNonAlpha\',FolderName,'_gk_nAlphanNonAlpha.xls'),1);
    nnAlphaHist=A(1,1);
    nnNonAlphaHist=A(2,1);
    nAlphaHist1=A(1:nnAlphaHist,2);
    nNonAlphaHist1=A(1:nnNonAlphaHist,3);
    gk=A(1:nnNonAlphaHist,4:(3+nnAlphaHist));
    clear A;

    A=xlsread(strcat(FigPath,'3-DOS\ExcelFiles\nAlphanNonAlpha\',FolderName,'_gk_nAlphanNonAlpha.xls'),2);
    gkerror=A(1:nnNonAlphaHist,1:nnAlphaHist);%4:(3+nnAlphaHist)
    clear A;

    A=xlsread(strcat(FigPath,'3-DOS\ExcelFiles\nAlphanNonAlpha\',FolderName,'_gk_nAlphanNonAlpha.xls'),3);
    UAvrg=A(1:nnNonAlphaHist,1:nnAlphaHist);%4:(3+nnAlphaHist)
    clear A;

    %Free Energy calculation vs nAlphanNonAlpha at different Temperatures
    %---------------------------------------------------------
    num=0;
    for T=MinTFE:dTFEnAlphanNonAlpha:MaxTFE
        for k2=1:nnAlphaHist
            for k1=1:nnNonAlphaHist
                if (gk(k1,k2)==0)
                    FE(k1,k2)=NaN;
                else
                    FE(k1,k2)= (-nNonAlphaHist1(k1)-nAlphaHist1(k2)+UAvrg(k1,k2)) - T*log(gk(k1,k2));
                    FEerror(k1,k2)=sqrt( (T/gk(k1,k2))^2 * gkerror(k1,k2)^2);
                end
            end
        end

        %Write in excel
        xlswrite(strcat(FigPath,'4-FreeEnergy\ExcelFiles\nAlphanNonAlpha\',FolderName,'T=',num2str(T),'.xls'),nnNonAlphaHist,1,'a1');
        xlswrite(strcat(FigPath,'4-FreeEnergy\ExcelFiles\nAlphanNonAlpha\',FolderName,'T=',num2str(T),'.xls'),nnAlphaHist,1,'a2');
        xlswrite(strcat(FigPath,'4-FreeEnergy\ExcelFiles\nAlphanNonAlpha\',FolderName,'T=',num2str(T),'.xls'),nNonAlphaHist1',1,'b1');
        xlswrite(strcat(FigPath,'4-FreeEnergy\ExcelFiles\nAlphanNonAlpha\',FolderName,'T=',num2str(T),'.xls'),nAlphaHist1,1,'c1');
        xlswrite(strcat(FigPath,'4-FreeEnergy\ExcelFiles\nAlphanNonAlpha\',FolderName,'T=',num2str(T),'.xls'),FE',1,'d1');
        xlswrite(strcat(FigPath,'4-FreeEnergy\ExcelFiles\nAlphanNonAlpha\',FolderName,'T=',num2str(T),'.xls'),FEerror',2,'d1');


        %making figure
        figure;
        %surfc(nAlphaHist1,nNonAlphaHist1,FE);
        %alpha(0.3);
        contourf(nAlphaHist1,nNonAlphaHist1,FE,50);
        colormap gray;
        colorbar;
        title(strcat(FolderName,'-nAlphanNonAlpha-T=',num2str(T)));
        print('-dpng',strcat(FigPath,'4-FreeEnergy\Figs\nAlphanNonAlpha\',FolderName,'-flat-T=',num2str(T),'.png'));
        saveas(gcf,strcat(FigPath,'4-FreeEnergy\Figs\nAlphanNonAlpha\',FolderName,'-flat-T=',num2str(T),'.fig'));
        close;

        figure;
        surfc(nAlphaHist1,nNonAlphaHist1,FE);
        alpha(0.3);
        title(strcat(FolderName,'-nAlphanNonAlpha-T=',num2str(T)));
        print('-dpng',strcat(FigPath,'4-FreeEnergy\Figs\nAlphanNonAlpha\',FolderName,'-T=',num2str(T),'.png'));
        saveas(gcf,strcat(FigPath,'4-FreeEnergy\Figs\nAlphanNonAlpha\',FolderName,'-T=',num2str(T),'.fig'));
        close;

        %{
        hold on;
        title(strcat(FolderName,'-errror-nAlphanNonAlpha-T=',num2str(T)));
        surfc(nAlphaHist1,nNonAlphaHist1,FE+FEerror);
        alpha(0.3);
        print('-dpng',strcat(FigPath,'4-FreeEnergy\Figs\nAlphanNonAlpha\',FolderName,'-Error-T=',num2str(T),'.png'));
        saveas(gcf,strcat(FigPath,'4-FreeEnergy\Figs\nAlphanNonAlpha\',FolderName,'-Error-T=',num2str(T),'.fig'));
        close;
        %}

        num=num+1;
        clear FE FEerror;
    end
    %---------------------------------------------------------

    clear nNonAlphaHist1 nAlphanNonAlphaHist1 nAlphanNonAlphaHist gk gkerror UAvrg;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    
    %*%*%*%*%*%*%*%*%*%*%*%*%*%*%*%*%*%
    clear TAvrgs TFEs;
end

%Write in excel
xlswrite(strcat(FigPath,'4-FreeEnergy\Tf.xls'),AllFNs,'Tf','A1:C104');%RunsNum
xlswrite(strcat(FigPath,'4-FreeEnergy\Tf.xls'),Tf,'Tf','d1');
xlswrite(strcat(FigPath,'4-FreeEnergy\Tf.xls'),MaxValsCv,'MaxCv','d1');
xlswrite(strcat(FigPath,'4-FreeEnergy\Tf.xls'),MaxValsChi,'MaxChi','d1');
xlswrite(strcat(FigPath,'4-FreeEnergy\Tf.xls'),MaxValsdq,'Maxdq','d1');
%xlswrite(strcat(FigPath,'4-FreeEnergy\Tf.xls'),Vals_q_p,'Vals_q_p','d1');

clear Tf MaxValsCv MaxValsChi MaxValsdq Vals_q_p;

fclose(FNs);


