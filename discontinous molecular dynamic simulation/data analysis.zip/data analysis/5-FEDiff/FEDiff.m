clear all;
clc;
MainPath = 'C:\Users\congyue wang\Documents\Visual Studio 2012\Projects\l=9_modified\';
FigPath = 'C:\Users\congyue wang\Documents\Visual Studio 2012\Projects\l=9_modified\data analysis\';
FolderNames = strcat(FigPath,'FolderNames.txt');
FNs = fopen(FolderNames,'r');
Runsnum=104;
AllFNs(1:Runsnum,1:3)=0;
for Foldernum=1:12;


%while ~(feof(FNs))
    %-------------------------------
    A = textscan(FNs,'%[^\n]',1);
    FolderName = cell2mat(A{1,1});
    clear A;
    %-------------------------------

    n =str2double(FolderName(1:2));  %n
    eNPStrength =str2double(FolderName(4:8));  %eNP
    npsize =str2double(FolderName(10:14));  %h
    
    AllFNs(Foldernum,1)=n;  %n
    AllFNs(Foldernum,2)=eNPStrength;  %eNP
    AllFNs(Foldernum,3)=npsize;  %h

    
    %nAlpha
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    A=xlsread(strcat(FigPath,'3-DOS\ExcelFiles\nAlpha\',FolderName,'_gk_nAlpha.xls'),1);
    nnAlphaHist=A(1,1);
    nUtotHist=A(2,1);
    nAlphaHist1=A(1:nnAlphaHist,2);
    UtotHist1=A(1:nUtotHist,3);
    gk=A(1:nUtotHist,4:(3+nnAlphaHist));
    clear A;

    A=xlsread(strcat(FigPath,'3-DOS\ExcelFiles\nAlpha\',FolderName,'_gk_nAlpha.xls'),2);
    gkerror=A(1:nUtotHist,1:nnAlphaHist);%4:(3+nnAlphaHist)
    clear A;
    
    LowLimitnAlpha=floor((nnAlphaHist-1)*0.25)+1; %floor is to restrict UF basin
    HighLimitnAlpha=round((nnAlphaHist-1)*0.75)+1;
    
    gk=gk';
    gkerror=gkerror';
    
    
    %Find S and UAvrg for UF Basin, nAlpha=0
    sumgk=0;
    sumgkerr2=0;
    sumU=0;
    sumU2=0;
    count=0;
    for i=1:1
        for j=1:nUtotHist
            gkij=gk(i,j);
            if gkij>0
                sumgk=sumgk+gkij;
                sumgkerr2=sumgkerr2+gkerror(i,j)*gkerror(i,j)/(gkij*gkij);
                sumU=sumU+gkij*UtotHist1(j);
                sumU2=sumU2+gkij*UtotHist1(j)*UtotHist1(j);
                count=count+1;
            end
        end
    end
    UAvrg_UF=sumU/sumgk;
    UAvrg_UF_err=sqrt(sumU2/sumgk-UAvrg_UF*UAvrg_UF);
    S_UF=sumgk/count;%
    S_UF_err=sqrt(sumgkerr2)*S_UF;
    S_UF_err=log(S_UF+S_UF_err)-log(S_UF);
    S_UF=log(S_UF);
    
    %Find S and UAvrg for F Basin, nAlpha=max
    sumgk=0;
    sumgkerr2=0;
    sumU=0;
    sumU2=0;
    count=0;
    for i=nnAlphaHist:nnAlphaHist
        for j=1:nUtotHist
            gkij=gk(i,j);
            if gkij>0
                sumgk=sumgk+gkij;
                sumgkerr2=sumgkerr2+gkerror(i,j)*gkerror(i,j)/(gkij*gkij);
                sumU=sumU+gkij*UtotHist1(j);
                sumU2=sumU2+gkij*UtotHist1(j)*UtotHist1(j);
                count=count+1;
            end
        end
    end
    if sumgk==0     %added only for 30-0.25-1.28 where gk(nAlphaMax)=0
        sumgk=0;
        sumgkerr2=0;
        sumU=0;
        sumU2=0;
        count=0;
        for i=nnAlphaHist-1:nnAlphaHist-1
            for j=1:nUtotHist
                gkij=gk(i,j);
                if gkij>0
                    sumgk=sumgk+gkij;
                    sumgkerr2=sumgkerr2+gkerror(i,j)*gkerror(i,j)/(gkij*gkij);
                    sumU=sumU+gkij*UtotHist1(j);
                    sumU2=sumU2+gkij*UtotHist1(j)*UtotHist1(j);
                    count=count+1;
                end
            end
        end
    end
    UAvrg_F=sumU/sumgk;
    UAvrg_F_err=sqrt(sumU2/sumgk-UAvrg_F*UAvrg_F);
    S_F=sumgk/count;%
    S_F_err=sqrt(sumgkerr2)*S_F;
    S_F_err=log(S_F+S_F_err)-log(S_F);
    S_F=log(S_F);
    
    
    
    %Find TSE location on the basis of 
    T=abs((UAvrg_UF-UAvrg_F)/(S_UF-S_F));
    for k1=1:nnAlphaHist
        Sum=0;
        error2=0;
        for k2=1:nUtotHist
            Sum=Sum+gk(k1,k2)*exp(-UtotHist1(k2)/T);
            error2 = error2 + T^2*exp(-2*UtotHist1(k2)/T)*gkerror(k1,k2)^2;
        end
        FE(k1)=-T*log(Sum);
        FEerror(k1)=sqrt(error2/Sum^2);
    end
    for i=2:nnAlphaHist-1
        if (FE(i)>FE(i-1)) && (FE(i)>FE(i+1))
            break;
        end
    end
    if i<nnAlphaHist*0.75
        TSEloc=i;
    else
        TSEloc=round(nnAlphaHist/2);
    end
    TSElocs(Foldernum)=TSEloc;

    
    figure;
    errorbar(nAlphaHist1,FE,FEerror,'-ok','LineWidth',2);
    title(strcat(FolderName,'-FE-nAlpha-Tf=',num2str(T)));
    print('-dpng',strcat(FigPath,'5-FEDiff\Figs\',FolderName,'-Tf=',num2str(T),'.png'));
    saveas(gcf,strcat(FigPath,'5-FEDiff\Figs\',FolderName,'-Tf=',num2str(T),'.fig'));
    close;
    
    clear FE FEerror;

    %Find S and UAvrg for TSE Basin, nAlpha=nAlphaHist1(TSEloc)
    sumgk=0;
    sumgkerr2=0;
    sumU=0;
    sumU2=0;
    count=0;
    for i=TSEloc:TSEloc
        for j=1:nUtotHist
            gkij=gk(i,j);
            if gkij>0
                sumgk=sumgk+gkij;
                sumgkerr2=sumgkerr2+gkerror(i,j)*gkerror(i,j)/(gkij*gkij);
                sumU=sumU+gkij*UtotHist1(j);
                sumU2=sumU2+gkij*UtotHist1(j)*UtotHist1(j);
                count=count+1;
            end
        end
    end
    UAvrg_TSE=sumU/sumgk;
    UAvrg_TSE_err=sqrt(sumU2/sumgk-UAvrg_TSE*UAvrg_TSE);
    S_TSE=sumgk/count;%
    S_TSE_err=sqrt(sumgkerr2)*S_TSE;
    S_TSE_err=log(S_TSE+S_TSE_err)-log(S_TSE);
    S_TSE=log(S_TSE);
    
    
    S_nAlpha(Foldernum,1:12)=[S_F,S_UF,S_TSE,S_F_err,S_UF_err,S_TSE_err,UAvrg_F,UAvrg_UF,UAvrg_TSE,UAvrg_F_err,UAvrg_UF_err,UAvrg_TSE_err];
    
    dS_UF_err=sqrt(S_UF_err*S_UF_err/(S_UF*S_UF)+S_F_err*S_F_err/(S_F*S_F))*(S_UF-S_F);
    dS_TSE_err=sqrt(S_TSE_err*S_TSE_err/(S_TSE*S_TSE)+S_F_err*S_F_err/(S_F*S_F))*(S_TSE-S_F);
    dS_nAlpha(Foldernum,1:6)=[S_UF-S_F,S_TSE-S_F,dS_UF_err,dS_TSE_err,UAvrg_UF-UAvrg_F,UAvrg_TSE-UAvrg_F];

    Ts_nAlpha(Foldernum,1:2)=[abs((UAvrg_UF-UAvrg_F)/(S_UF-S_F)) , abs(dS_UF_err*(UAvrg_UF-UAvrg_F)/((S_UF-S_F)*(S_UF-S_F)))];
    
    
    
   
    %-------------------------------------------------
    %Find S and UAvrg for UF Basin, nAlpha<=LowLimit
    sumgk=0;
    sumgkerr2=0;
    sumU=0;
    count=0;
    for i=1:LowLimitnAlpha
        for j=1:nUtotHist
            gkij=gk(i,j);
            if gkij>0
                sumgk=sumgk+gkij;
                sumgkerr2=sumgkerr2+gkerror(i,j)*gkerror(i,j)/(gkij*gkij);
                sumU=sumU+gkij*UtotHist1(j);
                count=count+1;
            end
        end
    end
    UAvrg_UF=sumU/sumgk;
    S_UF=sumgk/count;%
    S_UF_err=sqrt(sumgkerr2)*S_UF;
    S_UF_err=log(S_UF+S_UF_err)-log(S_UF);
    S_UF=log(S_UF);
    
    %Find S and UAvrg for F Basin, nAlpha>=HighLimit
    sumgk=0;
    sumgkerr2=0;
    sumU=0;
    count=0;
    for i=HighLimitnAlpha:nnAlphaHist
        for j=1:nUtotHist
            gkij=gk(i,j);
            if gkij>0
                sumgk=sumgk+gkij;
                sumgkerr2=sumgkerr2+gkerror(i,j)*gkerror(i,j)/(gkij*gkij);
                sumU=sumU+gkij*UtotHist1(j);
                count=count+1;
            end
        end
    end
    UAvrg_F=sumU/sumgk;
    S_F=sumgk/count;%
    S_F_err=sqrt(sumgkerr2)*S_F;
    S_F_err=log(S_F+S_F_err)-log(S_F);
    S_F=log(S_F);
    
    S_nAlpha(Foldernum,13:18)=[S_F,S_UF,S_F_err,S_UF_err,UAvrg_F,UAvrg_UF];
    
    dS_UF_err=sqrt(S_UF_err*S_UF_err/(S_UF*S_UF)+S_F_err*S_F_err/(S_F*S_F))*(S_UF-S_F);
    dS_nAlpha(Foldernum,7:9)=[S_UF-S_F,dS_UF_err,UAvrg_UF-UAvrg_F];

    Ts_nAlpha(Foldernum,3:4)=[abs((UAvrg_UF-UAvrg_F)/(S_UF-S_F)) , abs(dS_UF_err*(UAvrg_UF-UAvrg_F)/((S_UF-S_F)*(S_UF-S_F)))];
       
    clear UtotHist1 nAlphaHist1 nAlphaHist gk gkerror;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    
    %*%*%*%*%*%*%*%*%*%*%*%*%*%*%*%*%*%
    %{
    if eNPStrength~=0
        %nAlphaeNP
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
        A=xlsread(strcat(FigPath,'3-DOS\ExcelFiles\nAlphaeNP\',FolderName,'_gk_nAlphaeNP.xls'),1);
        nnAlphaHist=A(1,1);
        neNPHist=A(2,1);
        nAlphaHist1=A(1:nnAlphaHist,2);
        eNPHist1=A(1:neNPHist,3);
        gk=A(1:neNPHist,4:(3+nnAlphaHist));
        clear A;

        A=xlsread(strcat(FigPath,'3-DOS\ExcelFiles\nAlphaeNP\',FolderName,'_gk_nAlphaeNP.xls'),2);
        gkerror=A(1:neNPHist,1:nnAlphaHist);%4:(3+nnAlphaHist)
        clear A;

        A=xlsread(strcat(FigPath,'3-DOS\ExcelFiles\nAlphaeNP\',FolderName,'_gk_nAlphaeNP.xls'),3);
        UAvrg=A(1:neNPHist,1:nnAlphaHist);%4:(3+nnAlphaHist)
        clear A;
    

        clear eNPHist1 nAlphaeNPHist1 nAlphaeNPHist gk gkerror UAvrg;
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    end
    %}
 
    %nAlphanBeta
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    A=xlsread(strcat(FigPath,'3-DOS\ExcelFiles\nAlphanBeta\',FolderName,'_gk_nAlphanBeta.xls'),1);
    nnAlphaHist=A(1,1);
    nnBetaHist=A(2,1);
    nAlphaHist1=A(1:nnAlphaHist,2);
    nBetaHist1=A(1:nnBetaHist,3);
    gk=A(1:nnBetaHist,4:(3+nnAlphaHist));
    clear A;

    A=xlsread(strcat(FigPath,'3-DOS\ExcelFiles\nAlphanBeta\',FolderName,'_gk_nAlphanBeta.xls'),2);
    gkerror=A(1:nnBetaHist,1:nnAlphaHist);%4:(3+nnAlphaHist)
    clear A;

    A=xlsread(strcat(FigPath,'3-DOS\ExcelFiles\nAlphanBeta\',FolderName,'_gk_nAlphanBeta.xls'),3);
    UAvrg=A(1:nnBetaHist,1:nnAlphaHist);%4:(3+nnAlphaHist)
    clear A;

    gk=gk';
    gkerror=gkerror';
    UAvrg=UAvrg';
    

    %LowLimitnAlpha=round((nnAlphaHist-1)*0.25)+1;
    %HighLimitnAlpha=round((nnAlphaHist-1)*0.75)+1;
    LowLimitnAlpha=floor((nnAlphaHist-1)*0.25)+1; %floor is to restrict UF basin
    HighLimitnAlpha=round((nnAlphaHist-1)*0.75)+1;
    
    %LowLimitnBeta=round(2*floor((n-1)/4)*0.25)+1;
    %HighLimitnBeta=round(2*floor((n-1)/4)*0.75)+1-1;  %-1 is for an alpha-helical HB i-j=4 which is not accounted here
    %LowLimitnBeta=round(floor(n/2)*0.25)+1;
    %HighLimitnBeta=round((floor(n/2)-1)*0.75)+1;  %-1 is for an alpha-helical HB i-j=4 which is not accounted here
    LowLimitnBeta=floor(floor(n/2)*0.25)+1; %floor is to restrict UF basin
    HighLimitnBeta=round((floor(n/2)-1)*0.75)+1;  
     
    %added for cases with big n, HighLimit is not low enough to have nonzero gk 
    if n==30
        HighLimitnBeta=8;
    elseif n==23
        HighLimitnBeta=7;
    elseif n==16
        HighLimitnBeta=6;
    elseif n==9
        HighLimitnBeta=4;
    end
    
    
    %Find S and UAvrg for UF Basin
    sumgk=0;
    sumgkerr2=0;
    sumU=0;
    sumU2=0;
    count=0;
    for i=1:LowLimitnAlpha
        for j=1:LowLimitnBeta
            gkij=gk(i,j);
            if gkij>0
                sumgk=sumgk+gkij;
                sumgkerr2=sumgkerr2+gkerror(i,j)*gkerror(i,j)/(gkij*gkij);
                Utot=UAvrg(i,j)-i-j+2;
                sumU=sumU+gkij*Utot;
                sumU2=sumU2+gkij*Utot*Utot;
                count=count+1;
            end
        end
    end
    UAvrg_UF=sumU/sumgk;
    UAvrg_UF_err=sqrt(sumU2/sumgk-UAvrg_UF*UAvrg_UF);
    S_UF=sumgk/count;%
    S_UF_err=sqrt(sumgkerr2)*S_UF;
    S_UF_err=log(S_UF+S_UF_err)-log(S_UF);
    S_UF=log(S_UF);
        
    %Find S and UAvrg for Alpha Basin
    sumgk=0;
    sumgkerr2=0;
    sumU=0;
    sumU2=0;
    count=0;
    for i=HighLimitnAlpha:nnAlphaHist
        for j=1:nnBetaHist
            gkij=gk(i,j);
            if gkij>0
                sumgk=sumgk+gkij;
                sumgkerr2=sumgkerr2+gkerror(i,j)*gkerror(i,j)/(gkij*gkij);
                Utot=UAvrg(i,j)-i-j+2;
                sumU=sumU+gkij*Utot;
                sumU2=sumU2+gkij*Utot*Utot;
                count=count+1;
            end
        end
    end
    UAvrg_Alpha=sumU/sumgk;
    UAvrg_Alpha_err=sqrt(sumU2/sumgk-UAvrg_Alpha*UAvrg_Alpha);
    S_Alpha=sumgk/count;%
    S_Alpha_err=sqrt(sumgkerr2)*S_Alpha;
    S_Alpha_err=log(S_Alpha+S_Alpha_err)-log(S_Alpha);
    S_Alpha=log(S_Alpha);
        
    %Find S and UAvrg for Beta Basin
    sumgk=0;
    sumgkerr2=0;
    sumU=0;
    sumU2=0;
    count=0;
    for i=1:nnAlphaHist
        for j=HighLimitnBeta:nnBetaHist
            gkij=gk(i,j);
            if gkij>0
                sumgk=sumgk+gkij;
                sumgkerr2=sumgkerr2+gkerror(i,j)*gkerror(i,j)/(gkij*gkij);
                Utot=UAvrg(i,j)-i-j+2;
                sumU=sumU+gkij*Utot;
                sumU2=sumU2+gkij*Utot*Utot;
                count=count+1;
            end
        end
    end
    UAvrg_Beta=sumU/sumgk;
    UAvrg_Beta_err=sqrt(sumU2/sumgk-UAvrg_Beta*UAvrg_Beta);
    S_Beta=sumgk/count;%
    S_Beta_err=sqrt(sumgkerr2)*S_Beta;
    S_Beta_err=log(S_Beta+S_Beta_err)-log(S_Beta);
    S_Beta=log(S_Beta);
        
    S_nAlphanBeta(Foldernum,1:12)=[S_Alpha,S_UF,S_Beta,S_Alpha_err,S_UF_err,S_Beta_err,UAvrg_Alpha,UAvrg_UF,UAvrg_Beta,UAvrg_Alpha_err,UAvrg_UF_err,UAvrg_Beta_err];
    
    dS_UF_err=sqrt(S_UF_err*S_UF_err/(S_UF*S_UF)+S_Alpha_err*S_Alpha_err/(S_Alpha*S_Alpha))*(S_UF-S_Alpha);
    dS_Beta_err=sqrt(S_Beta_err*S_Beta_err/(S_Beta*S_Beta)+S_Alpha_err*S_Alpha_err/(S_Alpha*S_Alpha))*(S_Beta-S_Alpha);
    dS_nAlphanBeta(Foldernum,1:6)=[S_UF-S_Alpha,S_Beta-S_Alpha,dS_UF_err,dS_Beta_err,UAvrg_UF-UAvrg_Alpha,UAvrg_Beta-UAvrg_Alpha];

    ds_Beta_UF_err=sqrt(S_Beta_err*S_Beta_err/(S_Beta*S_Beta)+S_UF_err*S_UF_err/(S_UF*S_UF))*abs(S_Beta-S_UF);
    Ts_nAlphanBeta(Foldernum,1:6)=[abs((UAvrg_UF-UAvrg_Alpha)/(S_UF-S_Alpha)) , abs((UAvrg_Beta-UAvrg_Alpha)/(S_Beta-S_Alpha)) , ...
        abs((UAvrg_Beta-UAvrg_UF)/(S_Beta-S_UF)) , abs(dS_UF_err*(UAvrg_UF-UAvrg_Alpha)/((S_UF-S_Alpha)*(S_UF-S_Alpha))) , ...
        abs(dS_Beta_err*(UAvrg_Beta-UAvrg_Alpha)/((S_Beta-S_Alpha)*(S_Beta-S_Alpha))) , ...
        abs(ds_Beta_UF_err*(UAvrg_Beta-UAvrg_UF)/((S_Beta-S_UF)*(S_Beta-S_UF)))];
    
    clear nAlphaHist1 nBetaHist1 nAlphanBetaHist1 nAlphanBetaHist gk gkerror UAvrg;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    
    %nAlphanNonAlpha
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    A=xlsread(strcat(FigPath,'3-DOS\ExcelFiles\nAlphanNonAlpha\',FolderName,'_gk_nAlphanNonAlpha.xls'),1);
    nnAlphaHist=A(1,1);
    nnNonAlphaHist=A(2,1);
    nAlphaHist1=A(1:nnAlphaHist,2);
    nNonAlphaHist1=A(1:nnNonAlphaHist,3);
    gk=A(1:nnNonAlphaHist,4:(3+nnAlphaHist));
    clear A;

    A=xlsread(strcat(FigPath,'3-DOS\ExcelFiles\nAlphanNonAlpha\',FolderName,'_gk_nAlphanNonAlpha.xls'),2);
    gkerror=A(1:nnNonAlphaHist,1:nnAlphaHist);%4:(3+nnAlphaHist)
    clear A;

    A=xlsread(strcat(FigPath,'3-DOS\ExcelFiles\nAlphanNonAlpha\',FolderName,'_gk_nAlphanNonAlpha.xls'),3);
    UAvrg=A(1:nnNonAlphaHist,1:nnAlphaHist);%4:(3+nnAlphaHist)
    clear A;

    gk=gk';
    gkerror=gkerror';
    UAvrg=UAvrg';
    
    
    LowLimitnAlpha=floor((nnAlphaHist-1)*0.25)+1; %floor is to restrict UF basin
    HighLimitnAlpha=round((nnAlphaHist-1)*0.75)+1;
    
    %LowLimitnNonAlpha=round(floor(n/2)*0.25)+1;  
    %HighLimitnNonAlpha=round(floor(n/2)*0.75)+1-1;   %-1 is for an alpha-helical HB i-j=4 which is not accounted here
    LowLimitnNonAlpha=floor(floor(n/2)*0.25)+1;   %floor is to restrict UF basin
    HighLimitnNonAlpha=round((floor(n/2)-1)*0.75)+1;     
    
    %added for cases with big n, HighLimit is not low enough to have nonzero gk 
    %{
    if n==30    %nbeta=6
        HighLimitnNonAlpha=7;
    elseif n==23
        HighLimitnNonAlpha=6;
    elseif n==16
        HighLimitnNonAlpha=5;
    end
    %}
    if n==30
        HighLimitnNonAlpha=8;
    elseif n==23
        HighLimitnNonAlpha=7;
    elseif n==16
        HighLimitnNonAlpha=6;
    elseif n==9
        HighLimitnNonAlpha=4;
    end
    
    %Find S and UAvrg for UF Basin
    sumgk=0;
    sumgkerr2=0;
    sumU=0;
    sumU2=0;
    count=0;
    for i=1:LowLimitnAlpha
        for j=1:LowLimitnNonAlpha
            gkij=gk(i,j);
            if gkij>0
                sumgk=sumgk+gkij;
                sumgkerr2=sumgkerr2+gkerror(i,j)*gkerror(i,j)/(gkij*gkij);
                Utot=UAvrg(i,j)-i-j+2;
                sumU=sumU+gkij*Utot;
                sumU2=sumU2+gkij*Utot*Utot;
                count=count+1;
            end
        end
    end
    UAvrg_UF=sumU/sumgk;
    UAvrg_UF_err=sqrt(sumU2/sumgk-UAvrg_UF*UAvrg_UF);
    S_UF=sumgk/count;%
    S_UF_err=sqrt(sumgkerr2)*S_UF;
    S_UF_err=log(S_UF+S_UF_err)-log(S_UF);
    S_UF=log(S_UF);
        
    %Find S and UAvrg for UF Basin, with no NonAlpha HB
    sumgk=0;
    sumgkerr2=0;
    sumU=0;
    sumU2=0;
    count=0;
    for i=1:LowLimitnAlpha
        for j=1:1
            gkij=gk(i,j);
            if gkij>0
                sumgk=sumgk+gkij;
                sumgkerr2=sumgkerr2+gkerror(i,j)*gkerror(i,j)/(gkij*gkij);
                Utot=UAvrg(i,j)-i-j+2;
                sumU=sumU+gkij*Utot;
                sumU2=sumU2+gkij*Utot*Utot;
                count=count+1;
            end
        end
    end
    UAvrg_UF_noNon=sumU/sumgk;
    UAvrg_UF_noNon_err=sqrt(sumU2/sumgk-UAvrg_UF_noNon*UAvrg_UF_noNon);
    S_UF_noNon=sumgk/count;%
    S_UF_noNon_err=sqrt(sumgkerr2)*S_UF_noNon;
    S_UF_noNon_err=log(S_UF_noNon+S_UF_noNon_err)-log(S_UF_noNon);
    S_UF_noNon=log(S_UF_noNon);
        
    %Find S and UAvrg for Alpha Basin
    sumgk=0;
    sumgkerr2=0;
    sumU=0;
    sumU2=0;
    count=0;
    for i=HighLimitnAlpha:nnAlphaHist
        for j=1:nnNonAlphaHist
            gkij=gk(i,j);
            if gkij>0
                sumgk=sumgk+gkij;
                sumgkerr2=sumgkerr2+gkerror(i,j)*gkerror(i,j)/(gkij*gkij);
                Utot=UAvrg(i,j)-i-j+2;
                sumU=sumU+gkij*Utot;
                sumU2=sumU2+gkij*Utot*Utot;
                count=count+1;
            end
        end
    end
    UAvrg_Alpha=sumU/sumgk;
    UAvrg_Alpha_err=sqrt(sumU2/sumgk-UAvrg_Alpha*UAvrg_Alpha);
    S_Alpha=sumgk/count;%
    S_Alpha_err=sqrt(sumgkerr2)*S_Alpha;
    S_Alpha_err=log(S_Alpha+S_Alpha_err)-log(S_Alpha);
    S_Alpha=log(S_Alpha);
        
    %Find S and UAvrg for Alpha Basin, with no NonAlpha HB
    sumgk=0;
    sumgkerr2=0;
    sumU=0;
    sumU2=0;
    count=0;
    for i=HighLimitnAlpha:nnAlphaHist
        for j=1:1
            gkij=gk(i,j);
            if gkij>0
                sumgk=sumgk+gkij;
                sumgkerr2=sumgkerr2+gkerror(i,j)*gkerror(i,j)/(gkij*gkij);
                Utot=UAvrg(i,j)-i-j+2;
                sumU=sumU+gkij*Utot;
                sumU2=sumU2+gkij*Utot*Utot;
                count=count+1;
            end
        end
    end
    UAvrg_F_noNon=sumU/sumgk;
    UAvrg_F_noNon_err=sqrt(sumU2/sumgk-UAvrg_F_noNon*UAvrg_F_noNon);
    S_F_noNon=sumgk/count;%
    S_F_noNon_err=sqrt(sumgkerr2)*S_UF_noNon;
    S_F_noNon_err=log(S_F_noNon+S_F_noNon_err)-log(S_F_noNon);
    S_F_noNon=log(S_F_noNon);
        
    %Find S and UAvrg for NonAlpha Basin
    sumgk=0;
    sumgkerr2=0;
    sumU=0;
    sumU2=0;
    count=0;
    for i=1:nnAlphaHist
        for j=HighLimitnNonAlpha:nnNonAlphaHist
            gkij=gk(i,j);
            if gkij>0
                sumgk=sumgk+gkij;
                sumgkerr2=sumgkerr2+gkerror(i,j)*gkerror(i,j)/(gkij*gkij);
                Utot=UAvrg(i,j)-i-j+2;
                sumU=sumU+gkij*Utot;
                sumU2=sumU2+gkij*Utot*Utot;
                count=count+1;
            end
        end
    end
    UAvrg_NonAlpha=sumU/sumgk;
    UAvrg_NonAlpha_err=sqrt(sumU2/sumgk-UAvrg_NonAlpha*UAvrg_NonAlpha);
    S_NonAlpha=sumgk/count;%
    S_NonAlpha_err=sqrt(sumgkerr2)*S_NonAlpha;
    S_NonAlpha_err=log(S_NonAlpha+S_NonAlpha_err)-log(S_NonAlpha);
    S_NonAlpha=log(S_NonAlpha);
        
    S_nAlphanNonAlpha(Foldernum,1:20)=[S_Alpha,S_UF,S_NonAlpha,S_Alpha_err,S_UF_err,S_NonAlpha_err,UAvrg_Alpha,UAvrg_UF,UAvrg_NonAlpha,UAvrg_Alpha_err,UAvrg_UF_err,UAvrg_NonAlpha_err, ...
        S_UF_noNon,S_UF_noNon_err,UAvrg_UF_noNon,UAvrg_UF_noNon_err,S_F_noNon,S_F_noNon_err,UAvrg_F_noNon,UAvrg_F_noNon_err];
    
    dS_UF_err=sqrt(S_UF_err*S_UF_err/(S_UF*S_UF)+S_Alpha_err*S_Alpha_err/(S_Alpha*S_Alpha))*(S_UF-S_Alpha);
    dS_UF_noNon_err=sqrt(S_UF_noNon_err*S_UF_noNon_err/(S_UF_noNon*S_UF_noNon)+S_F_noNon_err*S_F_noNon_err/(S_F_noNon*S_F_noNon))*(S_UF_noNon-S_F_noNon);
    dS_NonAlpha_err=sqrt(S_NonAlpha_err*S_NonAlpha_err/(S_NonAlpha*S_NonAlpha)+S_Alpha_err*S_Alpha_err/(S_Alpha*S_Alpha))*(S_NonAlpha-S_Alpha);
    dS_nAlphanNonAlpha(Foldernum,1:9)=[S_UF-S_Alpha,S_NonAlpha-S_Alpha,dS_UF_err,dS_NonAlpha_err,UAvrg_UF-UAvrg_Alpha,UAvrg_NonAlpha-UAvrg_Alpha,S_UF_noNon-S_F_noNon,dS_UF_noNon_err,UAvrg_UF_noNon-UAvrg_F_noNon];

    ds_NonAlpha_UF_err=sqrt(S_NonAlpha_err*S_NonAlpha_err/(S_NonAlpha*S_NonAlpha)+S_UF_err*S_UF_err/(S_UF*S_UF))*abs(S_NonAlpha-S_UF);
    Ts_nAlphanNonAlpha(Foldernum,1:8)=[abs((UAvrg_UF-UAvrg_Alpha)/(S_UF-S_Alpha)) , abs((UAvrg_NonAlpha-UAvrg_Alpha)/(S_NonAlpha-S_Alpha)) , ...
        abs((UAvrg_NonAlpha-UAvrg_UF)/(S_NonAlpha-S_UF)) , abs(dS_UF_err*(UAvrg_UF-UAvrg_Alpha)/((S_UF-S_Alpha)*(S_UF-S_Alpha))) , ...
        abs(dS_NonAlpha_err*(UAvrg_NonAlpha-UAvrg_Alpha)/((S_NonAlpha-S_Alpha)*(S_NonAlpha-S_Alpha))) , ...
        abs(ds_NonAlpha_UF_err*(UAvrg_NonAlpha-UAvrg_UF)/((S_NonAlpha-S_UF)*(S_NonAlpha-S_UF))) , ...
        abs((UAvrg_UF_noNon-UAvrg_F_noNon)/(S_UF_noNon-S_F_noNon)) , abs(dS_UF_noNon_err*(UAvrg_UF_noNon-UAvrg_F_noNon)/((S_UF_noNon-S_F_noNon)*(S_UF_noNon-S_F_noNon))) ];
    
    clear nAlphaHist1 nNonAlphaHist1 nAlphanNonAlphaHist1 nAlphanNonAlphaHist gk gkerror UAvrg;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    
    %*%*%*%*%*%*%*%*%*%*%*%*%*%*%*%*%*%
    clear TAvrgs TFEs;
    disp(FolderName);
    Foldernum=Foldernum+1;
end

xlswrite(strcat(FigPath,'5-FEDiff\nAlpha.xls'),AllFNs,1,'A1:C104');%RunsNum
xlswrite(strcat(FigPath,'5-FEDiff\nAlpha.xls'),TSElocs',1,'d1');
xlswrite(strcat(FigPath,'5-FEDiff\nAlpha.xls'),AllFNs,'S','A1:C104');
xlswrite(strcat(FigPath,'5-FEDiff\nAlpha.xls'),S_nAlpha,'S','d1');
xlswrite(strcat(FigPath,'5-FEDiff\nAlpha.xls'),AllFNs,'dS','A1:C104');
xlswrite(strcat(FigPath,'5-FEDiff\nAlpha.xls'),dS_nAlpha,'dS','d1');
xlswrite(strcat(FigPath,'5-FEDiff\nAlpha.xls'),AllFNs,'Ts','A1:C104');
xlswrite(strcat(FigPath,'5-FEDiff\nAlpha.xls'),Ts_nAlpha,'Ts','d1');

xlswrite(strcat(FigPath,'5-FEDiff\nAlphanBeta.xls'),AllFNs,'S','A1:C104');%RunsNum
xlswrite(strcat(FigPath,'5-FEDiff\nAlphanBeta.xls'),S_nAlphanBeta,'S','d1');
xlswrite(strcat(FigPath,'5-FEDiff\nAlphanBeta.xls'),AllFNs,'dS','A1:C104');
xlswrite(strcat(FigPath,'5-FEDiff\nAlphanBeta.xls'),dS_nAlphanBeta,'dS','d1');
xlswrite(strcat(FigPath,'5-FEDiff\nAlphanBeta.xls'),AllFNs,'Ts','A1:C104');
xlswrite(strcat(FigPath,'5-FEDiff\nAlphanBeta.xls'),Ts_nAlphanBeta,'Ts','d1');

xlswrite(strcat(FigPath,'5-FEDiff\nAlphanNonAlpha.xls'),AllFNs,'S','A1:C104');%RunsNum
xlswrite(strcat(FigPath,'5-FEDiff\nAlphanNonAlpha.xls'),S_nAlphanNonAlpha,'S','d1');
xlswrite(strcat(FigPath,'5-FEDiff\nAlphanNonAlpha.xls'),AllFNs,'dS','A1:C104');
xlswrite(strcat(FigPath,'5-FEDiff\nAlphanNonAlpha.xls'),dS_nAlphanNonAlpha,'dS','d1');
xlswrite(strcat(FigPath,'5-FEDiff\nAlphanNonAlpha.xls'),AllFNs,'Ts','A1:C104');
xlswrite(strcat(FigPath,'5-FEDiff\nAlphanNonAlpha.xls'),Ts_nAlphanNonAlpha,'Ts','d1');
fclose(FNs);


